/* =========================================================
   Cotizador Dental Bci — popup
   Tarifas: Script Bci Dental Full, septiembre 2026.
   Valores en centésimas de UF (enteros) para que la
   conversión a pesos no arrastre errores de coma flotante.
   El índice del arreglo es la cantidad de cargas (0 a 3).
   ========================================================= */
const PLANES = [
  {id:"basico", nom:"Plan Urgencias",    precios:[26, 33, 39, 46]},
  {id:"full",   nom:"Plan 3 Full",       precios:[43, 68, 92, 116]},
  {id:"ninos",  nom:"Plan 4 Full Niños", precios:[null, 81, 113, 144]}
];
const MAX_CARGAS = 3;
const EDAD_NINOS = 14;

/* Aqui NO se calcula la edad del titular: no cambia el plan ni el precio.
   Lo unico que importa es la carga contra el corte de 14 anos.
   Las reglas de titular y conyuge estan documentadas en ../PRODUCTO.md. */
const REGLAS = {
  hijo: {min:{a:0, d:14, txt:"14 días"}, ing:{a:23,d:0, txt:"23 años y 0 días"}, per:{a:24,d:0, txt:"24 años y 0 días"}}
};

/* ---------- fechas ---------- */
function hoy(){ const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }
function fmt(d){ return String(d.getDate()).padStart(2,"0")+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+d.getFullYear(); }
// Lee "dd/mm/aaaa" y verifica que la fecha exista de verdad (rechaza 31/02)
function leerFecha(txt){
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(txt.trim());
  if(!m) return null;
  const dd=+m[1], mm=+m[2], aa=+m[3];
  if(mm<1 || mm>12 || dd<1 || aa<1900) return null;
  const d = new Date(aa, mm-1, dd);
  if(d.getFullYear()!==aa || d.getMonth()!==mm-1 || d.getDate()!==dd) return null;
  if(d > hoy()) return null;
  return d;
}
function hito(nac, h){
  const b = new Date(nac.getFullYear()+(h.a||0), nac.getMonth(), nac.getDate());
  b.setDate(b.getDate() + (h.d||0));
  return b;
}
function edad(nac, ref){
  let y=ref.getFullYear()-nac.getFullYear(), m=ref.getMonth()-nac.getMonth(), d=ref.getDate()-nac.getDate();
  if(d<0){ m--; d += new Date(ref.getFullYear(), ref.getMonth(), 0).getDate(); }
  if(m<0){ y--; m+=12; }
  return {y:y,m:m,d:d};
}
function edadTxt(nac, ref){
  const e = edad(nac, ref);
  if(e.y>0) return e.y+"a "+e.m+"m";
  if(e.m>0) return e.m+"m "+e.d+"d";
  return e.d+" días";
}

/* ---------- números ---------- */
function miles(n){ return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,"."); }
function ufTxt(c){ return miles(Math.floor(c/100))+","+String(c%100).padStart(2,"0"); }
function pesos(ufCent, planCent){
  const bruto = ufCent*planCent;                       // unidades de 0,0001 peso
  return {
    exacto: "$"+miles(Math.floor(bruto/10000))+","+String(bruto%10000).padStart(4,"0"),
    redondo: "$"+miles(Math.round(bruto/10000))
  };
}

/* ---------- valor UF ---------- */
let UF = null;
function pintarUF(cent, fecha, fuente){
  UF = cent;
  document.getElementById("ufVal").textContent   = cent===null ? "—" : "$"+ufTxt(cent);
  document.getElementById("ufFecha").textContent = cent===null ? "" : fecha+" · "+fuente;
  calcular();
}
/* Abierta como página web (no como extensión) no hay chrome.storage ni se
   puede consultar otro sitio, así que la UF se escribe a mano. */
const ESWEB = (typeof chrome === "undefined" || !chrome.storage);

async function cargarUF(){
  if(ESWEB){
    document.getElementById("ufManualBox").style.display = "flex";
    const c = leerGuardado();
    if(c) pintarUF(c.c, c.f, "escrita a mano");
    else  document.getElementById("ufFecha").textContent = "escríbela aquí abajo";
    avisarUFVieja();
    return;
  }
  document.getElementById("ufFecha").textContent = "actualizando…";
  try{
    const r = await fetch("https://mindicador.cl/api/uf", {cache:"no-store"});
    if(r.ok){
      const j = await r.json(), s = j.serie && j.serie[0];
      if(s && s.valor){
        const cent = Math.round(s.valor*100);
        const iso = String(s.fecha).slice(0,10).split("-");          // sin desfase de zona horaria
        const f = iso[2]+"-"+iso[1]+"-"+iso[0];
        guardar(cent, f);
        pintarUF(cent, f, "mindicador");
        return;
      }
    }
  }catch(e){}
  try{
    const r = await fetch("https://api.boostr.cl/economy/uf.json", {cache:"no-store"});
    if(r.ok){
      const j = await r.json(), v = j && j.data && (j.data.value || j.data.valor);
      if(v){
        const cent = Math.round(parseFloat(String(v).replace(/\./g,"").replace(",","."))*100);
        const f = fmt(hoy());
        guardar(cent, f);
        pintarUF(cent, f, "boostr");
        return;
      }
    }
  }catch(e){}
  const c = leerGuardado();
  if(c){ pintarUF(c.c, c.f, "guardado"); }
  else  { pintarUF(null, "", ""); }
  document.getElementById("ufManualBox").style.display = "flex";
}
function guardar(c, f){ almacen.escribir("uf", {c:c, f:f}); }

function avisarUFVieja(){
  const el = document.getElementById("ufVieja");
  if(!el) return;
  const c = leerGuardado();
  const vieja = UF !== null && c && c.f && c.f !== fmt(hoy());
  el.hidden = !vieja;
  if(vieja) el.textContent = "Ese valor es del " + c.f + ". Actualízalo con la UF de hoy.";
}
let cacheUF = null;
function leerGuardado(){ return cacheUF; }

/* ---------- evaluación ---------- */
function evaluar(nac, ref, tipo){
  const r = REGLAS[tipo];
  const fMin = hito(nac, r.min), fIng = hito(nac, r.ing), fPer = hito(nac, r.per);
  let estado, motivo = "";
  if(ref < fMin){
    estado = "menor";
    motivo = "no cumple la edad mínima de ingreso ("+r.min.txt+"), la cumple el "+fmt(fMin);
  }else if(ref > fIng){
    estado = "fuera";
    motivo = (ref < fPer)
      ? "supera la edad máxima de ingreso ("+r.ing.txt+"), alcanzada el "+fmt(fIng)
      : "superó la edad máxima de permanencia ("+r.per.txt+") el "+fmt(fPer);
  }else{
    estado = "ok";
  }
  return {estado:estado, motivo:motivo, menor14: ref < hito(nac, {a:EDAD_NINOS, d:0})};
}

/* ---------- entrada rápida de fecha ---------- */
function autoFecha(el){
  const pos = el.selectionStart, largo = el.value.length;
  let v = el.value.replace(/\D/g,"").slice(0,8);
  if(v.length > 4)      v = v.slice(0,2)+"/"+v.slice(2,4)+"/"+v.slice(4);
  else if(v.length > 2) v = v.slice(0,2)+"/"+v.slice(2);
  el.value = v;
  if(pos < largo) el.setSelectionRange(pos, pos);       // no saltar al final al editar en medio
}

/* ---------- guardado ----------
   El popup se cierra cada vez que el ejecutivo pincha fuera, y en una
   llamada real se sale a buscar datos a otro sistema. Nada de lo que
   escriba puede perderse: el estado se guarda en cada tecla y se
   restaura al abrir. Sólo el botón "Nuevo cliente" lo borra. */
const almacen = {
  leer: function(clave, cb){
    try{ chrome.storage.local.get(clave, function(r){ cb(r ? r[clave] : null); }); }
    catch(e){
      try{ cb(JSON.parse(localStorage.getItem(clave) || "null")); }catch(e2){ cb(null); }
    }
  },
  escribir: function(clave, valor){
    try{ chrome.storage.local.set(Object.fromEntries([[clave, valor]])); }
    catch(e){ try{ localStorage.setItem(clave, JSON.stringify(valor)); }catch(e2){} }
  },
  borrar: function(clave){
    try{ chrome.storage.local.remove(clave); }
    catch(e){ try{ localStorage.removeItem(clave); }catch(e2){} }
  }
};

let restaurando = false;

function guardarEstado(){
  if(restaurando) return;
  const cargas = [].map.call(document.querySelectorAll("#hijos .fila"), function(f){
    return { edad: f.querySelector(".edad").value, fecha: f.querySelector(".fecha").value };
  });
  const comuna = document.getElementById("comuna").value;
  const hayAlgo = nCargas > 0 || envio !== "linea" || planElegido !== PLAN_POR_DEFECTO ||
                  !document.getElementById("panelClin").hidden || comuna !== "";
  if(!hayAlgo){ almacen.borrar("estado"); pintarGuardado(null); return; }
  const estado = {
    n: nCargas,
    plan: planElegido,
    guion: guionAbierto,
    clinAbierto: !document.getElementById("panelClin").hidden,
    comuna: comuna,
    envio: envio,
    cargas: cargas,
    cuando: Date.now()
  };
  almacen.escribir("estado", estado);
  pintarGuardado(estado);
}

function pintarGuardado(estado){
  const barra = document.getElementById("guardado");
  if(!estado){ barra.hidden = true; return; }
  barra.hidden = false;
  const d = new Date(estado.cuando);
  document.getElementById("guardadoTxt").textContent =
    "Guardado a las " + String(d.getHours()).padStart(2,"0") + ":" + String(d.getMinutes()).padStart(2,"0") +
    ". Se mantiene aunque cierres el popup.";
}

function restaurarEstado(cb){
  almacen.leer("estado", function(e){
    if(!e){ pintarBloqueCargas(); if(cb) cb(); return; }
    restaurando = true;
    nCargas = Math.max(0, Math.min(MAX_CARGAS, e.n || 0));
    planElegido = e.plan || PLAN_POR_DEFECTO;
    guionAbierto = !!e.guion;
    envio = e.envio || "linea";
    marcarEnvio();

    // Una fila por carga, con lo que se había escrito
    const cont = document.getElementById("hijos");
    cont.innerHTML = "";
    for(let k = 0; k < nCargas; k++){
      const caja = filaHijo(true);
      const c = (e.cargas || [])[k] || {};
      caja.querySelector(".edad").value  = c.edad  || "";
      caja.querySelector(".fecha").value = c.fecha || "";
    }
    pintarBloqueCargas();

    if(e.clinAbierto){
      document.getElementById("panelClin").hidden = false;
      document.getElementById("abrirClin").classList.add("open");
    }
    document.getElementById("comuna").value = e.comuna || "";
    restaurando = false;
    pintarGuardado(e);
    calcular();
    if(e.comuna && norm(e.comuna).length >= 3) buscarComuna(e.comuna);
    if(cb) cb();
  });
}

/* ---------- veredictos ----------
   Con la fecha de nacimiento el veredicto es exacto.
   Con la edad en años alcanza para lo que decide el plan, salvo en los
   bordes (recién nacido, 23 años), donde hay que pedir la fecha. */
let nCargas = 0;

function veredictoPorFecha(nac, ref){
  const ev = evaluar(nac, ref, "hijo");
  const e  = edadTxt(nac, ref);
  if(ev.estado === "menor")
    return {clase:"no", chip:"bad", corto:e+" · aún no",
            texto:"Aún no puede ingresar: la edad mínima es 14 días. Podrá desde el "+fmt(hito(nac, REGLAS.hijo.min))+".",
            menor14:false, bloquea:true};
  if(ev.estado === "fuera")
    return {clase:"no", chip:"bad", corto:e+" · fuera",
            texto:"No entra en ningún plan: "+ev.motivo+".", menor14:false, bloquea:true};
  if(ev.menor14)
    return {clase:"no", chip:"warn", corto:e+" · menor de 14",
            texto:"Sólo Plan 4 Full Niños. No entra en Urgencias ni en Full.", menor14:true, bloquea:false};
  return {clase:"si", chip:"ok", corto:e+" · califica",
          texto:"Entra en Urgencias, en Full y en Full Niños.", menor14:false, bloquea:false};
}

function veredictoPorEdad(a){
  if(a < 0 || a > 120) return null;
  if(a === 0)
    return {clase:"pide", chip:"warn", corto:"menos de 1 año",
            texto:"Escribe la fecha de nacimiento: la edad mínima de ingreso son 14 días.",
            menor14:true, bloquea:false, aprox:true};
  if(a < 14)
    return {clase:"no", chip:"warn", corto:a+" años · menor de 14",
            texto:"Sólo Plan 4 Full Niños. No entra en Urgencias ni en Full.",
            menor14:true, bloquea:false, aprox:true};
  if(a < 23)
    return {clase:"si", chip:"ok", corto:a+" años · califica",
            texto:"Entra en Urgencias, en Full y en Full Niños.",
            menor14:false, bloquea:false, aprox:true};
  if(a === 23)
    return {clase:"pide", chip:"warn", corto:"23 años · depende",
            texto:"Escribe la fecha de nacimiento: el tope de ingreso es 23 años y 0 días, así que depende del día exacto.",
            menor14:false, bloquea:false, aprox:true};
  return {clase:"no", chip:"bad", corto:a+" años · fuera",
          texto:"No entra en ningún plan: el tope de permanencia es 24 años y 0 días.",
          menor14:false, bloquea:true, aprox:true};
}

/* ---------- filas de cargas ---------- */
function filaHijo(silencioso){
  const cont = document.getElementById("hijos");
  if(cont.querySelectorAll(".fila").length >= MAX_CARGAS) return null;
  const caja = document.createElement("div");
  caja.innerHTML =
    '<div class="fila">'+
      '<span class="edadbox">'+
        '<input type="text" class="edad" inputmode="numeric" placeholder="edad" maxlength="3">'+
        '<span class="spin">'+
          '<button type="button" class="up" tabindex="-1" title="Subir un año">&#9650;</button>'+
          '<button type="button" class="down" tabindex="-1" title="Bajar un año">&#9660;</button>'+
        '</span>'+
      '</span>'+
      '<span class="sep">o</span>'+
      '<input type="text" class="fecha" inputmode="numeric" placeholder="dd/mm/aaaa" maxlength="10">'+
      '<span class="chip">—</span>'+
    '</div>'+
    '<div class="veredicto n"></div>';
  cont.appendChild(caja);
  const ed = caja.querySelector(".edad"), fe = caja.querySelector(".fecha");

  // Flechas: suben y bajan de a un año, entre 0 y 99
  function mover(paso){
    if(ed.readOnly) return;
    const actual = ed.value === "" ? (paso > 0 ? -1 : 1) : parseInt(ed.value, 10);
    const nuevo = Math.max(0, Math.min(99, (isNaN(actual) ? 0 : actual) + paso));
    ed.value = String(nuevo);
    calcular(); guardarEstado();
  }
  caja.querySelector(".up").addEventListener("click", function(){ mover(1); });
  caja.querySelector(".down").addEventListener("click", function(){ mover(-1); });
  // Y con las flechas del teclado, que es aún más rápido
  ed.addEventListener("keydown", function(e){
    if(e.key === "ArrowUp"){ e.preventDefault(); mover(1); }
    else if(e.key === "ArrowDown"){ e.preventDefault(); mover(-1); }
  });
  ed.addEventListener("input", function(){
    this.value = this.value.replace(/\D/g,"").slice(0,3);
    calcular(); guardarEstado();
  });
  fe.addEventListener("input", function(){ autoFecha(this); calcular(); guardarEstado(); });
  if(!silencioso){ ed.focus(); calcular(); guardarEstado(); }
  return caja;
}

/* La casilla "tiene cargas" es la que habilita todo lo de las cargas.
   Sin marcarla se cotiza al titular solo. Marcada, hay una fila de edad
   por cada carga: 1 carga, 1 fila. */
function sincronizarFilas(){
  const cont = document.getElementById("hijos");
  while(cont.children.length < nCargas) filaHijo(true);
  while(cont.children.length > nCargas) cont.removeChild(cont.lastElementChild);
}

function pintarBloqueCargas(){
  document.getElementById("tieneCargas").checked = nCargas > 0;
  document.getElementById("bloqueCargas").hidden = nCargas === 0;
  marcarCargas();
  sincronizarFilas();
}

/* ---------- cálculo ---------- */
let ultimaCotizacion = "";
/* Por defecto se cotiza el Plan Urgencias. Sin menores, el cliente puede
   subir a Full. Con un menor de 14, el Plan 4 queda forzado. */
const PLAN_POR_DEFECTO = "basico";
let planElegido = PLAN_POR_DEFECTO;
/* true cuando el Plan 4 lo impuso un menor, no el ejecutivo. Si el menor
   desaparece (se corrige la edad, se quita la carga), se vuelve solo al plan
   por defecto en vez de dejar cotizando el plan más caro sin razón. */
let planForzado = false;

function calcular(){
  const ref = hoy();
  const problemas = [];
  let menores = 0, evaluados = 0;

  [].forEach.call(document.querySelectorAll("#hijos .fila"), function(f){
    const ed  = f.querySelector(".edad");
    const fe  = f.querySelector(".fecha");
    const chip = f.querySelector(".chip");
    const ver  = f.parentNode.querySelector(".veredicto");

    const nac = leerFecha(fe.value);
    fe.classList.toggle("mal", fe.value.length===10 && !nac);

    let v = null;
    if(nac){
      // Con fecha, la edad se deriva y se bloquea para que no se pisen
      v = veredictoPorFecha(nac, ref);
      ed.value = edad(nac, ref).y;
      ed.readOnly = true;
      ed.title = "Calculada desde la fecha. Borra la fecha para escribirla a mano.";
      ed.classList.remove("mal");
    }else{
      ed.readOnly = false;
      ed.title = "";
      if(ed.value !== ""){
        v = veredictoPorEdad(parseInt(ed.value, 10));
        ed.classList.toggle("mal", v === null);
      }else{
        ed.classList.remove("mal");
      }
    }

    if(!v){
      chip.className = "chip";
      chip.textContent = (fe.value.length===10) ? "fecha inválida" : (fe.value ? "fecha incompleta" : "—");
      ver.className = "veredicto n"; ver.textContent = "";
      return;
    }
    evaluados++;
    chip.className = "chip " + v.chip;
    chip.textContent = v.corto;
    ver.className = "veredicto " + v.clase;
    ver.textContent = v.texto + (v.aprox && v.clase!=="pide" ? " (por edad; con la fecha queda exacto)" : "");
    if(v.menor14) menores++;
    if(v.bloquea) problemas.push(v.texto);
  });



  // Plan. Con cero cargas no se incorpora a nadie, asi que un menor escrito
  // en el verificador no puede obligar al Plan 4: todavia no entra al grupo.
  const obliga = menores > 0 && nCargas > 0;
  if(obliga){
    planElegido = "ninos";
    planForzado = true;
  }else if(planForzado){
    planElegido = PLAN_POR_DEFECTO;     // se acabó la obligación: no dejar el caro puesto
    planForzado = false;
  }
  if(PLANES.filter(function(p){ return p.id===planElegido; })[0].precios[nCargas] === null && !obliga){
    planElegido = PLAN_POR_DEFECTO;
  }
  const plan = PLANES.filter(function(p){ return p.id===planElegido; })[0];
  const cent = plan.precios[nCargas];

  // Aviso
  const av = document.getElementById("aviso");
  let clase = "aviso", texto = "";
  if(obliga){
    clase = "aviso bad";
    const alt = PLANES[0].precios[nCargas];
    texto = "Hay "+menores+" menor"+(menores===1?"":"es")+" de 14: no entra"+(menores===1?"":"n")+
            " en Urgencias ni en Full. Obligatorio Plan 4 Full Niños.";
    if(UF && alt!==null && cent!==null) texto += " Son "+pesos(UF, cent-alt).redondo+" más al mes que Urgencias.";
  }else if(evaluados > 0){
    clase = "aviso ok";
    texto = (evaluados===1 ? "La carga califica" : "Las "+evaluados+" cargas califican")+
            ": el cliente puede quedarse en Urgencias o subir a Full.";
  }
  if(cent === null){
    clase = "aviso warn";
    texto = "El Plan 4 Full Niños no se vende con titular solo. Marca al menos 1 carga.";
  }
  if(problemas.length){ clase = "aviso bad"; texto = problemas.join(" "); }
  av.className = clase; av.textContent = texto;

  // Tabla seleccionable
  document.getElementById("tbody").innerHTML = PLANES.map(function(p){
    const c = p.precios[nCargas];
    const veta = (obliga && p.id!=="ninos");
    if(c === null) return '<tr><td class="off">'+p.nom+'</td><td class="n off">—</td><td class="n off">no aplica</td></tr>';
    const v = UF ? pesos(UF, c) : null;
    const cls = (p.id===planElegido) ? "hit" : (veta ? "veta" : "sel");
    const flecha = (guionAbierto && p.id===planElegido) ? '<span class="flecha">&#9656;</span>' : '';
    const nombre = veta
      ? p.nom + ' <small>(no admite menores)</small>'
      : '<button type="button" class="nomplan" data-nombre="'+p.id+'">'+p.nom+flecha+'</button>';
    return '<tr class="'+cls+'" data-plan="'+p.id+'"><td>'+nombre+
           '</td><td class="n">'+ufTxt(c)+'</td><td class="n">'+(v ? v.redondo : "—")+"</td></tr>";
  }).join("");

  // Total
  const v = (UF && cent!==null) ? pesos(UF, cent) : null;
  const compos = ["titular solo","titular + 1","titular + 2","titular + 3"][nCargas];
  document.getElementById("tUF").textContent  = cent===null ? "—" : ufTxt(cent)+" UF";
  document.getElementById("tCLP").textContent = v ? v.redondo : "";
  document.getElementById("exacto").textContent = v ? ufTxt(cent)+" × $"+ufTxt(UF)+" = "+v.exacto
                                                    : (UF ? "" : "sin valor UF");
  // Resumen permanente arriba: siempre a la vista, cambie lo que cambie
  document.getElementById("resPlan").textContent   = plan.nom;
  document.getElementById("resCompos").textContent = compos;
  document.getElementById("resUF").textContent     = cent===null ? "—" : ufTxt(cent)+" UF";
  document.getElementById("resCLP").textContent    = v ? v.redondo : "—";

  ultimaCotizacion = v
    ? plan.nom+" · "+compos+" · "+ufTxt(cent)+" UF · "+v.redondo+" mensual (UF de hoy $"+ufTxt(UF)+")"
    : "";

  if(typeof pintarGuion === "function") pintarGuion();
}

function marcarEnvio(){
  [].forEach.call(document.querySelectorAll("#envio button"), function(b){
    b.classList.toggle("on", b.dataset.envio === envio);
  });
  document.getElementById("envioPista").textContent = (envio === "linea")
    ? "Tiene cuenta Bci: se carga la prima a su cuenta corriente."
    : "Sin cuenta Bci: se le envía el link de pago, con 48 horas de vigencia.";
}

function marcarCargas(){
  [].forEach.call(document.querySelectorAll("#conteo button"), function(b){
    b.classList.toggle("on", +b.dataset.n === nCargas);
  });
}

/* ============================================================
   GUION DE VENTA
   Tomado del Script Bci Dental Full de septiembre 2026. Cada
   seccion declara en que planes se lee, y los montos se
   calculan en vivo con la UF del dia, para no leer cifras
   congeladas al cliente.
   ============================================================ */
const GUION = [
  {t:"Apertura", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>Muy buenos días / tardes, usted habla con <em>[su nombre]</em>. Lo llamo por ser cliente Bci. ¿Cómo está?</p>'+
    '<p>El motivo de mi llamado es entregarle una información importante, son buenas noticias, y no le quitaré mucho tiempo. '+
    'Queremos agradecer su permanencia como cliente y contarle que Bci pone a su disposición una completa cobertura dental, '+
    'que le cubrirá hasta el 100% en los tratamientos dentales más frecuentes. Y lo mejor es que la atención es exclusiva en la '+
    'red de clínicas <strong>Uno Salud Dental</strong>, más de 80 clínicas a lo largo de todo Chile.</p>'; }},

  {t:"Urgencias, a costo $0", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>Tendrá los siguientes tratamientos de urgencia dental <strong>sin costo</strong>, en caso de dolor, inflamación o sangrado. Por ejemplo:</p>'+
    '<ul><li>Extracciones simples</li>'+
    '<li>Trepanación, que es la primera parte del tratamiento de conducto</li>'+
    '<li>Colocación de cemento o tapadura temporal</li>'+
    '<li>Urgencia protésica: recementación de corona, puentes, incrustaciones y reparación de prótesis</li></ul>'+
    '<p class="nota">Sin tope. Carencia de 48 horas hábiles.</p>'; }},

  {t:"Prevención", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>Además le cubrimos tratamientos de prevención: evaluación y diagnóstico, radiografías pieza a pieza, y una '+
    '<strong>limpieza profunda</strong> (profilaxis más remoción de cálculos supragingivales), para remover la placa '+
    'bacteriana y el sarro acumulados entre los dientes.</p>'+
    '<p>Los odontólogos recomiendan una limpieza al menos una vez al año, y usted la tendría sin costo con nosotros '+
    'dentro de 30 días.</p>'; }},

  {t:"Tratamientos con copago", p:["full","ninos"], html:function(d){ return ''+
    '<p>Para los tratamientos más complejos, que de forma particular suelen ser los más costosos, también podrá acceder '+
    'dentro de 30 días, con copagos claros y fijos conocidos antes de realizarlos:</p>'+
    '<ul><li><strong>5 tapaduras en resina al año</strong>, a $12.000 cada una. En otras clínicas son unos $45.000.</li>'+
    '<li><strong>2 tratamientos de conducto al año</strong>, en muelas, premolares o dientes anteriores, a $12.000 cada uno. '+
    'El valor referencial en otras clínicas va de $150.000 a $300.000.</li></ul>'+
    '<p>Y hasta un <strong>65% de descuento</strong> en: extracción de muelas del juicio, planos de relajación para el bruxismo, '+
    'cambio de tapadura de amalgama a resina, tapaduras de resina adicionales y tratamientos de conducto adicionales.</p>'; }},

  {t:"Odontología para niños", p:["ninos"], clase:"clave", html:function(d){ return ''+
    '<p>Y como usted tiene niños menores de 14 años, le entregamos <strong>11 procedimientos adicionales</strong> asociados a '+
    'dientes temporales, a costo cero y sin tope, que podrá utilizar dentro de 30 días.</p>'; }},

  {t:"Programas de salud y bienestar", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>Además, sin costo, accede al <strong>Programa de Salud y Bienestar de Bci</strong>, con 13 programas: telemedicina, '+
    'salud mental, nutrición, kinesiología, fonoaudiología, entre otros. Uso ilimitado y atención multicanal.</p>'+
    '<p>Para acceder debe descargar la aplicación <strong>Care Assistance</strong> y seguir las instrucciones que recibirá en el '+
    'correo de bienvenida.</p>'; }},

  {t:"Muerte accidental", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>Complementando lo anterior, existe una protección frente a accidentes personales que terminen en fallecimiento '+
    '(sólo titular), que entrega una indemnización a sus herederos legales de <span class="dato">50 UF</span>'+
    (d.ap ? ', unos <span class="dato">'+d.ap+'</span>' : '')+'. Dinero de libre disposición.</p>'+
    '<p>Es una cobertura completa, ¿verdad?</p>'; }},

  {t:"Sin reembolsos", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>Lo mejor es que no trabajamos con reembolso, así que puede olvidarse de comprar bonos y de los papeleos. '+
    'Usted agenda la primera hora llamando al <strong>227501096</strong>, en cualquiera de las clínicas de la red Uno Salud, '+
    'donde le aplicarán todos los descuentos y valores automáticamente en su presupuesto.</p>'; }},

  {t:"Requisitos", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>Usted cumple con los requisitos, ya que es mayor de 18 años y menor de 70 años. La permanencia máxima es hasta '+
    'un día antes de cumplir los 71 años.</p>'+
    (d.cargas > 0
      ? '<p>Puede incorporar adicionales, cónyuge e hijos. La edad mínima de ingreso de sus hijos es de <strong>14 días</strong> '+
        'y la permanencia es hasta los <strong>24 años y 0 días</strong>. Sus adicionales contarían con la cobertura dental y los programas.</p>'+
        '<p class="nota">Necesito de cada adicional: nombre completo, RUT, fecha de nacimiento y parentesco. Los cuatro datos.</p>'
      : ''); }},

  {t:"El precio", p:["basico","full","ninos"], clase:"clave", html:function(d){ return ''+
    '<p>Lo más importante: todas las coberturas, asistencias y beneficios mencionados tienen un costo de '+
    '<span class="dato">'+d.uf+' UF</span> fijas, que son <span class="dato">'+d.clp+'</span> aproximadamente, '+
    'que se cargarán automáticamente en su cuenta Bci terminada en los dígitos <em>[XXX]</em>, en su próximo estado de cuenta.</p>'+
    '<p class="nota">'+d.plan+' · '+d.compos+' · calculado con la UF de hoy, $'+d.ufdia+'.</p>'+
    '<p>Además, este mes tenemos una promoción especial: la compañía le otorga <em>[X]</em> cuota sin costo durante el primer '+
    'año de vigencia. ¿Qué fecha de cargo le acomoda? ¿Lo incorporo, verdad?</p>'; }},

  {t:"Si duda o lo rechaza", p:["full"], clase:"ojo", html:function(d){ return ''+
    '<p>Como no queremos que se quede sin cobertura y lo tome por sorpresa un dolor de muelas, le ofrecemos por sólo '+
    '<span class="dato">'+(d.clpBasico || '—')+'</span> mensuales, es decir <span class="dato">'+(d.ufBasico || '—')+' UF</span>, '+
    'todas las urgencias dentales que ya le mencioné, más los tratamientos de prevención.</p>'+
    '<p class="nota">Es el Plan Urgencias. Pincha esa fila para leer su script.</p>'; }},

  {t:"Si quiere más cobertura", p:["basico"], clase:"ojo", html:function(d){ return ''+
    '<p>Si además quiere cubrir tapaduras y tratamientos de conducto, tenemos el Plan Full por '+
    '<span class="dato">'+(d.clpFull || '—')+'</span> mensuales: agrega 5 tapaduras y 2 tratamientos de conducto al año '+
    'con copago de $12.000 cada uno, y hasta 65% de descuento en el resto.</p>'+
    '<p class="nota">Pincha la fila del Plan 3 Full para leer su script completo.</p>'; }},

  {t:"Por qué no puede quedar en un plan menor", p:["ninos"], clase:"ojo", html:function(d){ return ''+
    '<p class="nota">Recordatorio interno, no se lee al cliente: hay un menor de 14 años en el grupo. La odontología infantil '+
    'sólo existe en este plan, así que no corresponde ofrecer Urgencias ni Full.</p>'; }},

  {t:"Pregunta de contratación · textual", p:["basico","full","ninos"], clase:"clave", html:function(d){ return ''+
    '<p>Antes de continuar le informo que, para su tranquilidad y respaldo, esta conversación está siendo grabada.</p>'+
    '<p>Señor o señora <em>[apellido]</em>, entonces con fecha <em>[DD/MM/AA]</em>, ¿acepta la contratación en forma '+
    'voluntaria del <strong>Seguro Dental Modular Bci</strong>, con las coberturas detalladas anteriormente, con un valor '+
    'mensual de <span class="dato">'+d.uf+' UF</span> fijas, <span class="dato">'+d.clp+'</span> aproximadamente, '+
    'IVA incluido? ¿Acepta?</p>'+
    '<p class="nota">Sólo vale “sí”, “acepto” o “de acuerdo”. No sirve “ok”, “ya” ni “correcto”.</p>'; }},

  {t:"Validación de datos", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>Entonces, para cumplir con la normativa y poder realizar el correcto envío de su póliza, le voy a solicitar '+
    'que me corrobore si los datos que tengo en pantalla están vigentes y correctos.</p>'+
    '<ul><li>Fecha de nacimiento</li><li>Domicilio completo</li><li>Teléfono de contacto</li>'+
    '<li>Correo electrónico <span class="nota">(fundamental para enviar la póliza vía email)</span></li>'+
    '<li>Nombre completo y RUT</li></ul>'+
    (d.cargas > 0 ? '<p class="nota">De cada asegurado adicional: nombre completo, RUT, fecha de nacimiento y parentesco. Los cuatro son obligatorios.</p>' : ''); }},

  {t:"Medio de pago · póliza en línea", p:["basico","full","ninos"], envio:"linea", clase:"clave", html:function(d){ return ''+
    '<p>“Sr./Sra. <em>[apellido]</em>, usted ¿autoriza el cargo de la prima mensual del seguro, el que será '+
    'descontado de su cuenta corriente <em>[N.º medio de pago]</em> del banco Bci? ¿Acepta?”</p>'+
    '<p class="nota">Esperar respuesta. Esta es la opción para el cliente que tiene cuenta Bci.</p>'; }},

  {t:"Medio de pago · link de pago", p:["basico","full","ninos"], envio:"link", clase:"clave", html:function(d){ return ''+
    '<p class="nota">Pago débito: cobro inmediato. Pago crédito: próximo ciclo de facturación.</p>'+
    '<p>“Sr./Sra. <em>[apellido]</em>, en este momento le llegará a su correo electrónico un correo con el asunto '+
    '<strong>Multicotizador – Pago de primera cuota</strong>, donde encontrará el link de pago, en naranjo: '+
    '<strong>Pagar aquí</strong>.</p>'+
    '<p>Autoriza el cargo de la prima mensual del Seguro Dental, el que será descontado en la forma de pago que '+
    'usted seleccione cuando ingrese al link enviado a su correo. ¿Acepta?”</p>'+
    '<p class="nota">Esperar respuesta.</p>'+
    '<p>“Si no puede realizar el pago en este momento, le comento que este link tiene una vigencia de '+
    '<strong>48 horas</strong>. Mientras no realice el pago, este seguro no está vigente y no puede hacer uso de '+
    'las asistencias y las coberturas.”</p>'; }},

  {t:"Después del pago", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>“Lo invitamos a siempre estar al día en el pago de su prima mensual, para así poder utilizar su cobertura '+
    'cuando la necesite.</p>'+
    '<p>Haremos llegar a su correo electrónico dentro de unos minutos, cuando registre su medio de pago, su póliza '+
    'de seguro y todas las comunicaciones relativas a esta.”</p>'; }},

  {t:"Exclusiones", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>Estas son algunas de las principales exclusiones. No se cubre cuando el origen sean: guerra, peleas o riñas, actos '+
    'delictivos, suicidio o intento, intoxicación o efecto de drogas, conducción en estado de ebriedad, negligencia o '+
    'imprudencia, servicio en fuerzas armadas o policiales, sismos de grado 8 o superior, o vuelo en aeronave de itinerario '+
    'no regular.</p>'+
    '<p>En el programa dental se excluyen cirugías de alta complejidad, cirugías para implantes fuera de la red Uno Salud, '+
    'costos de laboratorio y medicación.</p>'; }},

  {t:"Cierre normativo", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>Las condiciones generales están registradas en la CMF bajo el código <strong>POL 3 2013 0085 Alt. A</strong> para '+
    'muerte accidental y <strong>POL 3 2019 0055</strong> para la cobertura dental.</p>'+
    '<p>Bci Seguros Vida y Bci Corredores de Seguros tratarán sus datos para evaluar y mejorar sus servicios. '+
    '¿Autoriza el tratamiento de los mismos?</p>'+
    '<p>El código de operación asociado a esta venta es <em>[RUT o ID de venta]</em>. Guárdelo para futuras consultas. '+
    'La grabación constituye prueba de la información entregada y de la aceptación del contrato.</p>'+
    '<p>La vigencia comienza hoy, es anual y renovable automáticamente. Puede retractarse dentro de 10 días desde que '+
    'reciba la póliza, sin causa ni cargo, con devolución de la prima pagada.</p>'+
    '<p class="nota">Centro de Respuesta Inmediata 600 6000 292. Asistencia dental 227501096.</p>'; }},

  {t:"Encuesta EPA", p:["basico","full","ninos"], html:function(d){ return ''+
    '<p>“Don o señorita <em>[nombre]</em>, para finalizar lo derivaré a una pequeña encuesta de 2 preguntas para que '+
    'califique mi atención en esta llamada, ¿de acuerdo? Que tenga buen día.”</p>'+
    '<p class="nota">En el sistema: Transfer-Conf → ingroup ENCUESTA_EPA → CLOSER LOCAL, y luego tipificar. '+
    'Obligatoria salvo derivación a IVR por pago con tarjeta de crédito.</p>'; }}
];

let guionAbierto = false;   // se abre sólo al pinchar el nombre del plan
/* Por defecto se lee la opción de póliza en línea, porque el cliente tiene
   cuenta Bci. Si no la tiene, se le envía el link de pago. */
let envio = "linea";

function pintarGuion(){
  const app = document.getElementById("app");
  app.classList.toggle("abierto", guionAbierto);
  if(!guionAbierto) return;

  const plan = PLANES.filter(function(p){ return p.id===planElegido; })[0];
  const cent = plan.precios[nCargas];
  const basico = PLANES[0].precios[nCargas];
  const full   = PLANES[1].precios[nCargas];

  const d = {
    plan:   plan.nom,
    compos: ["titular solo","titular + 1 carga","titular + 2 cargas","titular + 3 cargas"][nCargas],
    cargas: nCargas,
    uf:     cent===null ? "—" : ufTxt(cent),
    clp:    (UF && cent!==null)   ? pesos(UF, cent).redondo   : "—",
    ufdia:  UF ? ufTxt(UF) : "—",
    ap:     UF ? pesos(UF, 5000).redondo : "",          // 50 UF de muerte accidental
    ufBasico:  basico!==null ? ufTxt(basico) : null,
    clpBasico: (UF && basico!==null) ? pesos(UF, basico).redondo : null,
    clpFull:   (UF && full!==null)   ? pesos(UF, full).redondo   : null
  };

  document.getElementById("guionTit").textContent = "Script · " + plan.nom;
  document.getElementById("guionSub").textContent =
    d.compos + " · " + d.uf + " UF · " + d.clp + " mensual";

  document.getElementById("guionCuerpo").innerHTML = GUION
    .filter(function(sec){
      if(sec.p.indexOf(planElegido) === -1) return false;
      if(sec.envio && sec.envio !== envio) return false;    // sólo la opción de pago que corresponde
      return true;
    })
    .map(function(sec){
      return '<div class="gs '+(sec.clase||"")+'"><h4>'+sec.t+"</h4>"+sec.html(d)+"</div>";
    }).join("");
}

/* ============================================================
   SUCURSALES POR COMUNA, LEÍDAS DE LOS SITIOS DE CADA RED
   La extensión corre en el Chrome del ejecutivo, así que lee
   unosalud.cl y e-dentalsys.com directamente (los permisos están
   en el manifest). Lo leído se guarda un día, para no consultar
   el sitio en cada llamada.
   ============================================================ */
const RED = {
  unosalud: {
    nombre: "Uno Salud",
    sitio: "https://www.unosalud.cl/region-comuna/",
    indices: ["https://www.unosalud.cl/region-comuna/", "https://www.unosalud.cl/clinicas/"],
    comuna: function(slug){ return "https://www.unosalud.cl/region-comuna/" + slug + "/"; }
  },
  edental: {
    nombre: "i-dental",
    sitio: "https://www.e-dentalsys.com/#clinicas",
    portada: "https://www.e-dentalsys.com/"
  }
};
const DIA = 24 * 60 * 60 * 1000;
const diag = {};   // lo que vio la última lectura de cada red, para depurar

/* ---------- texto ---------- */
function norm(t){
  return String(t || "").toLowerCase()
    .normalize("NFD").replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
}
function esc(t){
  return String(t == null ? "" : t).replace(/[&<>"']/g, function(c){
    return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];
  });
}
function urlSegura(u){ return /^https:\/\//i.test(String(u || "")) ? u : ""; }
function humanizar(slug){
  return String(slug || "").split("-").filter(Boolean).map(function(w){
    return w.charAt(0).toUpperCase() + w.slice(1);
  }).join(" ");
}
function txt(el){ return el ? (el.textContent || "").replace(/\s+/g, " ").trim() : ""; }

// Texto de un bloque separado en líneas, cortando donde corta el diseño
const BLOQUE = /^(ADDRESS|ARTICLE|ASIDE|BLOCKQUOTE|BR|DD|DIV|DL|DT|FIGCAPTION|FIGURE|FOOTER|FORM|H[1-6]|HEADER|HR|LI|MAIN|NAV|OL|P|SECTION|TABLE|TBODY|TD|TH|TR|UL)$/;
function lineas(el){
  const out = []; let buf = "";
  function cortar(){ const t = buf.replace(/\s+/g, " ").trim(); if(t) out.push(t); buf = ""; }
  (function rec(n){
    n.childNodes.forEach(function(c){
      if(c.nodeType === 3){ buf += c.textContent; return; }
      if(c.nodeType !== 1 || /^(SCRIPT|STYLE|NOSCRIPT|SVG|BUTTON|IFRAME|SELECT|TEMPLATE)$/.test(c.tagName)) return;
      const b = BLOQUE.test(c.tagName);
      if(b) cortar();
      rec(c);
      if(b) cortar();
    });
  })(el);
  cortar();
  return out;
}

const RE_FONO = /(\+?56[\s-]?)?(600[\s-]?\d{3}[\s-]?\d{4}|\(?22?\)?[\s-]?\d{3,4}[\s-]?\d{4}|9[\s-]?\d{4}[\s-]?\d{4})/;
function pareceHorario(l){
  return /(lunes|martes|miercoles|jueves|viernes|sabado|domingo|\blun\b|\bvie\b|\bsab\b)/.test(norm(l)) &&
         /\d{1,2}[:.]\d{2}/.test(l);
}
function pareceDireccion(l){
  if(l.length < 6 || l.length > 160 || !/\d/.test(l)) return false;
  if(pareceHorario(l)) return false;
  const sinFono = l.replace(RE_FONO, "").trim();
  if(!/[a-záéíóúñ]{3,}/i.test(sinFono)) return false;          // sólo un teléfono
  if(/^(tel|fono|telefono|whatsapp|llama)/.test(norm(l))) return false;
  return /(\bav\b|av\.|avenida|calle|pasaje|camino|paseo|alameda|mall|local|piso|esquina|esq\.|n°|nº|#|\bsur\b|\bnorte\b|oriente|poniente)/i.test(l) ||
         /[a-záéíóúñ]{3,}[^0-9]{0,40}\d{2,5}/i.test(l);
}

/* ---------- búsqueda tolerante ---------- */
function distancia(a, b, max){
  if(Math.abs(a.length - b.length) > max) return max + 1;
  let prev = [], fila = [];
  for(let j = 0; j <= b.length; j++) prev[j] = j;
  for(let i = 1; i <= a.length; i++){
    fila = [i]; let mejor = i;
    for(let j = 1; j <= b.length; j++){
      const costo = a.charCodeAt(i-1) === b.charCodeAt(j-1) ? 0 : 1;
      fila[j] = Math.min(prev[j] + 1, fila[j-1] + 1, prev[j-1] + costo);
      if(fila[j] < mejor) mejor = fila[j];
    }
    if(mejor > max) return max + 1;
    prev = fila;
  }
  return prev[b.length];
}
function puntaje(consulta, candidato){
  const q = norm(consulta), c = norm(candidato);
  if(!q || !c) return null;
  if(c === q) return 0;
  if(c.startsWith(q)) return 1;
  if(c.indexOf(q) !== -1) return 2;
  const max = q.length <= 4 ? 1 : 2;
  const d = distancia(q, c, max);
  return d <= max ? 3 + d : null;
}

/* ---------- red y caché ---------- */
async function traer(url){
  const ctl = new AbortController();
  const t = setTimeout(function(){ ctl.abort(); }, 12000);
  try{
    const r = await fetch(url, {signal: ctl.signal, credentials: "omit"});
    const html = await r.text();
    return {ok: r.ok, status: r.status, html: html, url: r.url || url};
  }catch(e){
    return {ok: false, status: 0, html: "", url: url,
            error: e.name === "AbortError" ? "el sitio tardó demasiado" : "no hubo respuesta del sitio"};
  }finally{ clearTimeout(t); }
}
function docDe(html){ return new DOMParser().parseFromString(html, "text/html"); }
function cacheLeer(clave, maxEdad){
  return new Promise(function(res){
    almacen.leer(clave, function(v){ res(v && v.t && (Date.now() - v.t) < maxEdad ? v.d : null); });
  });
}
function cacheEscribir(clave, d){ almacen.escribir(clave, {t: Date.now(), d: d}); }
function muestraHTML(doc){
  const b = doc.body ? doc.body.cloneNode(true) : null;
  if(!b) return "";
  b.querySelectorAll("script,style,noscript,svg,iframe,link,meta").forEach(function(x){ x.remove(); });
  return b.innerHTML.replace(/\s+/g, " ").slice(0, 12000);
}

/* ---------- lectura de datos estructurados (JSON-LD) ---------- */
function desdeJsonLd(doc){
  const out = [];
  doc.querySelectorAll('script[type="application/ld+json"]').forEach(function(s){
    let j; try{ j = JSON.parse(s.textContent); }catch(e){ return; }
    const pila = Array.isArray(j) ? j.slice() : [j];
    while(pila.length){
      const o = pila.pop();
      if(!o || typeof o !== "object") continue;
      ["@graph","location","department","subOrganization"].forEach(function(k){
        if(Array.isArray(o[k])) pila.push.apply(pila, o[k]);
      });
      const tipo = [].concat(o["@type"] || []).join(" ");
      if(!/Dentist|MedicalClinic|MedicalBusiness|LocalBusiness|Hospital/i.test(tipo)) continue;
      const ad = o.address;
      const dir = !ad ? "" : (typeof ad === "string" ? ad :
                  [ad.streetAddress, ad.addressLocality].filter(Boolean).join(", "));
      if(dir && o.name){
        out.push({nombre: String(o.name), direccion: dir, telefono: o.telephone || "", horario: "",
                  url: urlSegura(o.url), texto: o.name + " " + dir});
      }
    }
  });
  return out;
}

/* ---------- tarjetas: la caja que rodea a una clínica ---------- */
const GENERICO = /^(ver|ver mas|agenda|agendar|reserva|reservar|mas info|mas informacion|como llegar|llamar|whatsapp|ir|detalle|conoce mas|leer mas|ver ficha|ver clinica)$/;
function fuera(el){ return !!el.closest("header,nav,footer,[role=navigation],.menu,[class*='menu'],[id*='menu']"); }

function tarjetaDe(a, esEnlace){
  let n = a, previo = null;
  for(let i = 0; i < 8 && n && n.tagName !== "BODY"; i++){
    const propios = new Set([].filter.call(n.querySelectorAll ? n.querySelectorAll("a[href]") : [], esEnlace)
      .map(function(x){ return (x.getAttribute("href") || "").replace(/[#?].*$/, "").replace(/\/+$/, ""); }));
    if(propios.size > 1) return previo;              // ya abarca otra clínica: me quedo con el anterior
    if(lineas(n).some(pareceDireccion)) return n;
    previo = n; n = n.parentElement;
  }
  return null;
}

function datosDeTarjeta(card, a, base){
  const ls = lineas(card);
  const h = card.querySelector("h1,h2,h3,h4,h5,h6,strong,b,.title,[class*='titulo'],[class*='title'],[class*='nombre']");
  let nombre = h ? txt(h) : "";
  if(GENERICO.test(norm(nombre)) || nombre.length > 90 || pareceDireccion(nombre)) nombre = "";
  if(!nombre && a){ const t = txt(a); if(t && !GENERICO.test(norm(t)) && t.length < 80 && !pareceDireccion(t)) nombre = t; }
  if(!nombre){
    nombre = ls.find(function(l){
      return !pareceDireccion(l) && !RE_FONO.test(l) && !pareceHorario(l) && !GENERICO.test(norm(l)) && l.length < 70;
    }) || "";
  }
  const direccion = ls.find(pareceDireccion) || "";
  const fono = ls.join("  ").match(RE_FONO);
  let url = "";
  if(a){ try{ url = urlSegura(new URL(a.getAttribute("href"), base).href); }catch(e){} }
  return {nombre: nombre, direccion: direccion, telefono: fono ? fono[0].trim() : "",
          horario: ls.filter(pareceHorario).slice(0, 2).join(" · "), url: url, texto: ls.join(" ")};
}

// Último recurso: un título con una dirección justo debajo
function desdeEncabezados(doc){
  const out = [], vistas = {};
  doc.querySelectorAll("h2,h3,h4,h5").forEach(function(h){
    if(fuera(h)) return;
    const nombre = txt(h);
    if(!nombre || nombre.length > 80 || GENERICO.test(norm(nombre))) return;
    let ls = [], n = h.nextElementSibling, k = 0;
    while(n && k < 5 && !/^H[1-5]$/.test(n.tagName)){ ls = ls.concat(lineas(n)); n = n.nextElementSibling; k++; }
    const dir = ls.find(pareceDireccion);
    if(!dir || vistas[norm(dir)]) return;
    vistas[norm(dir)] = 1;
    const fono = ls.join("  ").match(RE_FONO);
    out.push({nombre: nombre, direccion: dir, telefono: fono ? fono[0].trim() : "",
              horario: ls.filter(pareceHorario).slice(0, 2).join(" · "), url: "", texto: nombre + " " + ls.join(" ")});
  });
  return out;
}

/* ---------- Uno Salud ---------- */
function parsearIndiceUnoSalud(html){
  const doc = docDe(html), m = {};
  function agregar(slug, nombre){
    slug = String(slug || "").toLowerCase();
    if(!/^(?=.*[a-z])[a-z0-9-]{2,50}$/.test(slug) || m[slug]) return;
    nombre = String(nombre || "").replace(/\s+/g, " ").trim();
    if(!nombre || nombre.length > 60 || GENERICO.test(norm(nombre)) || /\d/.test(nombre)) nombre = humanizar(slug);
    m[slug] = nombre.replace(/^cl[ií]nicas? dentales? en (la comuna de )?/i, "");
  }
  doc.querySelectorAll('a[href*="/region-comuna/"]').forEach(function(a){
    const mm = (a.getAttribute("href") || "").match(/\/region-comuna\/([^\/?#]+)\/?/i);
    if(mm) agregar(mm[1], txt(a));
  });
  doc.querySelectorAll("option").forEach(function(o){
    const v = (o.getAttribute("value") || "").trim(), t = txt(o);
    if(/\/region-comuna\//.test(v)){ const mm = v.match(/\/region-comuna\/([^\/?#]+)/); if(mm) agregar(mm[1], t); }
    else if(t && !/selecciona|todas|elige/i.test(t)) agregar(v, t);
  });
  return Object.keys(m).map(function(slug){ return {slug: slug, nombre: m[slug]}; });
}

function parsearComunaUnoSalud(html, base){
  const doc = docDe(html);
  const d = {titulo: txt(doc.querySelector("title")), estrategia: "", muestra: muestraHTML(doc)};
  const esFicha = function(a){
    const h = a.getAttribute("href") || "";
    return /\/clinicas\/[^\/?#]+\/?(?:[?#].*)?$/i.test(h) && !fuera(a);
  };
  const vistas = {}, porEnlace = [];
  [].filter.call(doc.querySelectorAll("a[href]"), esFicha).forEach(function(a){
    let k = ""; try{ k = new URL(a.getAttribute("href"), base).pathname.replace(/\/+$/, ""); }catch(e){ return; }
    if(vistas[k]) return;
    const card = tarjetaDe(a, esFicha);
    if(!card) return;
    const x = datosDeTarjeta(card, a, base);
    if(!x.direccion) return;                         // sin dirección no es una sucursal (menús, migas)
    if(!x.nombre) x.nombre = humanizar(k.split("/").pop());
    vistas[k] = 1;
    porEnlace.push(x);
  });
  const ld = desdeJsonLd(doc);
  let lista = porEnlace.length >= ld.length ? porEnlace : ld;
  d.estrategia = lista === porEnlace ? "enlaces a fichas" : "datos estructurados";
  if(!lista.length){ lista = desdeEncabezados(doc); d.estrategia = "títulos"; }
  d.encontradas = lista.length;
  d.enlacesFicha = [].filter.call(doc.querySelectorAll("a[href]"), esFicha).length;
  return {lista: lista, diag: d};
}

async function indiceUnoSalud(){
  const c = await cacheLeer("red_uno_indice", 7 * DIA);
  if(c && c.length) return c;
  const m = {};
  diag.indice = [];
  for(const u of RED.unosalud.indices){
    const r = await traer(u);
    diag.indice.push({url: u, status: r.status, error: r.error || ""});
    if(r.ok) parsearIndiceUnoSalud(r.html).forEach(function(x){ if(!m[x.slug]) m[x.slug] = x; });
  }
  const lista = Object.keys(m).map(function(k){ return m[k]; });
  if(lista.length) cacheEscribir("red_uno_indice", lista);
  return lista;
}

async function clinicasUnoSalud(comuna){
  const clave = "red_uno_" + comuna.slug;
  const c = await cacheLeer(clave, DIA);
  if(c) return c;
  const url = RED.unosalud.comuna(comuna.slug);
  const r = await traer(url);
  diag.unosalud = {url: url, status: r.status, error: r.error || ""};
  if(r.status === 404) return {lista: [], url: url, error: "", sinPagina: true};
  if(!r.ok) return {lista: [], url: url, error: r.error || ("el sitio respondió " + r.status)};
  const p = parsearComunaUnoSalud(r.html, r.url);
  Object.assign(diag.unosalud, p.diag);
  const res = {lista: p.lista, url: url, error: ""};
  if(p.lista.length) cacheEscribir(clave, res);       // un cero puede ser un fallo de lectura: no se guarda
  return res;
}

/* ---------- i-dental ---------- */
function parsearEdental(html, base){
  const doc = docDe(html);
  const d = {titulo: txt(doc.querySelector("title")), muestra: muestraHTML(doc)};
  const zona = doc.getElementById("clinicas") ||
               doc.querySelector('[id*="clinica" i],[class*="clinica" i],[id*="sucursal" i],[class*="sucursal" i],[id*="sede" i],[class*="sede" i]') ||
               doc.body;
  d.zona = zona === doc.body ? "toda la página" : (zona.id ? "#" + zona.id : "." + String(zona.className).split(/\s+/)[0]);

  // Tarjetas: bloques chicos con una dirección, que no contengan otras tarjetas
  const cand = [].filter.call(zona.querySelectorAll("article,li,div,tr,section"), function(el){
    if(fuera(el)) return false;
    const largo = (el.textContent || "").length;
    if(largo < 12 || largo > 700) return false;
    const ls = lineas(el);
    return ls.length >= 2 && ls.length <= 14 && ls.some(pareceDireccion);
  });
  const minimas = cand.filter(function(el){ return !cand.some(function(o){ return o !== el && el.contains(o); }); });

  // El título de sección que precede a cada tarjeta suele ser la región o la
  // comuna. Los títulos que están dentro de otra tarjeta no cuentan: son el
  // nombre de esa clínica, no una sección.
  const titulos = [].filter.call(doc.querySelectorAll("h1,h2,h3,h4,h5,h6"), function(h){
    return !minimas.some(function(c){ return c.contains(h); });
  });
  function contexto(el){
    let t = "";
    titulos.forEach(function(h){
      if(!el.contains(h) && (h.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING)) t = txt(h);
    });
    return t;
  }
  const vistas = {}, lista = [];
  minimas.forEach(function(card){
    const a = card.querySelector("a[href]");
    const x = datosDeTarjeta(card, a, base);
    if(!x.direccion || !x.nombre || vistas[norm(x.direccion)]) return;
    vistas[norm(x.direccion)] = 1;
    x.contexto = contexto(card);
    lista.push(x);
  });
  const ld = desdeJsonLd(doc);
  const final = lista.length >= ld.length ? lista : ld;
  d.encontradas = final.length;
  d.estrategia = final === lista ? "tarjetas" : "datos estructurados";
  return {lista: final, diag: d, doc: doc};
}

async function clinicasEdental(){
  const c = await cacheLeer("red_edental", DIA);
  if(c) return c;
  const r = await traer(RED.edental.portada);
  diag.edental = {url: RED.edental.portada, status: r.status, error: r.error || ""};
  if(!r.ok) return {lista: [], error: r.error || ("el sitio respondió " + r.status)};
  let p = parsearEdental(r.html, r.url);
  Object.assign(diag.edental, p.diag);

  // Si la portada no trae las clínicas, se sigue el enlace a la página que sí
  if(!p.lista.length){
    const link = [].find.call(p.doc.querySelectorAll("a[href]"), function(a){
      const h = a.getAttribute("href") || "";
      return !/^#|preguntas|mailto:|tel:/i.test(h) && /cl[ií]nicas|sucursales|sedes|red|centros/i.test(h + " " + txt(a));
    });
    if(link){
      let u = ""; try{ u = new URL(link.getAttribute("href"), r.url).href; }catch(e){}
      if(u){
        const r2 = await traer(u);
        diag.edental.segunda = {url: u, status: r2.status};
        if(r2.ok){ p = parsearEdental(r2.html, r2.url); Object.assign(diag.edental, p.diag); }
      }
    }
  }
  const res = {lista: p.lista.map(function(x){ delete x.doc; return x; }), error: ""};
  if(res.lista.length) cacheEscribir("red_edental", res);
  return res;
}

/* ---------- búsqueda y resultados ---------- */
let busquedaId = 0, temporizador = null;

function alEscribirComuna(){
  clearTimeout(temporizador);
  const q = document.getElementById("comuna").value;
  if(norm(q).length < 3){ pintarSugerencias([], false); pintarResultados(null); return; }
  temporizador = setTimeout(function(){ buscarComuna(q); }, 380);
}

async function buscarComuna(q, elegida){
  const id = ++busquedaId;
  pintarResultados({cargando: true, comuna: q});

  let comuna = elegida || null, sugerencias = [];
  if(!comuna){
    const indice = await indiceUnoSalud();
    if(id !== busquedaId) return;
    if(indice.length){
      const cand = indice
        .map(function(x){ return {x: x, pt: puntaje(q, x.nombre)}; })
        .filter(function(c){ return c.pt !== null; })
        .sort(function(a, b){ return a.pt - b.pt || a.x.nombre.localeCompare(b.x.nombre); });
      sugerencias = cand.slice(0, 5).map(function(c){ return c.x; });
      const claro = cand.length && (cand.length === 1 || cand[0].pt < cand[1].pt || cand[0].pt === 0);
      if(claro) comuna = cand[0].x;
    }else{
      // Sin índice se arma la dirección con el nombre escrito
      comuna = {slug: norm(q).replace(/\s+/g, "-"), nombre: q.trim()};
    }
  }
  pintarSugerencias(comuna ? sugerencias.filter(function(s){ return s.slug !== comuna.slug; }).slice(0, 4) : sugerencias, !!comuna);
  if(!comuna){ pintarResultados({sinElegir: true, comuna: q, nada: !sugerencias.length}); return; }

  const res = await Promise.all([clinicasUnoSalud(comuna), clinicasEdental()]);
  if(id !== busquedaId) return;
  const clave = norm(comuna.nombre);
  const ede = res[1], todas = ede.lista || [];
  // Primero las que nombran la comuna en su propia tarjeta. Sólo si no hay
  // ninguna, las que están bajo un título de sección con ese nombre.
  let enComuna = todas.filter(function(c){ return norm(c.texto || "").indexOf(clave) !== -1; });
  let porSeccion = false;
  if(!enComuna.length){
    enComuna = todas.filter(function(c){ return norm(c.contexto || "").indexOf(clave) !== -1; });
    porSeccion = enComuna.length > 0;
  }
  pintarResultados({
    comuna: comuna.nombre,
    uno: res[0],
    ede: {lista: enComuna, error: ede.error, total: todas.length, porSeccion: porSeccion}
  });
}

function pintarSugerencias(lista, hayElegida){
  const c = document.getElementById("sugComunas");
  if(!lista.length){ c.innerHTML = ""; return; }
  c.innerHTML = '<span class="sug-t">' + (hayElegida ? "¿O era…?" : "¿Cuál comuna?") + '</span>' +
    lista.map(function(x){
      return '<button type="button" class="sug" data-slug="' + esc(x.slug) + '" data-nombre="' + esc(x.nombre) + '">' + esc(x.nombre) + '</button>';
    }).join("");
}

function tarjetaHTML(c){
  return '<div class="clin">' +
    '<div class="clin-n">' + esc(c.nombre) + '</div>' +
    (c.direccion ? '<div class="clin-d">' + esc(c.direccion) + '</div>' : '') +
    ((c.telefono || c.horario || c.url) ? '<div class="clin-m">' +
      (c.telefono ? '<span class="dist">' + esc(c.telefono) + '</span>' : '') +
      (c.horario ? '<span class="dist">' + esc(c.horario) + '</span>' : '') +
      (urlSegura(c.url) ? '<a class="fuente" href="' + esc(c.url) + '" target="_blank" rel="noopener">ficha &#8599;</a>' : '') +
    '</div>' : '') +
  '</div>';
}

function bloqueRed(red, comuna, r){
  const nom = RED[red].nombre;
  const lista = r.lista || [];
  let estado;
  if(r.error) estado = "sin respuesta";
  else if(lista.length) estado = lista.length + (lista.length === 1 ? " sucursal" : " sucursales");
  else estado = "ninguna en " + esc(comuna);
  let h = '<div class="redblq"><div class="redcab">' +
    '<span class="red ' + red + '">' + nom + '</span>' +
    '<span class="redn">' + estado + '</span>' +
    '<a class="fuente" href="' + esc(red === "unosalud" && r.url ? r.url : RED[red].sitio) + '" target="_blank" rel="noopener">ver en el sitio &#8599;</a>' +
    '</div>';
  if(r.error){
    h += '<p class="clin-vacio">' + (ESWEB
      ? 'Desde la página web no se pueden consultar otros sitios. En la extensión de Chrome sí.'
      : 'No pude leer el sitio: ' + esc(r.error) + '.') +
      (ESWEB ? '' : ' <button type="button" class="link-carga" data-diag="' + red + '">copiar diagnóstico</button>') + '</p>';
  }else if(!lista.length){
    let motivo;
    if(red === "unosalud" && r.sinPagina) motivo = "Uno Salud no tiene página para esta comuna.";
    else if(red === "edental" && !r.total) motivo = "No encontré el listado de clínicas en el sitio de i-dental.";
    else if(red === "edental") motivo = "El listado de i-dental no tiene clínicas en esta comuna.";
    else motivo = "No encontré sucursales en la página de esta comuna.";
    h += '<p class="clin-vacio">' + motivo +
         (red === "unosalud" && r.sinPagina || red === "edental" && r.total ? '' :
          ' <button type="button" class="link-carga" data-diag="' + red + '">copiar diagnóstico</button>') + '</p>';
  }else{
    if(r.porSeccion){
      h += '<p class="clin-vacio">El sitio no dice la comuna de cada clínica. Éstas aparecen bajo el título <strong>' +
           esc(comuna) + '</strong>: confirma la dirección antes de dársela al cliente.</p>';
    }
    h += lista.map(tarjetaHTML).join("");
  }
  return h + '</div>';
}

function pintarResultados(e){
  const caja = document.getElementById("clinRes");
  if(!e){ caja.innerHTML = ""; return; }
  if(e.cargando){ caja.innerHTML = '<p class="clin-vacio">Buscando sucursales en ' + esc(e.comuna) + '…</p>'; return; }
  if(e.sinElegir){
    caja.innerHTML = e.nada
      ? '<p class="clin-vacio">No encuentro <strong>' + esc(e.comuna) + '</strong> entre las comunas de Uno Salud. Revisa cómo se escribe.</p>'
      : '';
    return;
  }
  caja.innerHTML = '<p class="clin-titulo">Sucursales en <strong>' + esc(e.comuna) + '</strong></p>' +
    bloqueRed("unosalud", e.comuna, e.uno) +
    bloqueRed("edental", e.comuna, e.ede) +
    '<p class="capturado">Leído de unosalud.cl y e-dentalsys.com. Se guarda un día. ' +
    '<button type="button" class="link-carga" id="refrescarRedes">volver a leer</button></p>';
}

async function copiarDiagnostico(red, btn){
  const info = {red: red, cuando: new Date().toISOString(), indice: diag.indice || null, lectura: diag[red] || null};
  const texto = "DIAGNOSTICO BUSCADOR " + red.toUpperCase() + "\n" + JSON.stringify(info, null, 1);
  try{ await navigator.clipboard.writeText(texto); btn.textContent = "copiado: pégalo en el chat"; }
  catch(e){ btn.textContent = "no se pudo copiar"; }
}

function olvidarRedes(cb){
  try{
    chrome.storage.local.get(null, function(todo){
      const claves = Object.keys(todo || {}).filter(function(k){ return k.indexOf("red_") === 0; });
      chrome.storage.local.remove(claves, cb);
    });
  }catch(e){
    try{ Object.keys(localStorage).filter(function(k){ return k.indexOf("red_") === 0; })
           .forEach(function(k){ localStorage.removeItem(k); }); }catch(e2){}
    cb();
  }
}

/* ---------- eventos ---------- */
function confirmarDosToques(btn, aviso, accion){
  if(btn.dataset.armado === "1"){
    btn.dataset.armado = ""; btn.textContent = btn.dataset.original; accion(); return;
  }
  btn.dataset.original = btn.textContent;
  btn.dataset.armado = "1";
  btn.textContent = aviso;
  setTimeout(function(){
    if(btn.dataset.armado === "1"){ btn.dataset.armado = ""; btn.textContent = btn.dataset.original; }
  }, 3500);
}

// Nuevo cliente: todo a cero. Titular solo, Plan Urgencias, sin nada escrito.
function reiniciar(){
  almacen.borrar("estado");
  busquedaId++;
  clearTimeout(temporizador);
  nCargas = 0;
  planElegido = PLAN_POR_DEFECTO;
  planForzado = false;
  guionAbierto = false;
  envio = "linea";
  document.getElementById("hijos").innerHTML = "";
  document.getElementById("comuna").value = "";
  document.getElementById("sugComunas").innerHTML = "";
  document.getElementById("clinRes").innerHTML = "";
  document.getElementById("panelClin").hidden = true;
  document.getElementById("abrirClin").classList.remove("open");
  pintarBloqueCargas();
  marcarEnvio();
  pintarGuardado(null);
  calcular();
}

document.getElementById("ufReload").addEventListener("click", cargarUF);
document.getElementById("ufManual").addEventListener("input", function(){
  const v = parseFloat(this.value.replace(/\./g, "").replace(",", "."));
  if(v > 0){
    const cent = Math.round(v * 100), f = fmt(hoy());
    guardar(cent, f);
    cacheUF = {c: cent, f: f};
    pintarUF(cent, f, ESWEB ? "escrita a mano" : "manual");
    avisarUFVieja();
  }
});
document.getElementById("tieneCargas").addEventListener("change", function(){
  nCargas = this.checked ? Math.max(1, nCargas) : 0;
  pintarBloqueCargas();
  calcular(); guardarEstado();
  if(this.checked){ const ed = document.querySelector("#hijos .edad"); if(ed) ed.focus(); }
});
document.getElementById("conteo").addEventListener("click", function(e){
  const b = e.target.closest("button");
  if(!b) return;
  nCargas = +b.dataset.n;
  pintarBloqueCargas();
  calcular(); guardarEstado();
});
document.getElementById("abrirClin").addEventListener("click", function(){
  const panel = document.getElementById("panelClin");
  const abierto = !panel.hidden;
  panel.hidden = abierto;
  this.classList.toggle("open", !abierto);
  if(!abierto) document.getElementById("comuna").focus();
  guardarEstado();
});
document.getElementById("comuna").addEventListener("input", function(){ alEscribirComuna(); guardarEstado(); });
document.getElementById("comuna").addEventListener("keydown", function(e){
  if(e.key === "Enter"){ e.preventDefault(); clearTimeout(temporizador); if(norm(this.value).length >= 3) buscarComuna(this.value); }
});
document.getElementById("sugComunas").addEventListener("click", function(e){
  const b = e.target.closest("button.sug");
  if(!b) return;
  document.getElementById("comuna").value = b.dataset.nombre;
  guardarEstado();
  buscarComuna(b.dataset.nombre, {slug: b.dataset.slug, nombre: b.dataset.nombre});
});
document.getElementById("clinRes").addEventListener("click", function(e){
  const d = e.target.closest("[data-diag]");
  if(d){ copiarDiagnostico(d.dataset.diag, d); return; }
  if(e.target.closest("#refrescarRedes")){
    olvidarRedes(function(){ buscarComuna(document.getElementById("comuna").value); });
  }
});
document.getElementById("envio").addEventListener("click", function(e){
  const b = e.target.closest("button");
  if(!b) return;
  envio = b.dataset.envio;
  marcarEnvio();
  pintarGuion(); guardarEstado();
});
document.getElementById("tbody").addEventListener("click", function(e){
  const tr = e.target.closest("tr");
  if(!tr || !tr.dataset.plan || tr.classList.contains("veta")) return;
  const porNombre = !!e.target.closest(".nomplan");
  const mismoPlan = (tr.dataset.plan === planElegido);
  planElegido = tr.dataset.plan;
  planForzado = false;
  if(porNombre) guionAbierto = !(guionAbierto && mismoPlan);
  calcular(); guardarEstado();
});
document.getElementById("cerrarGuion").addEventListener("click", function(){
  guionAbierto = false;
  pintarGuion(); guardarEstado();
});
document.getElementById("limpiar").addEventListener("click", function(){
  confirmarDosToques(this, "¿Seguro? Toca otra vez", reiniciar);
});
document.getElementById("copiar").addEventListener("click", function(){
  if(!ultimaCotizacion) return;
  const b = this;
  navigator.clipboard.writeText(ultimaCotizacion).then(function(){
    b.textContent = "Copiado";
    setTimeout(function(){ b.textContent = "Copiar"; }, 1200);
  }, function(){ b.textContent = "No se pudo"; setTimeout(function(){ b.textContent = "Copiar"; }, 1500); });
});

/* ---------- arranque ---------- */
almacen.leer("uf", function(u){
  if(u){ cacheUF = u; if(UF === null) pintarUF(u.c, u.f, ESWEB ? "escrita a mano" : "guardado"); }
  restaurarEstado(function(){ cargarUF(); });
});
marcarEnvio();
pintarBloqueCargas();
calcular();
