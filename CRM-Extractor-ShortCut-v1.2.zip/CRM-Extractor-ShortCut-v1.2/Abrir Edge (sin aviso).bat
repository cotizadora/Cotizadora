@echo off
REM Cierra Edge y lo reabre SIN el aviso de depuracion de la extension.
taskkill /F /IM msedge.exe >nul 2>&1
timeout /t 2 /nobreak >nul
set EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe
if not exist "%EDGE%" set EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe
start "" "%EDGE%" --silent-debugger-extension-api --restore-last-session
exit
