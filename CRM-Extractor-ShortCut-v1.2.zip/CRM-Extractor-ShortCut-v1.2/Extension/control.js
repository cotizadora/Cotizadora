// control.js — Ventana de control MULTI-SITIO.
// Habla con TODAS las pestañas que tengan nuestro bridge (VOCALCOM, CRM Atlas…),
// une sus listas de atajos y enruta cada acción a la pestaña dueña del atajo.
// Los pasos grabados son específicos de cada web, por eso cada sitio guarda los
// suyos; aquí solo se muestran juntos.
'use strict';

const $ = (s) => document.querySelector(s);

let TABS = [];            // [{id, host, url}]
let diag = { lines: [], verdict: '', lastErr: '' };
let editingId = null;     // atajo en edición de nombre (no reconstruir la lista)
let listSig = '';         // firma para no re-renderizar sin cambios
let engineLog = [];       // registro del motor (diagnóstico)
let learningTab = null;   // pestaña que está capturando los clics

// ---------------------------------------------------------------------------
//  Utilidades
// ---------------------------------------------------------------------------
function setStatus(t) { $('#status').textContent = t || ''; }
function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
function labelOf(st) { return (st && st.label) ? st.label : '(sin nombre)'; }
function siteName(host) {
  if (/vocalcom/i.test(host)) return 'VOCALCOM';
  if (/geimser/i.test(host)) return 'CRM';
  if (/peoplework/i.test(host)) return 'PEOPLEWORK';
  return host || '?';
}
// Nombres de sitio SIN repetir: si hay dos pestañas de VOCALCOM, muestra
// "VOCALCOM" una sola vez (no "VOCALCOM + VOCALCOM").
function siteNamesJoined() {
  return [...new Set(TABS.map(t => siteName(t.host)))].join(' + ');
}

// ---------------------------------------------------------------------------
//  Sonido minimalista al pasar el mouse por un atajo (blip suave y elegante).
//  El audio se crea/reanuda con el primer gesto (política de autoplay del
//  navegador); los blips van a volumen muy bajo, muy cortos, y como máximo uno
//  cada ~90 ms para que mover rápido el mouse no lo sature.
// ---------------------------------------------------------------------------
let _actx = null;
let _lastBlip = 0;
function ensureAudio() {
  try {
    if (!_actx) { const AC = window.AudioContext || window.webkitAudioContext; if (AC) _actx = new AC(); }
    if (_actx && _actx.state === 'suspended') _actx.resume();
  } catch (e) {}
}
function hoverBlip() {
  if (dragCtx && dragCtx.moved) return;   // en silencio mientras se arrastra
  ensureAudio();
  if (!_actx) return;
  const now = Date.now();
  if (now - _lastBlip < 90) return;
  _lastBlip = now;
  try {
    const t = _actx.currentTime;
    const osc = _actx.createOscillator();
    const g = _actx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1046, t);                       // Do agudo
    osc.frequency.exponentialRampToValueAtTime(1568, t + 0.05);  // sube suave (elegante)
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.045, t + 0.012);       // volumen bajo
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.13);       // decae rápido
    osc.connect(g); g.connect(_actx.destination);
    osc.start(t); osc.stop(t + 0.14);
  } catch (e) {}
}
document.addEventListener('pointerdown', ensureAudio);
document.addEventListener('keydown', ensureAudio);

function confirmBox(message) {
  return new Promise((res) => {
    const m = $('#modal');
    $('#modal-msg').textContent = message;
    m.style.display = 'flex';
    const done = (v) => { m.style.display = 'none'; $('#modal-yes').onclick = null; $('#modal-no').onclick = null; res(v); };
    $('#modal-yes').onclick = () => done(true);
    $('#modal-no').onclick = () => done(false);
  });
}

// ---------------------------------------------------------------------------
//  Descubrimiento de pestañas conectadas
// ---------------------------------------------------------------------------
// ¿Sigue viva esta ventana? Al RECARGAR la extensión, las ventanas abiertas de
// la instancia anterior quedan huérfanas: chrome.* lanza "Extension context
// invalidated". Hay que detectarlo y parar, no seguir llamando cada 900ms.
function contextAlive() {
  try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
}

function queryTabs(q) {
  return new Promise((r) => {
    try { chrome.tabs.query(q, (t) => r(chrome.runtime.lastError ? [] : (t || []))); }
    catch (e) { r([]); }   // contexto invalidado u otro fallo: no dejar promesa colgada
  });
}
function pingTab(id) {
  return new Promise((res) => {
    try {
      chrome.tabs.sendMessage(id, { type: 'ping' }, { frameId: 0 }, (r) => {
        const e = chrome.runtime.lastError;
        res({ ok: !e && r && r.ok === true, err: e ? e.message : (r ? '' : 'sin respuesta') });
      });
    } catch (ex) { res({ ok: false, err: String(ex) }); }
  });
}
function sendTo(tabId, msg) {
  return new Promise((res) => {
    try {
      chrome.tabs.sendMessage(tabId, msg, { frameId: 0 }, (r) => {
        if (chrome.runtime.lastError) res(null); else res(r);
      });
    } catch (e) { res(null); }
  });
}
async function broadcast(msg) {
  for (const t of TABS) await sendTo(t.id, msg);
}
// Envía a TODAS las pestañas del mismo sitio (mismo siteKey). Así un cambio
// (color, renombrar, borrar, reordenar) queda guardado en todas las pestañas de
// ese sitio y no se “pierde” si la lista se lee de otra pestaña del mismo sitio.
async function sendToSite(host, msg) {
  const sk = siteKey(host);
  const targets = TABS.filter(t => siteKey(t.host) === sk);
  const list = targets.length ? targets : TABS;   // respaldo: si no casa, a todas
  let last = null;
  for (const t of list) last = await sendTo(t.id, msg);
  return last;
}

// Sitios BASE (fijos en el manifest) + sitios agregados por el usuario (dinámicos).
const SITE_BASE_RE = /vocalcomcx\.com|geimser\.cl|peoplework\.cl/i;
const BASE_SITES = ['vocalcomcx.com', 'geimser.cl', 'peoplework.cl'];
let ADDED_SITES = [];            // dominios extra agregados (chrome.storage 'vca_sites')
let currentHost = null;          // dominio registrable de la pestaña activa (para "Agregar este sitio")

function isOurSite(url) {
  if (SITE_BASE_RE.test(url || '')) return true;
  return ADDED_SITES.some((h) => (url || '').indexOf(h) >= 0);
}
function sendToBg(msg) {
  return new Promise((r) => {
    try { chrome.runtime.sendMessage(msg, (resp) => r(chrome.runtime.lastError ? null : resp)); }
    catch (e) { r(null); }
  });
}
function requestSitePermission(pattern) {
  return new Promise((r) => {
    try { chrome.permissions.request({ origins: [pattern] }, (g) => r(!chrome.runtime.lastError && g)); }
    catch (e) { r(false); }
  });
}
// Dominio "registrable" aproximado: app.peoplework.cl -> peoplework.cl;
// foo.example.co.uk -> example.co.uk. Sin librería de TLDs, con heurística simple.
function registrableDomain(hostname) {
  const parts = String(hostname || '').split('.').filter(Boolean);
  if (parts.length <= 2) return hostname || '';
  const sld = parts[parts.length - 2];
  if (['co', 'com', 'net', 'org', 'gob', 'gov', 'edu', 'ac'].includes(sld) && parts.length >= 3) {
    return parts.slice(-3).join('.');
  }
  return parts.slice(-2).join('.');
}
async function currentTabHost() {
  let tabs = await queryTabs({ active: true, lastFocusedWindow: true });
  if (!tabs.length) tabs = await queryTabs({ active: true });
  const t = tabs.find((x) => /^https?:/.test(x.url || ''));
  if (!t) return null;
  try { return registrableDomain(new URL(t.url).hostname); } catch (e) { return null; }
}
async function loadAddedSites() {
  const r = await sendToBg({ type: 'listSites' });
  ADDED_SITES = (r && r.ok && Array.isArray(r.sites)) ? r.sites : [];
  return ADDED_SITES;
}

async function scanTabs() {
  diag = { lines: [], verdict: '', lastErr: '' };
  const all = await queryTabs({});
  let cands = all.filter(t => isOurSite(t.url || t.pendingUrl || ''));
  diag.lines.push('Pestañas: ' + all.length + ' | candidatas (sitios conocidos): ' + cands.length);
  if (!cands.length) { cands = all; diag.lines.push('Sin URLs visibles; ping a todas...'); }

  const found = [];
  for (const t of cands) {
    const { ok, err } = await pingTab(t.id);
    let host = ''; try { host = new URL(t.url || '').hostname; } catch (e) {}
    if (ok) {
      found.push({ id: t.id, host: host, url: t.url || '' });
      diag.lines.push('  OK    tab ' + t.id + '  ' + siteName(host) + '  ' + host);
    } else if (isOurSite(t.url || '')) {
      diag.lines.push('  FALLA tab ' + t.id + '  ' + host + ' -> ' + err);
      diag.lastErr = err;
    }
  }
  diag.verdict = found.length ? 'ok' : 'notab';
  diag.lines.push('CONECTADAS: ' + found.length +
    (found.length ? ' (' + found.map(f => siteName(f.host)).join(', ') + ')' : ''));
  return found;
}

// El ping a todas las pestañas es lo lento: se hace solo cada RESCAN_MS, no en
// cada ciclo. Así las acciones del usuario no quedan detrás de un escaneo.
let lastScan = 0;
const RESCAN_MS = 6000;

// Reúne el estado de TODAS las pestañas conectadas.
async function collect() {
  if (!TABS.length || (Date.now() - lastScan) > RESCAN_MS) {
    TABS = await scanTabs();
    lastScan = Date.now();
  }
  const out = { states: [], armed: null, learning: null, settings: {}, ka: null, log: [] };
  let failed = false;
  const seenStates = new Map();   // firma -> índice en out.states (evita duplicados)
  for (const t of TABS) {
    const r = await sendTo(t.id, { type: 'getData' });
    if (!r) { failed = true; continue; }
    // Varias pestañas del MISMO sitio (incluso de servidores VOCALCOM distintos)
    // reportan la misma lista; al fusionarlas se veían DUPLICADOS. Se muestran UNA
    // sola vez: firma = sitio + nombre + pasos. Si una copia trae color y la ya
    // mostrada no, se adopta el color (para que no se "pierda" entre pestañas).
    (r.states || []).forEach(s => {
      const sig = siteKey(t.host) + '|' + (s.label || s.name || '') + '|' + JSON.stringify(s.steps || []);
      if (seenStates.has(sig)) {
        const idx = seenStates.get(sig);
        if (s.color && !out.states[idx].color) out.states[idx].color = s.color;
        return;
      }
      seenStates.set(sig, out.states.length);
      out.states.push(Object.assign({}, s, { __tab: t.id, __host: t.host }));
    });
    if (r.armed && !out.armed) out.armed = Object.assign({}, r.armed, { __tab: t.id, __host: t.host });
    // De todas las pestañas "grabando", nos quedamos con la que tiene más pasos.
    if (r.learning) {
      const n = (r.learning.steps || []).length;
      const cur = out.learning ? (out.learning.steps || []).length : -1;
      if (n > cur) out.learning = Object.assign({}, r.learning, { __tab: t.id, __host: t.host });
    }
    if (!out.ka && r.ka) out.ka = r.ka;
    Object.assign(out.settings, r.settings || {});
    (r.log || []).forEach(l => out.log.push('[' + siteName(t.host) + '] ' + l));
  }
  if (failed) lastScan = 0;   // alguna pestaña no respondió -> re-escanear ya
  return out;
}

function connectionWarningHtml() {
  return '<div class="warn"><b>Sin pestañas conectadas.</b><br>' +
    'Abre VOCALCOM y/o el CRM Atlas, y pulsa <b>F5</b> en cada una (tras actualizar la ' +
    'extensión el script viejo queda sin conexión).<br>' +
    'Si persiste, da acceso al sitio: clic derecho en el icono → “Este puede leer y cambiar el sitio”.<br>' +
    '<span class="hintline">Último error: ' + (diag.lastErr || '—') + '</span></div>';
}

// ---------------------------------------------------------------------------
//  Lista de atajos
// ---------------------------------------------------------------------------
function sigOf(states, armed) {
  return JSON.stringify((states || []).map(s => [s.id, s.label, (s.steps || []).length, s.__host, s.color || ''])) +
    '|' + (armed ? armed.id : '');
}

// ---------------------------------------------------------------------------
//  ORDEN FIJO Y PREDECIBLE
//  Los atajos NUNCA se reordenan solos: primero por procedencia (Vocal, CRM,
//  Otros) y dentro de cada grupo alfabéticamente. Así cada atajo conserva su
//  posición entre sesiones y se puede memorizar dónde está.
// ---------------------------------------------------------------------------
// Clave de sitio ESTABLE para exportar/importar/distribuir. El host completo
// cambia según el servidor asignado (cdn.s-br01a..., s-br02a...), así que
// agrupamos por dominio conocido; si no, la config de uno no serviría a otro.
function siteKey(host) {
  if (/vocalcomcx\.com/i.test(host || '')) return 'vocalcomcx.com';
  if (/geimser\.cl/i.test(host || '')) return 'geimser.cl';
  if (/peoplework\.cl/i.test(host || '')) return 'peoplework.cl';
  return host || '';
}

function groupRank(host) {
  const s = siteName(host || '');
  if (/vocalcom/i.test(s)) return 0;   // Vocal
  if (/crm/i.test(s)) return 1;        // CRM
  return 2;                            // Otros
}
// Dentro del CRM, agrupa por color: verdes (positivas) juntas, luego rojas,
// luego sin color. Así las positivas quedan SIEMPRE agrupadas.
function colorRank(s) {
  const c = (s && s.color) || '';
  if (c === 'green') return 0;
  if (c === 'red') return 1;
  return 2;   // sin color
}
function sortStates(arr) {
  // Ordena por grupo/sitio (VOCALCOM, luego CRM); dentro del CRM, por color.
  // DENTRO de cada bloque conserva el orden guardado (sort estable → devuelve 0),
  // para poder reordenar a mano arrastrando. Nunca se mezclan los grupos.
  return (arr || []).slice().sort((a, b) => {
    const ga = groupRank(a.__host), gb = groupRank(b.__host);
    if (ga !== gb) return ga - gb;                              // 1º grupo
    const sa = siteName(a.__host || ''), sb = siteName(b.__host || '');
    if (sa !== sb) return sa.localeCompare(sb, 'es');            // 2º sitio
    if (/crm/i.test(sa)) {                                       // 3º color (solo CRM)
      const ca = colorRank(a), cb = colorRank(b);
      if (ca !== cb) return ca - cb;
    }
    return 0;                                                    // mismo bloque: orden guardado
  });
}

// Modelo local para poder pintar cambios AL INSTANTE (sin esperar al servidor).
let lastStates = [];
let lastArmed = null;
// Operaciones del usuario aún en vuelo. Mientras haya alguna, el ciclo periódico
// NO sobrescribe el modelo local (si no, el cambio optimista "revive" porque el
// servidor todavía no lo aplicó). Al terminar, se reconcilia con la verdad.
let pendingOps = 0;
function optimistic(sendPromise) {
  pendingOps++;
  Promise.resolve(sendPromise).then(() => {
    pendingOps = Math.max(0, pendingOps - 1);
    refresh();            // reconciliar con el estado real
  });
}
function paintArmInfo(armed) {
  $('#arminfo').textContent = armed
    ? '⏳ “' + labelOf(armed) + '” en cola: se ejecuta en cuanto se pueda.'
    : '';
}
function renderNow() {
  lastStates = sortStates(lastStates);
  renderList(lastStates, lastArmed);
  listSig = sigOf(lastStates, lastArmed);
  paintArmInfo(lastArmed);
}

function renderList(states, armed) {
  const list = $('#list');
  list.innerHTML = '';
  if (!states || !states.length) {
    list.innerHTML = '<div class="hintline">Aún no hay atajos. Abre <b>⚙️ Configuración → ⏺ Grabar nuevo atajo</b>.</div>';
    return;
  }
  let prevSite = null;
  states.forEach((st) => {
    const on = armed && armed.id === st.id;
    const isVocal = /vocalcom/i.test(st.__host || '');
    const isCRM = /geimser/i.test(st.__host || '');
    // Separador entre plataformas distintas (VOCALCOM / CRM Atlas / PeopleWork / …).
    // Muestra el nombre del grupo para que sea claro dónde empieza cada plataforma.
    const curSite = siteKey(st.__host);
    if (prevSite !== null && curSite !== prevSite) {
      const sep = document.createElement('div');
      sep.className = 'group-sep';
      sep.innerHTML = '<span>' + escapeHtml(siteName(st.__host)) + '</span>';
      list.appendChild(sep);
    } else if (prevSite === null) {
      const sep = document.createElement('div');
      sep.className = 'group-sep first';
      sep.innerHTML = '<span>' + escapeHtml(siteName(st.__host)) + '</span>';
      list.appendChild(sep);
    }
    prevSite = curSite;
    const row = document.createElement('div');
    // Fondo: VOCALCOM siempre celeste; CRM según su color (verde/rojo) o neutro.
    let bgClass = '';
    if (isVocal) bgClass = ' site-vocal';
    else if (isCRM) bgClass = ' color-' + (st.color || 'none');
    row.className = 'sc' + bgClass + (on ? ' on' : '');
    row.dataset.id = st.id;
    row.dataset.site = siteKey(st.__host);            // grupo (sitio)
    row.dataset.color = st.color || '';               // sub-grupo por color (CRM)
    row.addEventListener('mouseenter', hoverBlip);    // sonido minimalista al pasar
    row.addEventListener('pointerdown', (e) => onRowPointerDown(e, st, row));

    const nPasos = st.steps ? st.steps.length : 0;
    const lbl = document.createElement('div');
    lbl.className = 'lbl';
    // Una sola línea: nombre + sitio. Los pasos van en el tooltip para ahorrar alto.
    lbl.innerHTML = (on ? '⏳ ' : '') + escapeHtml(labelOf(st)) +
      ' <span class="mini">· ' + escapeHtml(siteName(st.__host)) + '</span>';
    row.title = labelOf(st) + ' · ' + siteName(st.__host) + ' · ' + nPasos + ' pasos';

    const edit = document.createElement('button');
    edit.textContent = '✏️';
    edit.title = isCRM ? 'Renombrar y elegir color' : 'Renombrar';
    edit.addEventListener('click', () => startRename(lbl, st, isCRM, row));

    const del = document.createElement('button');
    del.className = 'del';
    del.textContent = '✕'; del.title = 'Eliminar';
    del.addEventListener('click', async () => {
      if (!(await confirmBox('¿Eliminar el atajo “' + labelOf(st) + '”?'))) return;
      // INSTANTÁNEO: quitar de la lista y repintar YA; el envío va después.
      lastStates = lastStates.filter(x => x.id !== st.id);
      if (lastArmed && lastArmed.id === st.id) lastArmed = null;
      renderNow();
      optimistic(sendToSite(st.__host, { type: 'deleteState', id: st.id }));
    });

    const play = document.createElement('button');
    play.className = 'play';
    // Sin cola: ▶ (ejecutar). En cola (VOCALCOM): el mismo botón se vuelve ■
    // (detener) y al pulsarlo cancela lo que estaba encolado. Sin botón aparte.
    play.textContent = on ? '■' : '▶';
    play.title = on ? 'En cola — clic para detener' : 'Ejecutar';
    play.addEventListener('click', () => activateShortcut(st));

    row.append(lbl, edit, del, play);
    list.appendChild(row);
  });
}

// Ejecuta / cancela un atajo (lo mismo que el botón ▶/■). Se usa también al hacer
// clic en CUALQUIER zona del botón (no solo en el ▶). Calcula solo si está en cola.
function activateShortcut(st) {
  const on = lastArmed && lastArmed.id === st.id;
  // INSTANTÁNEO: marcar/desmarcar en cola y repintar YA; el envío va después.
  lastArmed = on ? null : { id: st.id, label: st.label, __tab: st.__tab, __host: st.__host };
  renderNow();
  optimistic(sendTo(st.__tab, on ? { type: 'disarm' } : { type: 'arm', id: st.id }));
}

// ---------------------------------------------------------------------------
//  ARRASTRAR PARA REORDENAR (drag & drop) dentro del MISMO grupo/sitio.
//  Se arrastra el botón completo; los demás se apartan con animación y el atajo
//  se suelta en la posición deseada. NUNCA cruza de grupo (VOCALCOM ↔ CRM):
//  el destino se limita a las filas del mismo sitio.
// ---------------------------------------------------------------------------
let dragCtx = null;

function onRowPointerDown(e, st, row) {
  if (e.button != null && e.button !== 0) return;       // solo botón izquierdo
  if (e.target.closest('button, input')) return;         // no arrastrar desde los controles
  if (editingId != null) return;                         // no arrastrar mientras se edita
  const list = $('#list');
  const rows = Array.from(list.querySelectorAll('.sc'));
  // Grupo de arrastre = mismo sitio Y mismo color. Así una verde solo se mueve
  // entre verdes (las positivas quedan siempre agrupadas); VOCALCOM (sin color)
  // se mueve entre todas las de VOCALCOM.
  const group = rows.filter(r => r.dataset.site === row.dataset.site &&
                                 r.dataset.color === row.dataset.color);
  const startIndex = group.indexOf(row);
  if (startIndex < 0) return;
  let step = row.offsetHeight + 6;
  if (group.length > 1) {
    const a = group[0].getBoundingClientRect(), b = group[1].getBoundingClientRect();
    step = Math.abs(b.top - a.top) || step;
  }
  dragCtx = { st, row, group, startIndex, targetIndex: startIndex, step, startY: e.clientY, moved: false };
  window.addEventListener('pointermove', onDragMove);
  window.addEventListener('pointerup', onDragEnd, { once: true });
  window.addEventListener('pointercancel', onDragEnd, { once: true });
}

function onDragMove(e) {
  if (!dragCtx) return;
  const dy = e.clientY - dragCtx.startY;
  if (!dragCtx.moved) {
    if (Math.abs(dy) < 4) return;                         // umbral: distinguir clic de arrastre
    dragCtx.moved = true;
    dragCtx.row.classList.add('dragging');
    document.body.classList.add('dragging-active');
  }
  e.preventDefault();
  dragCtx.row.style.transform = 'translateY(' + dy + 'px) scale(1.03)';
  // Destino: según cuánto se movió, limitado SIEMPRE a los bordes del grupo.
  let ti = dragCtx.startIndex + Math.round(dy / dragCtx.step);
  ti = Math.max(0, Math.min(dragCtx.group.length - 1, ti));
  dragCtx.targetIndex = ti;
  // Apartar las demás filas del grupo para dejar el hueco (animado por CSS).
  dragCtx.group.forEach((r, i) => {
    if (r === dragCtx.row) return;
    let shift = 0;
    if (i > dragCtx.startIndex && i <= ti) shift = -dragCtx.step;
    else if (i < dragCtx.startIndex && i >= ti) shift = dragCtx.step;
    r.style.transform = shift ? 'translateY(' + shift + 'px)' : '';
  });
}

function onDragEnd() {
  window.removeEventListener('pointermove', onDragMove);
  const ctx = dragCtx; dragCtx = null;
  if (!ctx) return;
  document.body.classList.remove('dragging-active');
  if (!ctx.moved) {
    // No hubo arrastre: fue un CLIC en el cuerpo de la fila -> ejecutar el atajo
    // (clic en cualquier zona, no solo en el ▶). Los botones ✏️/✕ ya se
    // excluyeron en onRowPointerDown, así que aquí siempre es el cuerpo.
    ctx.row.classList.remove('dragging'); ctx.row.style.transform = '';
    activateShortcut(ctx.st);
    return;
  }
  const from = ctx.startIndex, to = ctx.targetIndex;
  // Nuevo orden de los ids del grupo tras mover el arrastrado a su destino.
  const groupIds = ctx.group.map(r => r.dataset.id);
  groupIds.splice(to, 0, groupIds.splice(from, 1)[0]);
  // Animación de asentado: la fila baja/sube a su hueco antes de repintar.
  ctx.row.style.transition = 'transform .16s ease';
  ctx.row.style.transform = 'translateY(' + ((to - from) * ctx.step) + 'px) scale(1)';
  setTimeout(() => {
    reorderGroupInLastStates(groupIds);
    renderNow();
    optimistic(sendToSite(ctx.st.__host, { type: 'reorderStates', order: groupIds }));
  }, 160);
}

// Reordena SOLO los atajos cuyos ids están en orderedIds, en ese orden, ocupando
// las MISMAS posiciones que ya ocupaban en la lista (deja el resto intacto). Así
// no descoloca a los de otro color ni a los de otro grupo.
function reorderGroupInLastStates(orderedIds) {
  const set = new Set(orderedIds);
  const byId = {}; lastStates.forEach(s => { if (set.has(s.id)) byId[s.id] = s; });
  const slots = [];
  lastStates.forEach((s, i) => { if (set.has(s.id)) slots.push(i); });
  slots.forEach((slot, k) => { if (byId[orderedIds[k]]) lastStates[slot] = byId[orderedIds[k]]; });
}

function startRename(lbl, st, isCRM, row) {
  editingId = st.id;
  // Ocultar los botones de acción mientras se edita (dejan sitio al editor).
  const hidden = row ? Array.from(row.querySelectorAll('button')) : [];
  hidden.forEach(b => b.style.display = 'none');

  const input = document.createElement('input');
  input.value = st.label || '';
  lbl.innerHTML = ''; lbl.appendChild(input);

  // Color SOLO en el CRM: pequeños botones que cambian el FONDO de la fila al
  // instante. Aparecen únicamente al editar, así la lista queda limpia a diario.
  let picker = null;
  if (isCRM && row) {
    const setBg = (col) => {
      row.classList.remove('color-none', 'color-green', 'color-red');
      row.classList.add('color-' + (col || 'none'));
    };
    const mk = (col, label, title) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'cchip cc-' + (col || 'none') + (((st.color || '') === col) ? ' on' : '');
      b.textContent = label; b.title = title;
      b.addEventListener('mousedown', (e) => e.preventDefault());  // no quitar foco al input
      b.addEventListener('click', () => {
        st.color = col;
        const it = lastStates.find(x => x.id === st.id); if (it) it.color = col;
        setBg(col);
        picker.querySelectorAll('.cchip').forEach(c => c.classList.remove('on'));
        b.classList.add('on');
        optimistic(sendToSite(st.__host, { type: 'setColor', id: st.id, color: col }));
      });
      return b;
    };
    picker = document.createElement('span');
    picker.className = 'colorpick';
    picker.append(
      mk('green', 'Verde', 'Contacto / interesado'),
      mk('red', 'Rojo', 'No contacto / no interesado'),
      mk('', 'Sin color', 'Quitar color')
    );
    row.append(picker);
  }

  input.focus(); input.select();
  let doneOnce = false;
  const finish = (save) => {
    if (doneOnce) return; doneOnce = true;
    const v = input.value.trim();
    editingId = null;
    if (picker) picker.remove();
    if (save && v && v !== st.label) {
      // INSTANTÁNEO: renombrar en el modelo local y repintar YA (re-ordena solo
      // si el nuevo nombre cambia su lugar alfabético); el envío va después.
      const it = lastStates.find(x => x.id === st.id);
      if (it) it.label = v;
      if (lastArmed && lastArmed.id === st.id) lastArmed.label = v;
      renderNow();
      optimistic(sendToSite(st.__host, { type: 'rename', id: st.id, label: v }));
    } else {
      listSig = ''; refresh();
    }
  };
  input.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter') finish(true);
    else if (e.key === 'Escape') finish(false);
  });
  input.addEventListener('blur', () => finish(true));
}

// ---------------------------------------------------------------------------
//  Grabación (se activa en TODAS las pestañas; guarda donde hubo clics)
// ---------------------------------------------------------------------------
function showRecBox(mode) {
  const box = $('#recbox');
  box.className = mode || '';
  $('#rec-recording').style.display = mode === 'recording' ? 'block' : 'none';
  $('#rec-naming').style.display = mode === 'naming' ? 'block' : 'none';
  $('#rec').style.display = mode ? 'none' : 'block';
}

// Nombra el/los sitio(s) conocidos que NO están conectados, para que se vea
// antes de grabar (los clics en una pestaña sin conectar no se capturan).
function missingSiteHtml() {
  const falta = [];
  if (!TABS.some(t => /vocalcom/i.test(t.host || ''))) falta.push('VOCALCOM');
  if (!TABS.some(t => /geimser/i.test(t.host || ''))) falta.push('CRM (Atlas)');
  if (!falta.length) return '';
  return '<br>⚠️ <b>' + falta.join(' y ') + '</b> sin conectar: los clics ahí NO se graban. ' +
         'Abre esa pestaña y pulsa <b>F5</b>.';
}

// Estado del segundo plano en DOS piezas para ahorrar alto: una insignia corta
// que va en la misma línea que los sitios, y un aviso largo SOLO si hay que actuar.
function bgBadge(r) {
  const s = r.settings || {};
  if (s.keepAlive === false) return '⚪ 2° plano off';
  const ka = r.ka;
  if (!ka) return '⚪ 2° plano…';
  const fresh = (Date.now() - (ka.ts || 0)) < 8000;
  if (ka.state === 'running') return fresh ? '🟢 2° plano' : '🟠 2° plano sin latido';
  return '🟠 2° plano suspendido';
}
function bgWarning(r) {
  const s = r.settings || {};
  if (s.keepAlive === false) return '';
  const ka = r.ka;
  if (ka && ka.state !== 'running') {
    return '🟠 Haz <b>un clic en la página</b> de VOCALCOM/CRM para activar el 2° plano.';
  }
  return '';   // todo bien -> vacío -> #bg:empty lo colapsa (no ocupa alto)
}

let lastCount = -1;
let refreshing = false;
async function refresh() {
  // Evita que se solapen ciclos: si ya hay uno en vuelo, este se descarta (la UI
  // ya se pintó de forma optimista y el siguiente ciclo reconcilia igualmente).
  if (refreshing) return;
  refreshing = true;
  try { await refreshInner(); } finally { refreshing = false; }
}

async function refreshInner() {
  const r = await collect();
  engineLog = r.log || engineLog;

  if (!TABS.length) {
    if (editingId == null) { $('#list').innerHTML = connectionWarningHtml(); listSig = ''; }
    setStatus('Sin conexión.');
    return;
  }

  const learn = r.learning;
  learningTab = learn ? learn.__tab : null;

  if (learn && learn.recording) {
    showRecBox('recording');
    $('#reccount').textContent = (learn.steps || []).length;
    // Mostrar SIEMPRE dónde se está capturando: si falta un sitio, los clics
    // que hagas allí no se grabarán y hay que saberlo ANTES de perder el tiempo.
    $('#reccap').innerHTML = 'Capturando en: <b>' +
      escapeHtml(siteNamesJoined() || '—') + '</b>' + missingSiteHtml();
    setStatus('Grabando…');
  } else if (learn && !learn.recording) {
    showRecBox('naming');
    const n = (learn.steps || []).length;
    $('#namecount').textContent = n;
    $('#namesite').textContent = siteName(learn.__host);
    // Si no se capturó nada, decirlo claramente en vez de dejar guardar en vano.
    const vacio = n === 0;
    $('#nameok').style.display = vacio ? 'none' : '';
    $('#namewarn').style.display = vacio ? 'block' : 'none';
    $('#name').style.display = vacio ? 'none' : '';
    $('#save').style.display = vacio ? 'none' : '';
    if ($('#sched-wrap')) $('#sched-wrap').style.display = vacio ? 'none' : '';
    if (vacio) {
      $('#namewarn').innerHTML = '<b>No se capturó ningún clic.</b><br>' +
        'La pestaña donde hiciste los clics no estaba conectada. Pulsa <b>F5</b> en ' +
        'esa pestaña, comprueba arriba que aparezca, y vuelve a grabar.' + missingSiteHtml();
    } else if (lastCount !== n) {
      // Recién detenida: NO auto-rellenar (antes se ponía "Atajo N"). El nombre
      // es OBLIGATORIO: dejamos el campo vacío y con el foco para invitar a
      // escribirlo. Guardar sin nombre queda bloqueado (ver botón Guardar).
      $('#name').value = '';
      try { $('#name').focus(); } catch (e) {}
      // Prepara el bloque de programación para esta grabación (limpio, días todos
      // ON, y el paso de login visible solo si se grabó en PeopleWork).
      prepareSchedUI(learn.__host);
    }
    setStatus(vacio ? 'Grabación vacía.' : 'Grabación detenida. Escríbele un nombre y guarda.');
  } else {
    showRecBox('');
    setStatus('');
  }
  lastCount = learn ? (learn.steps || []).length : -1;

  // Sincroniza con la verdad del servidor SOLO si no hay cambios del usuario en
  // vuelo (si no, pisaríamos lo que acabamos de pintar de forma optimista). Y
  // NUNCA mientras se arrastra (repintar cortaría el arrastre a medias).
  if (pendingOps === 0 && !(dragCtx && dragCtx.moved)) {
    lastStates = sortStates(r.states);
    lastArmed = r.armed;
    if (editingId == null) {
      const sig = sigOf(lastStates, lastArmed);
      if (sig !== listSig) { renderList(lastStates, lastArmed); listSig = sig; }
    }
  }
  paintArmInfo(lastArmed);
}

// ---- Botones de grabación --------------------------------------------------
$('#rec').addEventListener('click', async () => {
  $('#name').value = '';
  await broadcast({ type: 'learnStart' });   // graba en TODAS las pestañas
  listSig = ''; refresh();
});
$('#stop').addEventListener('click', async () => { await broadcast({ type: 'learnStop' }); refresh(); });
$('#cancel1').addEventListener('click', async () => { await broadcast({ type: 'learnCancel' }); listSig = ''; refresh(); });
$('#cancel2').addEventListener('click', async () => { await broadcast({ type: 'learnCancel' }); listSig = ''; refresh(); });
$('#save').addEventListener('click', async () => {
  if (learningTab == null) { setStatus('No hay nada grabado.'); return; }
  const label = $('#name').value.trim();
  // Nombre OBLIGATORIO: sin nombre no se guarda. Se enfoca el campo y parpadea
  // en rojo un instante para dejar claro que hay que escribirlo.
  if (!label) {
    const el = $('#name');
    try { el.focus(); } catch (e) {}
    el.style.borderColor = '#c0392b'; el.style.background = '#fdecea';
    setTimeout(() => { el.style.borderColor = ''; el.style.background = ''; }, 1200);
    setStatus('Escríbele un nombre para guardar.');
    return;
  }
  const r = await sendTo(learningTab, { type: 'learnSave', label: label });
  await broadcast({ type: 'learnCancel' });  // limpia grabaciones vacías en las demás
  // ¿Se marcó "Programar ejecución"? Guardamos el horario asociado al atajo nuevo.
  let schedMsg = '';
  if (r && r.ok && r.id && $('#sched-on') && $('#sched-on').checked) {
    schedMsg = await saveScheduleFor(r.id, label);
  }
  setStatus(r && r.ok ? ('Atajo guardado.' + schedMsg) : 'No se guardó (0 clics grabados).');
  $('#name').value = '';
  if ($('#sched-on')) $('#sched-on').checked = false;
  listSig = ''; refresh();
});

// ===========================================================================
//  PROGRAMACIÓN POR HORARIO
//  Los horarios viven en chrome.storage.local (los lee el service worker aunque
//  el popup esté cerrado). Cada horario referencia un atajo por id + el sitio y
//  la URL a abrir. background.js los dispara a la hora fijada.
// ===========================================================================
const SCHED_KEY = 'vca_schedules';
// dow según Date.getDay(): 0=Dom … 6=Sáb. Orden visual L→D.
const SCHED_DAYS = [
  { dow: 1, l: 'L' }, { dow: 2, l: 'M' }, { dow: 3, l: 'M' }, { dow: 4, l: 'J' },
  { dow: 5, l: 'V' }, { dow: 6, l: 'S' }, { dow: 0, l: 'D' }
];

function storageGet(key) {
  return new Promise((r) => {
    try { chrome.storage.local.get(key, (o) => r(chrome.runtime.lastError ? undefined : o[key])); }
    catch (e) { r(undefined); }
  });
}
function storageSet(obj) {
  return new Promise((r) => {
    try { chrome.storage.local.set(obj, () => r(!chrome.runtime.lastError)); }
    catch (e) { r(false); }
  });
}
async function getSchedules() { const a = await storageGet(SCHED_KEY); return Array.isArray(a) ? a : []; }
async function setSchedules(a) { await storageSet({ [SCHED_KEY]: a }); notifyBgSched(); }
function notifyBgSched() {
  try { chrome.runtime.sendMessage({ type: 'schedChanged' }, () => { void chrome.runtime.lastError; }); } catch (e) {}
}
function genSchedId() { return 'sch_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

function buildDayButtons() {
  const box = $('#sched-days');
  if (!box || box.dataset.built) return;
  box.dataset.built = '1';
  SCHED_DAYS.forEach((d) => {
    const b = document.createElement('div');
    b.className = 'daybtn on';
    b.textContent = d.l;
    b.dataset.dow = d.dow;
    b.addEventListener('click', () => b.classList.toggle('on'));
    box.appendChild(b);
  });
}
function getSelectedDays() {
  return [...document.querySelectorAll('#sched-days .daybtn.on')].map((b) => +b.dataset.dow);
}
function setAllDaysOn() {
  document.querySelectorAll('#sched-days .daybtn').forEach((b) => b.classList.add('on'));
}
function daysLabel(days) {
  if (!days || days.length === 0 || days.length === 7) return 'Todos los días';
  const wk = [1, 2, 3, 4, 5];
  if (days.length === 5 && wk.every((d) => days.includes(d))) return 'Lun a Vie';
  const map = { 0: 'D', 1: 'L', 2: 'M', 3: 'M', 4: 'J', 5: 'V', 6: 'S' };
  return days.slice().sort((a, b) => (a === 0 ? 7 : a) - (b === 0 ? 7 : b)).map((d) => map[d]).join(' ');
}

// Prepara el bloque de programación al entrar a "nombrar" un atajo recién grabado.
// `host` = sitio donde se grabó (decide si mostrar el paso de login, solo PeopleWork).
function prepareSchedUI(host) {
  buildDayButtons();
  if ($('#sched-on')) $('#sched-on').checked = false;
  if ($('#sched-opts')) $('#sched-opts').style.display = 'none';
  setAllDaysOn();
  if ($('#sched-time')) $('#sched-time').value = '';
  const isPW = siteKey(host) === 'peoplework.cl';
  if ($('#sched-login-wrap')) $('#sched-login-wrap').style.display = isPW ? 'block' : 'none';
  const sel = $('#sched-login');
  if (sel) {
    sel.innerHTML = '<option value="">(ninguno)</option>';
    (lastStates || []).filter((s) => siteKey(s.__host) === siteKey(host)).forEach((s) => {
      const o = document.createElement('option');
      o.value = s.id; o.textContent = s.label || '(sin nombre)';
      sel.appendChild(o);
    });
  }
}

// Construye y guarda el horario para el atajo recién creado. Devuelve un sufijo
// para el mensaje de estado (' + programado…' o el motivo de por qué no).
async function saveScheduleFor(shortcutId, label) {
  const time = $('#sched-time') ? $('#sched-time').value : '';
  if (!time) return ' (falta la hora: no se programó).';
  const t = TABS.find((x) => x.id === learningTab);
  const host = t ? t.host : '';
  const sk = siteKey(host);
  const sched = {
    id: genSchedId(),
    shortcutId: shortcutId,
    shortcutLabel: label,
    siteKey: sk,
    host: host,
    openUrl: (t && t.url) || '',
    time: time,
    days: getSelectedDays(),
    loginShortcutId: sk === 'peoplework.cl' && $('#sched-login') ? ($('#sched-login').value || '') : '',
    enabled: true
  };
  const arr = await getSchedules();
  arr.push(sched);
  await setSchedules(arr);
  renderSchedules();
  return ' ⏰ Programado ' + time + ' (' + daysLabel(sched.days) + ').';
}

// id del horario que se está editando en línea (reprogramar hora/días), o null.
let editingSchedId = null;

async function renderSchedules() {
  const box = $('#schedlist');
  if (!box) return;
  const arr = await getSchedules();
  if ($('#schedcount')) $('#schedcount').textContent = arr.length ? '(' + arr.length + ')' : '';
  if (!arr.length) {
    box.innerHTML = '<div class="hintline">No hay horarios. Al grabar un atajo, marca “⏰ Programar ejecución”.</div>';
    editingSchedId = null;
    return;
  }
  box.innerHTML = '';
  arr.forEach((s) => {
    if (editingSchedId === s.id) { box.appendChild(buildSchedEditor(s)); return; }
    const div = document.createElement('div');
    div.className = 'schitem' + (s.enabled ? '' : ' off');
    div.innerHTML =
      '<div class="sch-main"><span class="sch-name"><span class="sch-when">' + escapeHtml(s.time) +
      '</span> · ' + escapeHtml(s.shortcutLabel || '(atajo)') + '</span>' +
      '<span class="sch-sub">' + escapeHtml(siteName(s.host)) + ' · ' + escapeHtml(daysLabel(s.days)) +
      (s.loginShortcutId ? ' · con login' : '') + '</span></div>';
    const bEdit = document.createElement('button');
    bEdit.className = 'sch-edit';
    bEdit.title = 'Reprogramar hora / días';
    bEdit.textContent = '✎';
    bEdit.addEventListener('click', () => { editingSchedId = s.id; renderSchedules(); });
    const bt = document.createElement('button');
    bt.className = 'sch-toggle';
    bt.title = s.enabled ? 'Desactivar' : 'Activar';
    bt.textContent = s.enabled ? '⏸' : '▶';
    bt.addEventListener('click', async () => {
      const a = await getSchedules();
      const it = a.find((x) => x.id === s.id);
      if (it) { it.enabled = !it.enabled; await setSchedules(a); renderSchedules(); }
    });
    const bd = document.createElement('button');
    bd.className = 'sch-del';
    bd.title = 'Eliminar';
    bd.textContent = '✕';
    bd.addEventListener('click', async () => {
      if (!(await confirmBox('¿Eliminar el horario de “' + (s.shortcutLabel || '') + '” (' + s.time + ')?'))) return;
      const a = (await getSchedules()).filter((x) => x.id !== s.id);
      await setSchedules(a);
      renderSchedules();
    });
    div.append(bEdit, bt, bd);
    box.appendChild(div);
  });
}

// Editor en línea para reprogramar la hora y los días de un horario existente.
function buildSchedEditor(s) {
  const wrap = document.createElement('div');
  wrap.className = 'schitem editing';
  wrap.innerHTML =
    '<div style="width:100%">' +
    '<div class="sch-sub" style="margin-bottom:4px">Reprogramar “' + escapeHtml(s.shortcutLabel || '(atajo)') + '”</div>' +
    '<div class="schedrow"><span>Hora:</span><input type="time" class="txt schedtime" value="' + escapeHtml(s.time) + '"></div>' +
    '<div class="dayrow" style="margin-top:6px"></div>' +
    '<div class="row" style="margin-top:6px"><button class="btn primary sch-save">Guardar</button>' +
    '<button class="btn sch-cancel">Cancelar</button></div>' +
    '</div>';
  const timeInput = wrap.querySelector('.schedtime');
  const dayRow = wrap.querySelector('.dayrow');
  SCHED_DAYS.forEach((d) => {
    const b = document.createElement('div');
    const on = !s.days || s.days.length === 0 || s.days.includes(d.dow);
    b.className = 'daybtn' + (on ? ' on' : '');
    b.textContent = d.l;
    b.dataset.dow = d.dow;
    b.addEventListener('click', () => b.classList.toggle('on'));
    dayRow.appendChild(b);
  });
  wrap.querySelector('.sch-cancel').addEventListener('click', () => { editingSchedId = null; renderSchedules(); });
  wrap.querySelector('.sch-save').addEventListener('click', async () => {
    const time = timeInput.value;
    if (!time) { setStatus('Pon una hora válida.'); return; }
    const days = [...dayRow.querySelectorAll('.daybtn.on')].map((b) => +b.dataset.dow);
    const a = await getSchedules();
    const it = a.find((x) => x.id === s.id);
    if (it) {
      it.time = time;
      it.days = days;
      delete it._lastFireKey;   // permite que dispare hoy con la hora nueva
      await setSchedules(a);
    }
    editingSchedId = null;
    renderSchedules();
    setStatus('Horario actualizado: ' + time + ' (' + daysLabel(days) + ').');
  });
  return wrap;
}

if ($('#sched-on')) {
  $('#sched-on').addEventListener('change', () => {
    if ($('#sched-opts')) $('#sched-opts').style.display = $('#sched-on').checked ? 'block' : 'none';
  });
}
// Prueba manual del login e ingreso al dashboard de PeopleWork (sin esperar la
// hora). El service worker abre la pestaña, hace clic en "INICIAR SESIÓN" y
// verifica que llegue a /profile. Reporta el resultado en el estado.
if ($('#test-login')) {
  $('#test-login').addEventListener('click', () => {
    setStatus('Probando login de PeopleWork… (mira la pestaña que se abre)');
    try {
      chrome.runtime.sendMessage({ type: 'testLogin' }, (r) => {
        if (chrome.runtime.lastError) { setStatus('No se pudo iniciar la prueba (recarga la extensión).'); return; }
        setStatus(r && r.ok ? ('✅ ' + (r.msg || 'Login OK.')) : ('⚠️ ' + ((r && r.msg) || 'Falló la prueba.')));
      });
    } catch (e) { setStatus('No se pudo iniciar la prueba.'); }
  });
}
buildDayButtons();
renderSchedules();

// ===========================================================================
//  SITIOS (base + agregados). "Agregar este sitio" pide permiso al navegador y
//  registra los scripts para ese dominio (lo hace el background). Así funciona
//  en cualquier plataforma, con tu aprobación.
// ===========================================================================
async function renderSites() {
  const box = $('#siteslist');
  if (!box) return;
  await loadAddedSites();
  currentHost = await currentTabHost();
  box.innerHTML = '';
  BASE_SITES.forEach((h) => box.appendChild(siteRow(h, true)));
  ADDED_SITES.forEach((h) => box.appendChild(siteRow(h, false)));
  // Botón: habilitado solo si la pestaña actual es un sitio nuevo (no base ni ya agregado).
  const btn = $('#addsite');
  if (btn) {
    const isKnown = !currentHost || BASE_SITES.includes(currentHost) || ADDED_SITES.includes(currentHost);
    btn.textContent = currentHost && !isKnown ? ('➕ Agregar “' + currentHost + '”') : '➕ Agregar este sitio';
    btn.disabled = isKnown;
    btn.style.opacity = isKnown ? '0.55' : '1';
  }
}
function siteRow(host, isBase) {
  const div = document.createElement('div');
  div.className = 'siteitem';
  div.innerHTML = '<span class="site-name">' + escapeHtml(host) +
    ' <span class="site-base">' + (isBase ? '· base' : '· agregado') + '</span></span>';
  if (!isBase) {
    const del = document.createElement('button');
    del.className = 'site-del';
    del.title = 'Quitar sitio';
    del.textContent = '✕';
    del.addEventListener('click', async () => {
      if (!(await confirmBox('¿Quitar el sitio “' + host + '”? Dejará de funcionar ahí.'))) return;
      await sendToBg({ type: 'unregisterSite', host });
      try { chrome.permissions.remove({ origins: ['*://*.' + host + '/*'] }, () => { void chrome.runtime.lastError; }); } catch (e) {}
      setStatus('Sitio quitado: ' + host + '.');
      renderSites();
    });
    div.appendChild(del);
  }
  return div;
}
if ($('#addsite')) {
  $('#addsite').addEventListener('click', async () => {
    // OJO: permissions.request DEBE llamarse en el gesto del clic, sin awaits antes.
    // Por eso currentHost se precalcula en renderSites().
    const host = currentHost;
    if (!host) { setStatus('No pude leer el sitio de la pestaña actual.'); return; }
    if (BASE_SITES.includes(host) || ADDED_SITES.includes(host)) { setStatus('Ese sitio ya está incluido.'); return; }
    const granted = await requestSitePermission('*://*.' + host + '/*');
    if (!granted) { setStatus('Permiso no concedido para ' + host + '.'); return; }
    const r = await sendToBg({ type: 'registerSite', host });
    setStatus(r && r.ok ? ('Sitio agregado: ' + host + '. Recargando la pestaña…') : 'No se pudo registrar el sitio.');
    renderSites();
  });
}
renderSites();

// Reloj en TODAS las páginas: ACTIVO por defecto (clock.js va fijo en el manifest).
// El interruptor solo guarda el flag; no pide permisos (ya vienen en la extensión).
async function initClockAll() {
  const r = await sendToBg({ type: 'getClockAll' });
  if ($('#clockall')) $('#clockall').checked = !(r && r.on === false);
}
if ($('#clockall')) {
  $('#clockall').addEventListener('change', async () => {
    const on = $('#clockall').checked;
    await sendToBg({ type: 'setClockAll', on: on });
    setStatus(on ? 'Reloj visible en todas las páginas.' : 'Reloj solo en Vocalcom.');
  });
}
initClockAll();

// ---- Global ----------------------------------------------------------------
$('#export').addEventListener('click', async () => {
  const r = await collect();
  if (!TABS.length) { setStatus('Sin pestañas conectadas.'); return; }
  const states = (r.states || []).map(s => ({ id: s.id, label: s.label, steps: s.steps, color: s.color || '', site: siteKey(s.__host) }));
  const cfg = { version: 3, exportedAt: new Date().toISOString(), states: states, settings: r.settings || {} };
  const blob = new Blob([JSON.stringify(cfg, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'auto-atajos-config.json';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
  setStatus('Configuración exportada (' + states.length + ' atajos).');
});

$('#import').addEventListener('click', () => $('#file').click());
$('#file').addEventListener('change', async (e) => {
  const f = e.target.files[0]; if (!f) return;
  let cfg; try { cfg = JSON.parse(await f.text()); } catch (err) { setStatus('Archivo JSON inválido.'); return; }
  e.target.value = '';
  if (!Array.isArray(cfg.states)) { setStatus('El archivo no tiene “states”.'); return; }
  if (!(await confirmBox('Importar reemplazará los atajos de los sitios incluidos. ¿Continuar?'))) return;
  // Reparte cada atajo a la pestaña de su sitio.
  let n = 0;
  for (const t of TABS) {
    const mine = cfg.states.filter(s => !s.site || siteKey(s.site) === siteKey(t.host));
    if (!mine.length) continue;
    const r = await sendTo(t.id, { type: 'importConfig', states: mine, settings: cfg.settings || {} });
    if (r && r.ok) n += mine.length;
  }
  setStatus(n ? ('Importados ' + n + ' atajos.') : 'Ningún atajo coincidía con los sitios abiertos.');
  listSig = ''; refresh();
});

// ---- Modo popup anclado al icono -------------------------------------------
// El icono abre el popup anclado (no crea ventana, NO sale en la barra de tareas).
const IS_WINDOW = location.search.indexOf('win=1') >= 0;
const IS_EMBED = location.search.indexOf('embed=1') >= 0;   // (panel flotante, desactivado)
if (IS_WINDOW) document.body.classList.add('aswindow');

// Incrustado (panel flotante): avisar al contenedor nuestro ALTO real para que
// ajuste el iframe al contenido (sin scroll). Se actualiza si la lista cambia.
if (IS_EMBED) {
  const postH = () => {
    try { parent.postMessage({ __vcaHeight: Math.ceil(document.documentElement.scrollHeight) }, '*'); } catch (e) {}
  };
  try { new ResizeObserver(postH).observe(document.documentElement); } catch (e) {}
  window.addEventListener('load', postH);
  setTimeout(postH, 120);
  setTimeout(postH, 600);
}

// ---- Init ------------------------------------------------------------------
function showStaleNotice() {
  const el = $('#list');
  if (el) el.innerHTML =
    '<div class="warn"><b>La extensión se actualizó.</b><br>' +
    'Esta ventana quedó desconectada de la extensión y ya no responde. ' +
    'Ciérrala y vuelve a abrirla con el icono.</div>';
  setStatus('Ventana obsoleta — ciérrala y reábrela.');
}

(async function init() {
  if (!contextAlive()) { showStaleNotice(); return; }
  refresh();
  const timer = setInterval(() => {
    if (!contextAlive()) { clearInterval(timer); showStaleNotice(); return; }
    refresh();
  }, 900);
})();
