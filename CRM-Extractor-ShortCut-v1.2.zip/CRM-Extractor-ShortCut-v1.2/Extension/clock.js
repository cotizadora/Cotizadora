// clock.js — RELOJ-ESPEJO en cualquier página (se registra con permiso "todas las
// páginas"). Lee el estado que Vocalcom dejó en chrome.storage ('vca_clock') y
// dibuja el mismo reloj flotante, arriba de todo. Clic = volver a Disponible (se
// lo pide al service worker, que lo ejecuta en la pestaña de Vocalcom). Así el
// agente ve su tiempo aunque esté distraído en otra web.
(function () {
  'use strict';
  // En Vocalcom NO: ahí ya está el reloj real (content.js). Evita duplicado.
  if (/vocalcomcx\.com/i.test(location.hostname || '')) return;
  if (window.top !== window) return;   // solo frame superior
  // Ahora viene fijo en el manifest (activo por defecto); una instalación vieja
  // podría tenerlo además registrado dinámicamente → nunca dibujar dos relojes.
  if (window.__vcaClockMirror) return;
  window.__vcaClockMirror = true;
  // Interruptor "Mostrar el reloj en todas las páginas": ACTIVO por defecto; solo se
  // apaga si el usuario lo desmarca (vca_clock_all === false).
  let enabled = true;

  let state = null;   // {label,emoji,startedAt,limitMin,ts}
  let box = null, hiddenKey = '', warnFired = false, overFired = false, lastKey = '';

  function beep(times) {
    try {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
      const ctx = new AC(); let t = ctx.currentTime;
      for (let i = 0; i < (times || 1); i++) {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = 'square'; o.frequency.value = 880; g.gain.value = 0.15;
        o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + 0.18); t += 0.28;
      }
      setTimeout(function () { try { ctx.close(); } catch (e) {} }, (times || 1) * 300 + 200);
    } catch (e) {}
  }
  function ensureBox() {
    if (box) return box;
    const b = document.createElement('div');
    b.id = 'vca-clock-mirror';
    b.style.cssText = [
      'position:fixed', 'right:14px', 'bottom:14px', 'z-index:2147483647',
      'min-width:180px', 'padding:10px 12px', 'border-radius:12px',
      'font-family:system-ui,Segoe UI,Arial,sans-serif', 'color:#fff',
      'box-shadow:0 6px 22px rgba(0,0,0,.3)', 'background:#16323b',
      'display:none', 'user-select:none', 'cursor:pointer'
    ].join(';');
    b.title = 'Clic = volver a Disponible';
    b.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px">'
      + '<span data-r="title" style="font-size:12px;font-weight:700"></span>'
      + '<span data-r="close" title="Ocultar" style="cursor:pointer;opacity:.8;font-size:13px">✕</span></div>'
      + '<div data-r="time" style="font-size:26px;font-weight:800;line-height:1.1;margin-top:2px;font-variant-numeric:tabular-nums"></div>'
      + '<div data-r="limit" style="font-size:11px;opacity:.85;margin-top:1px"></div>'
      + '<div style="height:5px;border-radius:3px;background:rgba(255,255,255,.25);margin-top:7px;overflow:hidden">'
      + '<div data-r="bar" style="height:100%;width:0%;background:#fff;transition:width .5s"></div></div>'
      + '<div data-r="go" style="text-align:center;margin-top:8px;padding:5px;border-radius:8px;'
      + 'background:rgba(255,255,255,.18);font-size:11px;font-weight:700;cursor:pointer">▶ Disponible</div>';
    (document.documentElement || document.body).appendChild(b);
    b.querySelector('[data-r="close"]').addEventListener('click', function (ev) {
      ev.stopPropagation(); hiddenKey = lastKey; b.style.display = 'none';
    });
    b.addEventListener('click', function () {
      try { chrome.runtime.sendMessage({ type: 'goDisponible' }, function () { void chrome.runtime.lastError; }); } catch (e) {}
    });
    box = b;
    return b;
  }
  function mmss(sec) {
    const s = Math.max(0, Math.floor(sec));
    return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  }
  function tick() {
    if (!enabled) { if (box) box.style.display = 'none'; return; }
    const c = state;
    const fresh = c && c.ts && (Date.now() - c.ts < 12000);   // Vocalcom sigue vivo
    if (!c || !c.label || !fresh) { if (box) box.style.display = 'none'; lastKey = ''; return; }
    const key = c.label + ':' + c.startedAt;
    if (key !== lastKey) { lastKey = key; warnFired = false; overFired = false; }
    if (hiddenKey === key) { if (box) box.style.display = 'none'; return; }
    const b = ensureBox();
    // Si el panel de la extensión está fijo a la derecha, el reloj se corre a su lado
    // izquierdo para no taparlo.
    const pnl = document.getElementById('vca-panel');
    const pnlRight = pnl && pnl.style.display !== 'none' && (pnl.offsetLeft + pnl.offsetWidth) >= window.innerWidth - 2;
    b.style.right = pnlRight ? (pnl.offsetWidth + 14) + 'px' : '14px';
    const elapsed = (Date.now() - c.startedAt) / 1000;
    const limitSec = (c.limitMin || 0) * 60;
    const pct = limitSec > 0 ? Math.min(100, elapsed / limitSec * 100) : 0;
    const over = limitSec > 0 && elapsed >= limitSec;
    const warn = limitSec > 0 && !over && pct >= 80;
    b.style.display = 'block';
    b.querySelector('[data-r="title"]').textContent = (c.emoji || '') + ' ' + c.label;
    b.querySelector('[data-r="time"]').textContent = mmss(elapsed);
    b.querySelector('[data-r="limit"]').textContent = limitSec > 0 ? ('Límite ' + mmss(limitSec) + (over ? ' · ¡EXCEDIDO!' : '')) : 'Sin límite';
    b.querySelector('[data-r="bar"]').style.width = pct + '%';
    let bg = '#166534', bar = '#4ade80';
    if (warn) { bg = '#9a6a00'; bar = '#fbbf24'; }
    if (over) { const blink = Math.floor(Date.now() / 500) % 2 === 0; bg = blink ? '#b91c1c' : '#7f1d1d'; bar = '#fca5a5'; }
    b.style.background = bg;
    b.querySelector('[data-r="bar"]').style.background = bar;
    if (warn && !warnFired) { warnFired = true; beep(1); }
    if (over && !overFired) { overFired = true; beep(3); }
  }
  function load() {
    try {
      chrome.storage.local.get(['vca_clock', 'vca_clock_all'], function (o) {
        if (chrome.runtime.lastError) return;
        state = (o && o.vca_clock) || null;
        enabled = !(o && o.vca_clock_all === false);
        tick();
      });
    } catch (e) {}
  }
  try {
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== 'local') return;
      if (ch.vca_clock) state = ch.vca_clock.newValue || null;
      if (ch.vca_clock_all) enabled = ch.vca_clock_all.newValue !== false;
      if (ch.vca_clock || ch.vca_clock_all) tick();
    });
  } catch (e) {}
  load();
  setInterval(tick, 1000);
})();
