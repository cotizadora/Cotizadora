// clockpub.js — corre en Vocalcom (TODOS los frames, mundo aislado con chrome.*).
// Su única tarea: recoger el estado del reloj que emite content.js (CustomEvent
// 'vca:clock' en el mismo frame, incluido el frame del panel del agente) y
// guardarlo en chrome.storage, para que el reloj-espejo de otras páginas lo lea.
(function () {
  'use strict';
  document.addEventListener('vca:clock', function (e) {
    try {
      const d = (e && e.detail) || null;
      if (!d) return;
      chrome.storage.local.set({ vca_clock: d }, function () { void chrome.runtime.lastError; });
    } catch (err) {}
  });
  // Número de cada llamada que detecta sc_content.js en el WebSocket de Vocalcom:
  // se lo pasa al service worker (reemplaza la escucha permanente por depurador).
  document.addEventListener('vca:wsphone', function (e) {
    try {
      const p = e && e.detail && e.detail.phone;
      if (p) chrome.runtime.sendMessage({ type: 'VCA_WS_PHONE', phone: p }, function () { void chrome.runtime.lastError; });
    } catch (err) {}
  });
})();
