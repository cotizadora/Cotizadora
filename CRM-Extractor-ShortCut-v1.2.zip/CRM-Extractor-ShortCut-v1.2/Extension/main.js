// main.js — Shell del popup unificado.
// Va en archivo EXTERNO (no en línea) porque las páginas de extensión MV3 bloquean
// el JavaScript inline por CSP (`script-src 'self'`).
//
// Hace cosas puramente de presentación (NO cambian la lógica de las apps):
//  1) Oculta los encabezados internos de los iframes (la marca vive en la barra superior).
//  2) La barra inferior "Enviar a Cotizadora" dispara el botón real del Extractor.
//  3) NO redimensiona el popup → cero parpadeo (alto fijo en CSS).
'use strict';

(function () {
  var extFrame = document.getElementById('extFrame');
  var scFrame  = document.getElementById('scFrame');
  var sendBar  = document.getElementById('sendBar');
  var topBar   = document.getElementById('topBar');
  var bridge   = document.getElementById('sendCotizadoraBridge');

  // Oculta el <header> interno de un iframe (mismo origen) para que el título no se
  // duplique: la marca vive en la barra superior común. No edita las apps; solo
  // inyecta un <style>. Idempotente.
  function hideInnerHeader(fr) {
    try {
      var d = fr.contentDocument;
      if (!d || !d.head || d.getElementById('vca-hdr-hide')) return;
      var st = d.createElement('style');
      st.id = 'vca-hdr-hide';
      // Oculta: (1) el <header> interno duplicado; (2) el botón propio "Enviar a
      // Cotizadora" del Extractor (#btnSendCotizadora) — main.html ya trae la barra
      // roja común abajo, así no aparece DOS veces. El clic sigue funcionando porque
      // el botón oculto responde igual a .click() desde la barra de main.html.
      st.textContent = 'body > header, header:first-of-type { display: none !important; }' +
        '#btnSendCotizadora, #sendCotizadora, .send-cotizadora { display: none !important; }';
      d.head.appendChild(st);
    } catch (e) {}
  }
  // Reenvía un clic de la barra superior al botón real dentro del Extractor.
  function fwdExtClick(id) {
    try { var d = extFrame.contentDocument; var b = d && d.getElementById(id); if (b) b.click(); } catch (e) {}
  }
  var topHistory = document.getElementById('topHistory');
  var topStats   = document.getElementById('topStats');
  if (topHistory) topHistory.addEventListener('click', function () { fwdExtClick('btnViewHistory'); });
  if (topStats)   topStats.addEventListener('click', function () { fwdExtClick('btnViewStats'); });

  // PANEL DENTRO DE LA PÁGINA (main.html?panel=1): fijo al costado derecho. Se puede
  // arrastrar tomándolo con el botón izquierdo desde CUALQUIER zona (salvo botones,
  // campos, filas de atajos o barras de scroll); un clic normal sigue funcionando porque
  // solo cuenta como arrastre si el mouse se mueve >5px apretado. Doble clic en la barra
  // superior = volver a fijarlo a la derecha. ✕ = ocultar (el ícono lo vuelve a abrir).
  // Versión visible en la barra superior: así se sabe al tiro si Edge ya cargó la
  // versión nueva (si no, hay que Recargar la extensión en edge://extensions).
  try {
    var ver = chrome.runtime.getManifest().version;
    var small = document.querySelector('#topBar .brand small');
    if (small && ver) small.textContent += ' · v' + ver;
  } catch (e) {}
  var inPanel = /[?&]panel=1/.test(location.search);
  var topFloat = document.getElementById('topFloat');
  function postParent(kind, extra) {
    try {
      var m = { __vcaPanel: kind };
      if (extra) { m.dx = extra.dx; m.dy = extra.dy; }
      window.parent.postMessage(m, '*');
    } catch (e) {}
  }
  if (inPanel) {
    document.body.classList.add('in-panel');
    if (topFloat) {
      topFloat.style.display = '';
      topFloat.addEventListener('click', function () { postParent('close'); });
    }
    if (topBar) topBar.addEventListener('dblclick', function (e) {
      if (e.target && e.target.closest && e.target.closest('button')) return;
      postParent('dock');
    });
  }
  var NO_DRAG = 'button,input,select,textarea,a,label,summary,option,[contenteditable="true"],' +
    '[draggable="true"],.sc,[data-action],[data-crm-phone],.hcr-line,.daybtn';
  // Mientras el botón está apretado el navegador sigue entregando el movimiento al
  // documento donde empezó el clic (aquí, dentro del panel), así que el arrastre
  // completo se sigue desde aquí y se le avisa a la página cuánto se ha movido.
  var pend = null;      // botón apretado: aún no se sabe si es clic o arrastre
  var dragging = null;  // arrastre en curso: {x, y} = punto donde se apretó
  function onDown(doc, e) {
    if (!inPanel || e.button !== 0) return;
    var t = e.target;
    if (t && t.closest && t.closest(NO_DRAG)) return;
    var root = doc.documentElement;
    if (root && e.clientX >= root.clientWidth) return;            // barra de scroll de la página
    if (t && t.clientWidth && e.offsetX > t.clientWidth) return;   // barra de scroll de un bloque
    pend = { x: e.screenX, y: e.screenY };
  }
  function onMove(e) {
    var st = dragging || pend;
    if (!st) return;
    if (!(e.buttons & 1)) { onUp(); return; }
    var dx = e.screenX - st.x, dy = e.screenY - st.y;
    if (!dragging) {
      if (Math.abs(dx) + Math.abs(dy) < 5) return;
      dragging = pend; pend = null;
      try { var s = e.view && e.view.getSelection && e.view.getSelection(); if (s) s.removeAllRanges(); } catch (x) {}
      postParent('dragStart');
    }
    e.preventDefault();   // que no seleccione texto mientras arrastra
    postParent('dragMove', { dx: dx, dy: dy });
  }
  function onUp() {
    pend = null;
    if (dragging) { dragging = null; postParent('dragEnd'); }
  }
  function hookDrag(doc) {
    if (!inPanel || !doc || doc.__vcaDragHooked) return;
    doc.__vcaDragHooked = true;
    doc.addEventListener('mousedown', function (e) { onDown(doc, e); }, true);
    doc.addEventListener('mousemove', onMove, true);
    doc.addEventListener('mouseup', onUp, true);
  }

  // Alto FIJO en CSS (540px cada iframe) → NO hay redimensión dinámica ni parpadeo.
  // Si el contenido es más alto, el iframe hace scroll interno (overflow: auto).

  // Refleja en la barra si hay datos extraídos (parseResult visible en el Extractor).
  function syncBridge() {
    var hasData = false;
    try {
      var d = extFrame.contentDocument;
      var pr = d && d.getElementById('parseResult');
      hasData = !!(pr && !pr.classList.contains('hidden'));
    } catch (e) { hasData = false; }
    if (bridge) bridge.classList.toggle('dim', !hasData);
  }

  // La barra reutiliza la acción existente: hace clic en el botón real del Extractor.
  if (bridge) {
    bridge.addEventListener('click', function () {
      try {
        var d = extFrame.contentDocument;
        var btn = d && d.getElementById('btnSendCotizadora');
        if (btn) btn.click();
      } catch (e) {}
    });
  }

  function tick() {
    hideInnerHeader(extFrame); hideInnerHeader(scFrame); syncBridge();
    // El arrastre se engancha también dentro de las dos columnas (mismo origen).
    hookDrag(document);
    try { hookDrag(extFrame.contentDocument); hookDrag(scFrame.contentDocument); } catch (e) {}
  }
  setInterval(tick, 1200);  // chequeo más relajado: solo si hay datos extraídos (syncBridge)
  window.addEventListener('load', tick);
  setTimeout(tick, 120);
  tick();
})();
