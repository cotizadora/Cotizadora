// panel.js — PANEL FLOTANTE dentro de la página (Atlas, Vocalcom, etc.).
// Por qué dentro de la página: el popup del ícono no se puede mover, y una ventana
// aparte sale en la barra de tareas, con la barra de depuración encima y se duplicaba
// con el popup. El panel vive en la página: UNO solo, sin esa barra, fijo al costado
// derecho y de alto completo. Se puede arrastrar a los lados (recuerda dónde quedó);
// doble clic en su barra superior lo vuelve a fijar a la derecha.
// Clic FUERA del panel = pasa a segundo plano: se esconde y deja una pestañita ⚡ en el
// borde derecho para volver a abrirlo (como el popup de antes, que se cerraba solo).
// Lo inyecta el service worker a pedido (ícono o cliente extraído); es idempotente.
(function () {
  'use strict';
  if (window.top !== window) return;
  if (window.__vcaPanel) return;          // ya inyectado: solo responde mensajes

  var W = 764, H = 600;
  var wrap = null, frame = null, tab = null, drag = null;
  var docked = true;   // fijo al costado derecho hasta que el usuario lo arrastre

  function clampPos(left) {
    var maxL = Math.max(0, window.innerWidth - Math.min(W, window.innerWidth));
    return { left: Math.min(Math.max(0, left), maxL), top: 0 };
  }
  function place(left, top) {
    // BARRA LATERAL de ALTO COMPLETO: ya no hay tope de 600px (ese era del popup del
    // ícono). Usa todo el alto visible, así se ve todo sin scroll. Solo se desplaza en
    // horizontal: arriba queda siempre pegado al borde superior.
    wrap.style.height = window.innerHeight + 'px';
    var p = clampPos(left);
    wrap.style.left = p.left + 'px';
    wrap.style.top = '0px';
  }
  function dockRight() { place(window.innerWidth, 0); }   // clampPos lo pega al borde derecho
  function savePos() {
    try {
      if (docked) chrome.storage.local.remove('vca_panel_pos');
      else chrome.storage.local.set({ vca_panel_pos: { left: wrap.offsetLeft, top: wrap.offsetTop } });
    } catch (e) {}
  }

  function build() {
    wrap = document.createElement('div');
    wrap.id = 'vca-panel';
    wrap.style.cssText = [
      'position:fixed', 'z-index:2147483646', 'width:' + W + 'px', 'height:' + H + 'px',
      'left:0', 'top:0', 'border-radius:8px', 'overflow:hidden', 'display:none',
      'box-shadow:0 12px 40px rgba(0,0,0,.45)', 'background:#0e1217'
    ].join(';');
    frame = document.createElement('iframe');
    frame.src = chrome.runtime.getURL('main.html?panel=1');
    frame.setAttribute('allow', 'clipboard-read; clipboard-write');   // copiar a Excel
    frame.style.cssText = 'width:100%;height:100%;border:0;display:block;background:#0e1217;';
    wrap.appendChild(frame);
    (document.body || document.documentElement).appendChild(wrap);
    dockRight();
    // Si el usuario lo había dejado en otro lugar, se respeta.
    try {
      chrome.storage.local.get(['vca_panel_pos'], function (o) {
        var p = o && o.vca_panel_pos;
        if (p && typeof p.left === 'number' && typeof p.top === 'number') { docked = false; place(p.left, p.top); }
      });
    } catch (e) {}
  }

  // Pestañita del borde derecho: aparece cuando el panel pasa a segundo plano.
  function ensureTab() {
    if (tab) return tab;
    tab = document.createElement('div');
    tab.id = 'vca-panel-tab';
    tab.title = 'Abrir el panel (CRM Extractor + ShortCut)';
    tab.textContent = '⚡';
    tab.style.cssText = [
      'position:fixed', 'right:0', 'top:38%', 'z-index:2147483646', 'display:none',
      'width:30px', 'height:64px', 'align-items:center', 'justify-content:center',
      'background:#0e1217', 'color:#fbbf24', 'font:18px system-ui,Segoe UI,Arial,sans-serif',
      'border:1px solid #26313d', 'border-right:0', 'border-radius:10px 0 0 10px',
      'box-shadow:0 4px 16px rgba(0,0,0,.35)', 'cursor:pointer', 'opacity:.85', 'user-select:none'
    ].join(';');
    tab.addEventListener('mouseenter', function () { tab.style.opacity = '1'; });
    tab.addEventListener('mouseleave', function () { tab.style.opacity = '.85'; });
    tab.addEventListener('click', function (e) { e.stopPropagation(); show(); });
    (document.body || document.documentElement).appendChild(tab);
    return tab;
  }

  function isVisible() { return !!(wrap && wrap.style.display !== 'none'); }
  function show() {
    if (!wrap) build();
    wrap.style.display = 'block';
    if (tab) tab.style.display = 'none';
    lastActive = document.activeElement;   // el foco que ya estaba no cuenta como "clic fuera"
    if (docked) dockRight(); else place(wrap.offsetLeft, wrap.offsetTop);
  }
  // Ocultar del todo (✕ o ícono): sin pestañita.
  function hide() { if (wrap) wrap.style.display = 'none'; if (tab) tab.style.display = 'none'; }
  // Segundo plano (clic fuera): se esconde y deja la pestañita para volver.
  function collapse() {
    if (!isVisible()) return;
    wrap.style.display = 'none';
    ensureTab().style.display = 'flex';
  }
  function toggle() { if (isVisible()) hide(); else show(); }

  // ── CLIC FUERA → SEGUNDO PLANO ────────────────────────────────────────────
  // Los clics DENTRO del panel ocurren en su iframe y no llegan a esta página, así que
  // cualquier clic aquí es "afuera". No se bloquea: el clic sigue funcionando en la
  // página (se puede usar al tiro).
  document.addEventListener('mousedown', function (e) {
    if (!isVisible() || drag) return;
    if (tab && tab.contains(e.target)) return;
    if (wrap.contains(e.target)) return;
    collapse();
  }, true);

  // ── ARRASTRE ──────────────────────────────────────────────────────────────
  // Mientras el botón está apretado, el navegador entrega el movimiento del mouse al
  // documento donde empezó el clic (dentro del panel). Por eso main.html sigue el
  // arrastre completo y avisa aquí cuánto se movió desde que se apretó; el panel se
  // desplaza exactamente eso.
  function beginDrag() { if (wrap) drag = { left: wrap.offsetLeft, top: wrap.offsetTop }; }
  function moveDrag(dx, dy) { if (drag) place(drag.left + (dx || 0), drag.top + (dy || 0)); }
  function endDrag() {
    if (!drag) return;
    drag = null;
    // Soltado pegado al borde derecho → vuelve a quedar fijo a la derecha.
    docked = (wrap.offsetLeft + wrap.offsetWidth) >= window.innerWidth - 24;
    if (docked) dockRight();
    savePos();
  }
  window.addEventListener('blur', endDrag);
  // Clic dentro de un iframe PROPIO de la página (Vocalcom usa varios): ese clic no llega
  // a este documento, pero el foco pasa a ese iframe. Si el foco CAMBIA a un iframe que
  // no es el nuestro, también es "afuera". (Cambiar de pestaña o de programa no lo esconde.)
  var lastActive = null;
  setInterval(function () {
    if (!isVisible()) return;
    var a = document.activeElement;
    if (a === lastActive) return;
    lastActive = a;
    if (a && a.tagName === 'IFRAME' && a !== frame && !drag) collapse();
  }, 250);
  window.addEventListener('resize', function () {
    if (!isVisible()) return;
    if (docked) dockRight(); else place(wrap.offsetLeft, wrap.offsetTop);
  });

  // Mensajes del propio panel (solo del iframe nuestro).
  window.addEventListener('message', function (e) {
    if (!frame || e.source !== frame.contentWindow) return;
    var d = e.data || {};
    if (d.__vcaPanel === 'close') hide();
    else if (d.__vcaPanel === 'dragStart') beginDrag();
    else if (d.__vcaPanel === 'dragMove') moveDrag(d.dx, d.dy);
    else if (d.__vcaPanel === 'dragEnd') endDrag();
    else if (d.__vcaPanel === 'dock') { docked = true; dockRight(); savePos(); }
  });

  // Órdenes del service worker: mostrar (cliente extraído) o alternar (clic en el ícono).
  try {
    chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
      if (!msg || msg.type !== 'vcaPanel') return;
      if (msg.action === 'show') show();
      else if (msg.action === 'hide') hide();
      else toggle();
      try { reply({ ok: true, visible: isVisible() }); } catch (e) {}
    });
  } catch (e) {}

  window.__vcaPanel = { show: show, hide: hide, toggle: toggle, collapse: collapse };
})();
