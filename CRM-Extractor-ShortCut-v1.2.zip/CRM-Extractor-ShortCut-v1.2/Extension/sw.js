// ══════════════════════════════════════════════════════════════════════════
//  sw.js — SERVICE WORKER UNIFICADO
//  MV3 admite un solo service worker. importScripts() carga los DOS originales
//  en el mismo contexto, SIN modificar la lógica de ninguno:
//   · background.js     → Extractor CRM.
//   · sc_background.js   → ShortCut-VocalCRM (solo cambios de nombre para convivir:
//                          `sleep`→`scSleep` y `content.js`→`sc_content.js`).
//  Sus escuchas (onMessage/onAlarm/onInstalled/…) coexisten porque cada una filtra
//  por tipo de mensaje o nombre de alarma; no comparten identificadores globales.
// ══════════════════════════════════════════════════════════════════════════
importScripts('background.js', 'sc_background.js');

// ══════════════════════════════════════════════════════════════════════════
//  PANEL DENTRO DE LA PÁGINA (panel.js)
//  La UI ya no es el popup del ícono ni una ventana aparte: es un panel dentro de la
//  pestaña, fijo al costado derecho (arrastrable, recuerda posición). UNO solo, sin la
//  barra de depuración encima y sin salir en la barra de tareas. El manifest NO tiene
//  default_popup: el clic en el ícono llega aquí y alterna el panel en la pestaña.
// ══════════════════════════════════════════════════════════════════════════
async function vcaShowPanelInTab(tabId, action) {
  try {
    await chrome.scripting.executeScript({ target: { tabId: tabId }, files: ['panel.js'] });
    // Se llama al panel DIRECTAMENTE (mismo mundo aislado que panel.js), NO por
    // tabs.sendMessage: en Atlas, bridge.js contesta "tipo desconocido" a cualquier
    // mensaje ajeno y ganaba la carrera → se creía que el panel falló, se abría TAMBIÉN
    // el popup del ícono (el que no se mueve) y salía DUPLICADO.
    const res = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      args: [action || 'show'],
      func: function (a) {
        var p = window.__vcaPanel;
        if (!p) return false;
        (p[a] || p.show)();
        return true;
      }
    });
    return !!(res && res[0] && res[0].result);
  } catch (e) { return false; }
}
self.vcaShowPanelInTab = vcaShowPanelInTab;

// Páginas donde el navegador no deja inyectar (edge://, nueva pestaña, tienda de
// extensiones): se abre el popup clásico del ícono solo esa vez.
async function vcaOpenClassicPopup() {
  try { await chrome.action.setPopup({ popup: 'main.html' }); await chrome.action.openPopup(); } catch (e) {}
  setTimeout(function () { chrome.action.setPopup({ popup: '' }).catch(function () {}); }, 800);
}
self.vcaOpenClassicPopup = vcaOpenClassicPopup;

// Si Edge conservó el popup del ícono de una versión anterior (no se reinició), se
// anula aquí en cada arranque: así el clic del ícono SIEMPRE llega a onClicked → panel,
// nunca al popup viejo que no se puede mover.
try { chrome.action.setPopup({ popup: '' }).catch(function () {}); } catch (e) {}

try {
  chrome.action.onClicked.addListener(async function (tab) {
    if (tab && tab.id != null && /^https?:/i.test(tab.url || '')) {
      if (await vcaShowPanelInTab(tab.id, 'toggle')) return;
    }
    vcaOpenClassicPopup();
  });
} catch (e) {}
