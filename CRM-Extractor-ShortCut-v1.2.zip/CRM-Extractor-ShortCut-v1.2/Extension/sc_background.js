// background.js — Service worker. Al pulsar el icono abre (o enfoca) la VENTANA
// de control (ventana propia del navegador, no un popup anclado; no se cierra al
// hacer clic en la pagina). Se ancla arriba a la derecha (cerca de la barra de
// extensiones) y recuerda la ultima posicion donde la dejaste.
'use strict';

const W = 300, H = 460;
let controlWinId = null;

async function getSavedPos() {
  try { const o = await chrome.storage.local.get('ctrlPos'); return o.ctrlPos || null; }
  catch (e) { return null; }
}
async function savePos(w) {
  if (w.left == null) return;
  try { await chrome.storage.local.set({ ctrlPos: { left: w.left, top: w.top, width: w.width, height: w.height } }); }
  catch (e) {}
}

// Busca una ventana de control YA abierta (robusto aunque el service worker se
// haya reiniciado y perdido controlWinId). Evita que se acumulen ventanas.
async function findControlWindow() {
  const base = chrome.runtime.getURL('control.html');
  try {
    const wins = await chrome.windows.getAll({ populate: true });
    for (const w of wins) {
      if ((w.tabs || []).some(t => t.url && t.url.split('?')[0] === base)) return w.id;
    }
  } catch (e) {}
  return null;
}

async function openControl() {
  // Ya abierta (en cualquier ventana) -> enfocar esa, no crear otra
  const existing = await findControlWindow();
  if (existing != null) {
    try { await chrome.windows.update(existing, { focused: true }); controlWinId = existing; return; }
    catch (e) {}
  }
  controlWinId = null;

  const saved = await getSavedPos();
  let left, top, width = W, height = H;
  if (saved) {
    left = saved.left; top = saved.top; width = saved.width || W; height = saved.height || H;
  } else {
    // esquina superior derecha de la ventana del navegador actual
    try {
      const cur = await chrome.windows.getLastFocused();
      left = Math.max(0, (cur.left || 0) + (cur.width || 1280) - W - 16);
      top = Math.max(0, (cur.top || 0) + 72);
    } catch (e) { left = 200; top = 100; }
  }

  const url = chrome.runtime.getURL('control.html?win=1');  // ?win=1 => modo ventana
  try {
    const win = await chrome.windows.create({ url, type: 'popup', width, height, left, top, focused: true });
    controlWinId = win.id;
  } catch (e) {
    const win = await chrome.windows.create({ url, type: 'popup', width: W, height: H });
    controlWinId = win.id;
  }
}

// El icono abre el POPUP ANCLADO (default_popup en el manifest): NO se crea
// ninguna ventana aparte, así nada aparece en la barra de tareas. No enganchamos
// onClicked (con default_popup ni siquiera se dispara) ni abrimos ventanas.
chrome.windows.onRemoved.addListener((id) => { if (id === controlWinId) controlWinId = null; });
if (chrome.windows.onBoundsChanged) {
  chrome.windows.onBoundsChanged.addListener((w) => { if (w.id === controlWinId) savePos(w); });
}

// ---------------------------------------------------------------------------
//  PULSO DE SEGUNDO PLANO
//  El navegador congela los temporizadores de las pestañas en segundo plano.
//  Aquí, desde el service worker (que no está atado a la pestaña), disparamos
//  periódicamente window.__vcaTick() en la pestaña de VOCALCOM con
//  chrome.scripting.executeScript, que se ejecuta aunque la pestaña esté al
//  fondo. Es una red de seguridad ADEMÁS del keep-alive de audio.
//  Nota: alarms tiene un mínimo de ~30s; el keep-alive sigue siendo la vía
//  rápida (~1s) cuando está activo.
// ---------------------------------------------------------------------------
// CONFIABILIDAD: crear cada alarma SOLO si no existe. En MV3 el service worker se
// duerme y se re-evalúa este archivo en cada despertar; si recreáramos la alarma
// cada vez, se REINICIA su cuenta. Como 'vca-pump' (30s) despierta al worker antes
// de que 'vca-sched' (60s) cumpla su minuto, el programador NUNCA disparaba. Las
// alarmas persisten aunque el worker muera, así que basta crearlas una vez.
async function ensurePump() {
  try {
    const pump = await chrome.alarms.get('vca-pump');
    if (!pump) chrome.alarms.create('vca-pump', { periodInMinutes: 0.5 });
    const sched = await chrome.alarms.get('vca-sched');
    if (!sched) chrome.alarms.create('vca-sched', { periodInMinutes: 1 });
  } catch (e) {}
}
// Al instalar/actualizar/recargar la extensión, las ventanas de control abiertas
// quedan HUÉRFANAS (su contexto se invalida y dejan de responder). Las cerramos
// para que no queden ventanas muertas ni inunden el registro de errores.
async function closeStaleControlWindows() {
  const base = chrome.runtime.getURL('control.html');
  try {
    const wins = await chrome.windows.getAll({ populate: true });
    for (const w of wins) {
      if ((w.tabs || []).some(t => t.url && t.url.split('?')[0] === base)) {
        try { await chrome.windows.remove(w.id); } catch (e) {}
      }
    }
  } catch (e) {}
  controlWinId = null;
}

// AUTO-F5: al instalar/actualizar la extensión, el script viejo de las pestañas
// abiertas de VOCALCOM/CRM queda desconectado y habría que pulsar F5 a mano.
// Aquí las recargamos nosotros para que el compañero no tenga que hacer nada.
// Solo recarga pestañas de nuestros sitios (host_permissions); nada más se toca.
async function reloadOurSiteTabs() {
  const patterns = ['*://*.vocalcomcx.com/*', '*://*.geimser.cl/*', '*://*.peoplework.cl/*'];
  for (const pat of patterns) {
    let tabs = [];
    try { tabs = await chrome.tabs.query({ url: pat }); } catch (e) {}
    for (const t of tabs) {
      try { await chrome.tabs.reload(t.id, { bypassCache: false }); } catch (e) {}
    }
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  ensurePump();
  ensureSitesRegistered();   // re-registra los sitios extra que el usuario agregó
  ensureClockOverlay();      // re-registra el reloj-espejo si estaba activado
  closeStaleControlWindows();
  // 'install' (primera vez) y 'update' (nueva versión) dejan el script viejo
  // colgado; en ambos casos recargamos las pestañas de los sitios.
  if (!details || details.reason === 'install' || details.reason === 'update') {
    reloadOurSiteTabs();
  }
});
chrome.runtime.onStartup.addListener(() => { ensurePump(); ensureSitesRegistered(); ensureClockOverlay(); });
ensurePump();
ensureSitesRegistered();
ensureClockOverlay();

async function pumpTick() {
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: '*://*.vocalcomcx.com/*' }); } catch (e) {}
  for (const t of tabs) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: t.id, allFrames: true },
        world: 'MAIN',
        func: () => { try { if (window.__vcaTick) window.__vcaTick(); } catch (e) {} }
      });
    } catch (e) {}
  }
}
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'vca-pump') pumpTick();
  else if (a.name === 'vca-sched') schedTick();
});

// ===========================================================================
//  PROGRAMADOR POR HORARIO
//  Los horarios se guardan en chrome.storage.local (clave 'vca_schedules') desde
//  el popup (control.js). Cada minuto revisamos cuáles vencen y los ejecutamos:
//  buscamos/abrimos la pestaña del sitio, verificamos sesión (PeopleWork) y
//  disparamos el atajo con `applynow` (el mismo camino que el ▶ del popup).
//  Requisito: el navegador debe estar abierto a la hora fijada.
// ===========================================================================
const SCHED_KEY = 'vca_schedules';

const scSleep = (ms) => new Promise((r) => setTimeout(r, ms));

function bgStorageGet(key) {
  return new Promise((r) => {
    try { chrome.storage.local.get(key, (o) => r(chrome.runtime.lastError ? undefined : o[key])); }
    catch (e) { r(undefined); }
  });
}
function bgStorageSet(obj) {
  return new Promise((r) => {
    try { chrome.storage.local.set(obj, () => r(!chrome.runtime.lastError)); }
    catch (e) { r(false); }
  });
}
async function getSchedulesBG() { const a = await bgStorageGet(SCHED_KEY); return Array.isArray(a) ? a : []; }
async function setSchedulesBG(a) { await bgStorageSet({ [SCHED_KEY]: a }); }

function tabsQuery(q) { return new Promise((r) => { try { chrome.tabs.query(q, (t) => r(chrome.runtime.lastError ? [] : (t || []))); } catch (e) { r([]); } }); }
function tabsGet(id) { return new Promise((r) => { try { chrome.tabs.get(id, (t) => r(chrome.runtime.lastError ? null : t)); } catch (e) { r(null); } }); }
function tabsCreate(props) { return new Promise((r) => { try { chrome.tabs.create(props, (t) => r(chrome.runtime.lastError ? null : t)); } catch (e) { r(null); } }); }
function tabsUpdate(id, props) { return new Promise((r) => { try { chrome.tabs.update(id, props, (t) => r(chrome.runtime.lastError ? null : t)); } catch (e) { r(null); } }); }
function sendMsg(tabId, msg) {
  return new Promise((res) => {
    try { chrome.tabs.sendMessage(tabId, msg, { frameId: 0 }, (r) => res(chrome.runtime.lastError ? null : r)); }
    catch (e) { res(null); }
  });
}

// Patrón de URL y URL por defecto por sitio (respaldo si el horario no trae openUrl).
function hostPatternFor(siteKey) {
  if (siteKey === 'peoplework.cl') return '*://*.peoplework.cl/*';
  if (siteKey === 'vocalcomcx.com') return '*://*.vocalcomcx.com/*';
  if (siteKey === 'geimser.cl') return '*://*.geimser.cl/*';
  return '*://*.' + siteKey + '/*';
}
function defaultUrlFor(siteKey) {
  if (siteKey === 'peoplework.cl') return 'https://app.peoplework.cl/profile/dashboard';
  return 'https://' + siteKey + '/';
}

function notify(title, message) {
  try {
    if (!chrome.notifications) return;
    chrome.notifications.create('vca-sched-' + Date.now(), {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icon48.png'),
      title: title || 'ShortCut-VocalCRM',
      message: message || ''
    }, () => { void chrome.runtime.lastError; });
  } catch (e) {}
}

function fireKeyFor(now, s) {
  return now.getFullYear() + '-' + now.getMonth() + '-' + now.getDate() + 'T' + s.time;
}
function isDue(s, now) {
  if (!s || !s.enabled || !s.time) return false;
  const dow = now.getDay();                       // 0=Dom … 6=Sáb
  if (Array.isArray(s.days) && s.days.length && !s.days.includes(dow)) return false;
  const parts = String(s.time).split(':');
  const schedMin = (+parts[0]) * 60 + (+parts[1]);
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const late = nowMin - schedMin;
  if (late < 0 || late > 2) return false;          // ventana de disparo: 0–2 min tras la hora
  if (s._lastFireKey === fireKeyFor(now, s)) return false;   // ya se disparó hoy a esa hora
  return true;
}

let schedRunning = false;
async function schedTick() {
  if (schedRunning) return;
  schedRunning = true;
  try {
    const now = new Date();
    const schedules = await getSchedulesBG();
    const due = schedules.filter((s) => isDue(s, now));
    if (!due.length) return;
    // Marca ANTES de ejecutar (aunque tarde) para no dispararlos dos veces.
    due.forEach((s) => { s._lastFireKey = fireKeyFor(now, s); });
    await setSchedulesBG(schedules);
    for (const s of due) {
      try { await runSchedule(s); } catch (e) {}
    }
  } finally {
    schedRunning = false;
  }
}

async function pingReady(tabId, timeoutMs) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    const r = await sendMsg(tabId, { type: 'ping' });
    if (r && r.ok) return true;
    await scSleep(400);
  }
  return false;
}
async function waitTabComplete(tabId, timeoutMs) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    const tab = await tabsGet(tabId);
    if (!tab) return null;
    if (tab.status === 'complete') return tab;
    await scSleep(400);
  }
  return await tabsGet(tabId);
}
async function waitUrl(tabId, re, timeoutMs) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    const tab = await tabsGet(tabId);
    if (!tab) return false;
    if (re.test(tab.url || '') && tab.status === 'complete') return true;
    await scSleep(400);
  }
  return false;
}
// Dispara un atajo por id en la pestaña (mismo mecanismo que el ▶ del popup).
async function triggerShortcut(tabId, shortcutId) {
  const r = await sendMsg(tabId, { type: 'applynow', id: shortcutId });
  return !!(r && r.ok);
}

// Login INTEGRADO de PeopleWork. El sitio es React: el autocompletado del
// navegador llena el .value del DOM, pero el ESTADO de React sigue vacío, así que
// al enviar sale "Este campo es obligatorio". Antes de pulsar "INICIAR SESIÓN"
// forzamos a React a releer los campos: invalidamos su value-tracker y disparamos
// `input`/`change`; React entonces toma el valor del propio campo. La extensión
// NO lee ni guarda la contraseña: solo dispara eventos; el valor lo lee React del
// DOM. Devuelve true si encontró y pulsó el botón.
async function clickPeopleworkLogin(tabId) {
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      world: 'MAIN',
      func: async () => {
        const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
        const findBtn = () =>
          document.querySelector('button[type="submit"].btn-login') ||
          document.querySelector('button.btn-login[type="submit"]') ||
          document.querySelector('form button.btn-login') ||
          Array.from(document.querySelectorAll('button, input[type="submit"]'))
            .find((b) => /iniciar\s*sesi/i.test(((b.textContent || b.value) || '').trim()));
        // Espera activa (hasta 10s) a que la app React monte el formulario + botón,
        // y a que el navegador autocomplete el usuario. Antes buscábamos demasiado
        // pronto (página aún armándose) y salía "no se encontró el botón".
        let btn = null, login = null, pass = null;
        const t0 = Date.now();
        while (Date.now() - t0 < 10000) {
          login = document.querySelector('input[name="login"]');
          pass = document.querySelector('input[name="password"]');
          btn = findBtn();
          if (btn && login && pass && (login.value || '').trim()) break;
          await sleep(250);
        }
        if (!login || !pass) return { ok: false, reason: 'no-fields' };
        // Un respiro para que el autofill también ponga la clave y avise a React.
        await sleep(500);
        const loginLen = (login.value || '').length;
        const passLen = (pass.value || '').length;
        btn = btn || findBtn();
        if (!btn) return { ok: false, reason: 'no-button', diag: { loginLen, passLen } };
        // IMPORTANTE (comprobado en la página real): NO tocar los campos. El navegador
        // oculta el valor de la clave autocompletada; si disparamos eventos sobre ese
        // campo, React lo lee "vacío" y BORRA lo que el autofill puso → "campo
        // obligatorio". Solo hacemos clic y dejamos que autofill + React resuelvan.
        btn.click();
        return { ok: true, diag: { loginLen, passLen } };
      }
    });
    return (res && res[0] && res[0].result) || { ok: false, reason: 'exec-fail' };
  } catch (e) { return { ok: false, reason: 'exec-error' }; }
}

function isPeopleworkLogin(url) {
  // Login = /login, o la raíz del sitio (sin /profile). Logueado = contiene /profile.
  if (/\/profile/i.test(url)) return false;
  if (/peoplework\.cl\/login/i.test(url)) return true;
  return /peoplework\.cl\/?($|\?)/i.test(url);
}
// Compara dos URLs ignorando el hash y la barra final (para no recargar de más).
function sameUrl(a, b) {
  const norm = (u) => String(u || '').split('#')[0].replace(/\/+$/, '');
  return norm(a) === norm(b);
}

async function runSchedule(s) {
  const pattern = hostPatternFor(s.siteKey);
  const openUrl = s.openUrl || defaultUrlFor(s.siteKey);

  // PeopleWork se abre en PRIMER PLANO: Edge solo autocompleta usuario/clave de
  // forma fiable con la pestaña activa, y el login depende de ese autocompletado.
  // El resto de sitios se abren en segundo plano para no robar el foco al trabajo.
  const openActive = (s.siteKey === 'peoplework.cl');
  let tabs = await tabsQuery({ url: pattern });
  let tab = tabs[0];
  if (!tab) {
    tab = await tabsCreate({ url: openUrl, active: openActive });
    if (!tab) { notify('⏰ ' + (s.shortcutLabel || 'Atajo'), 'No se pudo abrir ' + s.siteKey + '.'); return; }
  } else if (openActive) {
    try { await tabsUpdate(tab.id, { active: true }); } catch (e) {}
  }
  tab = await waitTabComplete(tab.id, 25000);
  if (!tab) { notify('⏰ ' + (s.shortcutLabel || 'Atajo'), 'La pestaña no cargó a tiempo.'); return; }

  // PeopleWork: si cayó en el login, inicia sesión haciendo CLIC en "INICIAR
  // SESIÓN" (usuario y clave los pone el autocompletado del navegador; la
  // extensión NUNCA escribe ni guarda la contraseña). Prioriza el atajo "Login"
  // si el usuario lo asignó; si no, usa el clic integrado al botón conocido.
  // Luego espera el dashboard (/profile).
  if (s.siteKey === 'peoplework.cl' && isPeopleworkLogin(tab.url || '')) {
    await pingReady(tab.id, 15000);
    let lr = { ok: false, diag: {} };
    if (s.loginShortcutId) { const ok = await triggerShortcut(tab.id, s.loginShortcutId); lr = { ok: ok, diag: {} }; }
    if (!lr.ok) lr = await clickPeopleworkLogin(tab.id);

    // Intento automático: espera corta al dashboard.
    let logged = await waitUrl(tab.id, /\/profile/i, 12000);
    if (!logged) {
      // El navegador oculta la clave autocompletada hasta un gesto real del
      // usuario, así que el envío automático puede no entrar. Pedimos UN clic y
      // esperamos hasta 2 min a que la sesión abra; luego seguimos con los comandos.
      const d = lr.diag || {};
      try { await tabsUpdate(tab.id, { active: true }); } catch (e) {}
      notify('⏰ PeopleWork: pulsa INICIAR SESIÓN',
        'Por seguridad, la clave autocompletada necesita un clic tuyo. Púlsalo y ejecuto “' +
        (s.shortcutLabel || '') + '”. (user:' + (d.loginLen || 0) + ' clave:' + (d.passLen || 0) + ')');
      logged = await waitUrl(tab.id, /\/profile/i, 120000);
    }
    if (!logged) {
      notify('⏰ PeopleWork: no se inició sesión', '“' + (s.shortcutLabel || '') + '” no se ejecutó.');
      return;
    }
    tab = (await waitTabComplete(tab.id, 20000)) || tab;

    // Tras el login, PeopleWork aterriza en su dashboard por defecto, que puede NO
    // ser la página donde se grabaron los comandos. Volvemos a la URL grabada para
    // que la reproducción empiece donde corresponde (salvo que esa URL sea el login).
    if (openUrl && !/\/login/i.test(openUrl) && !sameUrl(tab.url || '', openUrl)) {
      try { await tabsUpdate(tab.id, { url: openUrl }); } catch (e) {}
      tab = (await waitTabComplete(tab.id, 20000)) || tab;
    }
  }

  const ready = await pingReady(tab.id, 15000);
  if (!ready) { notify('⏰ ' + (s.shortcutLabel || 'Atajo'), 'La página no respondió; no se ejecutó.'); return; }

  const ran = await triggerShortcut(tab.id, s.shortcutId);
  notify(ran ? '⏰ Atajo disparado' : '⏰ No se pudo disparar',
    (ran ? '▶ ' : '') + (s.shortcutLabel || 'Atajo') + ' — ' + siteLabel(s.siteKey) + ' ' + s.time);
}

function siteLabel(siteKey) {
  if (siteKey === 'peoplework.cl') return 'PeopleWork';
  if (siteKey === 'vocalcomcx.com') return 'VOCALCOM';
  if (siteKey === 'geimser.cl') return 'CRM';
  return siteKey || '';
}

// Prueba manual: abre PeopleWork, inicia sesión (clic en "INICIAR SESIÓN" con el
// autocompletado) y verifica que llegue al dashboard. La activa el botón del popup.
async function testPeopleworkLogin() {
  const siteKey = 'peoplework.cl';
  const openUrl = defaultUrlFor(siteKey);
  let tabs = await tabsQuery({ url: hostPatternFor(siteKey) });
  let tab = tabs[0];
  if (!tab) {
    tab = await tabsCreate({ url: openUrl, active: true });
  } else {
    // Reusa la pestaña y la lleva al dashboard para ejercitar el camino completo.
    try { await tabsUpdate(tab.id, { active: true, url: openUrl }); } catch (e) {}
  }
  if (!tab) return { ok: false, msg: 'No se pudo abrir PeopleWork.' };

  tab = await waitTabComplete(tab.id, 25000);
  if (!tab) return { ok: false, msg: 'La página no cargó a tiempo.' };

  if (isPeopleworkLogin(tab.url || '')) {
    await pingReady(tab.id, 15000);
    const lr = await clickPeopleworkLogin(tab.id);
    const d = lr.diag || {};
    const diagTxt = ' (user:' + (d.loginLen || 0) + ' clave:' + (d.passLen || 0) + ')';
    if (!lr.ok && lr.reason === 'no-button') {
      notify('🔑 Prueba de login', 'No se encontró el botón “INICIAR SESIÓN”.' + diagTxt);
      return { ok: false, msg: 'No se encontró el botón de login.' + diagTxt };
    }
    // Intento automático: espera corta.
    let logged = await waitUrl(tab.id, /\/profile/i, 10000);
    if (!logged) {
      // Diagnóstico clave: si clave:0, el navegador ocultó la clave autocompletada
      // (necesita un clic tuyo). Pedimos ese clic y esperamos.
      notify('🔑 Prueba: pulsa INICIAR SESIÓN',
        (d.passLen === 0
          ? 'El navegador oculta la clave autocompletada hasta que la pulses tú.'
          : 'No entró automáticamente.') + ' Pulsa INICIAR SESIÓN.' + diagTxt);
      logged = await waitUrl(tab.id, /\/profile/i, 60000);
    }
    if (!logged) {
      return { ok: false, msg: 'No llegó al dashboard.' + diagTxt };
    }
    notify('✅ Prueba de login OK', 'Llegó al dashboard.' + diagTxt);
    return { ok: true, msg: 'Login OK: llegó al dashboard.' + diagTxt };
  }

  // Ya estaba logueado: confirma acceso al dashboard.
  notify('✅ PeopleWork', 'Ya estaba con sesión iniciada (dashboard).');
  return { ok: true, msg: 'Ya estaba logueado: dashboard cargado.' };
}

// ===========================================================================
//  SITIOS DINÁMICOS ("úsala en cualquier entorno")
//  Los 3 sitios base (vocalcom, geimser, peoplework) vienen fijos en el manifest.
//  Cualquier OTRO sitio se agrega en runtime: el popup pide el permiso (con tu
//  aprobación) y aquí registramos content.js + bridge.js para ese host. La lista
//  se guarda en chrome.storage ('vca_sites') y se re-registra al iniciar.
// ===========================================================================
function sitePattern(host) { return '*://*.' + host + '/*'; }

async function getSitesBG() { const a = await bgStorageGet('vca_sites'); return Array.isArray(a) ? a : []; }
async function addSiteStored(host) {
  const a = await getSitesBG();
  if (!a.includes(host)) { a.push(host); await bgStorageSet({ vca_sites: a }); }
}
async function removeSiteStored(host) {
  const a = (await getSitesBG()).filter((h) => h !== host);
  await bgStorageSet({ vca_sites: a });
}
function hasPermission(host) {
  return new Promise((r) => {
    try { chrome.permissions.contains({ origins: [sitePattern(host)] }, (g) => r(!chrome.runtime.lastError && g)); }
    catch (e) { r(false); }
  });
}
async function registerSite(host) {
  const pat = sitePattern(host);
  try { await chrome.scripting.unregisterContentScripts({ ids: ['vca-cs-' + host, 'vca-br-' + host] }); } catch (e) {}
  try {
    await chrome.scripting.registerContentScripts([
      { id: 'vca-cs-' + host, matches: [pat], js: ['sc_content.js'], runAt: 'document_start', allFrames: true, world: 'MAIN', persistAcrossSessions: true },
      { id: 'vca-br-' + host, matches: [pat], js: ['bridge.js'], runAt: 'document_start', allFrames: false, persistAcrossSessions: true }
    ]);
    return true;
  } catch (e) { return false; }
}
async function unregisterSite(host) {
  try { await chrome.scripting.unregisterContentScripts({ ids: ['vca-cs-' + host, 'vca-br-' + host] }); } catch (e) {}
}
// Re-registra los sitios guardados cuyo permiso sigue concedido (defensivo, por si
// se perdió el registro). Y limpia de la lista los que ya no tienen permiso.
async function ensureSitesRegistered() {
  const sites = await getSitesBG();
  for (const h of sites) {
    if (await hasPermission(h)) await registerSite(h);
    else { await unregisterSite(h); await removeSiteStored(h); }
  }
}
async function reloadHostTabs(host) {
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: sitePattern(host) }); } catch (e) {}
  for (const t of tabs) { try { await chrome.tabs.reload(t.id, { bypassCache: false }); } catch (e) {} }
}

// Si el usuario revoca el permiso de un sitio, desregistramos sus scripts.
if (chrome.permissions && chrome.permissions.onRemoved) {
  chrome.permissions.onRemoved.addListener(async (perms) => {
    for (const origin of (perms.origins || [])) {
      const m = /:\/\/\*\.([^/]+)\/\*/.exec(origin);
      if (m) { await unregisterSite(m[1]); await removeSiteStored(m[1]); }
    }
  });
}

// ===========================================================================
//  RELOJ-ESPEJO EN TODAS LAS PÁGINAS (clock.js)
//  Se registra en <all_urls> tras aprobar el permiso amplio (opt-in desde el
//  popup). Clic en ese reloj -> "goDisponible" -> se ejecuta en la pestaña de
//  Vocalcom el atajo DISPONIBLE (window.__vcaGoDisponible, expuesto por content.js).
// ===========================================================================
async function registerClockOverlay() {
  try { await chrome.scripting.unregisterContentScripts({ ids: ['vca-clock-overlay'] }); } catch (e) {}
  try {
    await chrome.scripting.registerContentScripts([
      { id: 'vca-clock-overlay', matches: ['*://*/*'], js: ['clock.js'], runAt: 'document_idle', allFrames: false, persistAcrossSessions: true }
    ]);
    return true;
  } catch (e) { return false; }
}
async function unregisterClockOverlay() {
  try { await chrome.scripting.unregisterContentScripts({ ids: ['vca-clock-overlay'] }); } catch (e) {}
}
// El reloj-espejo ahora viene FIJO en el manifest (activo por defecto en todas las
// páginas). Solo quitamos el registro dinámico que dejaron versiones anteriores,
// para que no quede inyectado dos veces. El on/off es solo el flag vca_clock_all.
async function ensureClockOverlay() {
  await unregisterClockOverlay();
}
async function goDisponibleOnVocalcom() {
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: '*://*.vocalcomcx.com/*' }); } catch (e) {}
  for (const t of tabs) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: t.id, allFrames: true }, world: 'MAIN',
        func: () => { try { if (window.__vcaGoDisponible) window.__vcaGoDisponible(); } catch (e) {} }
      });
    } catch (e) {}
  }
}

// El popup avisa cuando cambian los horarios (por si el service worker estaba
// dormido): reafirmamos la alarma. La lista se lee siempre fresca en cada tick.
// También atiende la prueba manual de login y el alta/baja de sitios dinámicos.
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === 'schedChanged') { ensurePump(); reply && reply({ ok: true }); return true; }
  if (msg && msg.type === 'testLogin') {
    testPeopleworkLogin()
      .then((r) => { try { reply(r); } catch (e) {} })
      .catch((e) => { try { reply({ ok: false, msg: 'Error: ' + e }); } catch (e2) {} });
    return true;
  }
  if (msg && msg.type === 'registerSite' && msg.host) {
    (async () => {
      const ok = await registerSite(msg.host);
      if (ok) { await addSiteStored(msg.host); await reloadHostTabs(msg.host); }
      try { reply({ ok }); } catch (e) {}
    })();
    return true;
  }
  if (msg && msg.type === 'unregisterSite' && msg.host) {
    (async () => {
      await unregisterSite(msg.host);
      await removeSiteStored(msg.host);
      try { reply({ ok: true }); } catch (e) {}
    })();
    return true;
  }
  if (msg && msg.type === 'listSites') {
    (async () => { try { reply({ ok: true, sites: await getSitesBG() }); } catch (e) {} })();
    return true;
  }
  if (msg && msg.type === 'goDisponible') {
    goDisponibleOnVocalcom().then(() => { try { reply({ ok: true }); } catch (e) {} });
    return true;
  }
  if (msg && msg.type === 'setClockAll') {
    (async () => {
      await bgStorageSet({ vca_clock_all: !!msg.on });
      try { reply({ ok: true }); } catch (e) {}
    })();
    return true;
  }
  if (msg && msg.type === 'getClockAll') {
    // Activo por defecto: solo "apagado" si el usuario lo desmarcó explícitamente.
    (async () => { try { reply({ ok: true, on: (await bgStorageGet('vca_clock_all')) !== false }); } catch (e) {} })();
    return true;
  }
  return false;
});
