# CRM Extractor Pro — Instrucciones de Instalación

## Archivos incluidos
- manifest.json
- background.js
- content.js
- popup.html / popup.css / popup.js
- icon16.png / icon48.png / icon128.png

## Instalación en Chrome
1. Abre Chrome y ve a: chrome://extensions/
2. Activa "Modo desarrollador" (esquina superior derecha)
3. Haz clic en "Cargar extensión descomprimida"
4. Selecciona la carpeta de esta extensión
5. La extensión aparecerá en la barra del navegador

## Instalación en Edge
1. Abre Edge y ve a: edge://extensions/
2. Activa "Modo de desarrollador" (panel izquierdo)
3. Haz clic en "Cargar desempaquetada"
4. Selecciona la carpeta de esta extensión

## Uso básico
1. Llega una llamada → el discador muestra el número
2. Copia el número → la extensión lo detecta automáticamente
3. El número queda "congelado" en la barra azul superior
4. Busca la empresa en el CRM
5. Con el CRM abierto, haz clic en el ícono de la extensión
6. Presiona "Capturar página actual"
7. La extensión extrae todos los datos automáticamente
8. Presiona "Copiar Excel" o "Guardar"
