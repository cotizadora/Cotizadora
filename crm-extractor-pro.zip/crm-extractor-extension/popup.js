// ══════════════════════════════════════════════════════════════════
//  POPUP.JS — CRM Extractor Pro v3
//  Novedades:
//    · Historial permanente (no se borra salvo acción manual)
//    · Historial diferencia registros completos (azul) e incompletos (amarillo)
//    · Alerta neon si el número ya fue llamado antes
//    · Botón "Pegar teléfono" reemplaza número anterior sin confirmar
//    · Exportar CSV manual + descarga automática a 12:00, 15:00 y 17:45
//    · Importar CSV para restaurar respaldo
// ══════════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────
//  ESTADO GLOBAL
// ─────────────────────────────────────────────
let currentParsed = null;
let currentView   = 'main';
let allRecords    = [];
let activeFilter  = 'all';
let searchQuery   = '';

// ─────────────────────────────────────────────
//  INIT
// ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadFixedPhone();
  loadRecords(() => scheduleAutoExports());
  bindEvents();
  // Auto-pulsar el botón verde en el primer frame tras abrir el popup.
  // Chrome permite clipboard.writeText() dentro de un click() programático
  // disparado en el mismo microtask queue que el gesto de apertura del popup.
  requestAnimationFrame(() => {
    q('btnDetectPhone').click();
  });
});

// ─────────────────────────────────────────────
//  BIND EVENTOS
// ─────────────────────────────────────────────
function bindEvents() {
  // Navegación
  q('btnViewHistory').addEventListener('click', () => showView('history'));
  q('btnViewStats').addEventListener('click',   () => showView('stats'));
  q('btnBackFromHistory').addEventListener('click', () => showView('main'));
  q('btnBackFromStats').addEventListener('click',   () => showView('main'));

  // Paso 1 — teléfono
  q('btnDetectPhone').addEventListener('click', detectFromDialer);
  q('btnSetPhone').addEventListener('click', pegarTelefono);
  q('phoneInput').addEventListener('keydown', e => { if (e.key === 'Enter') pegarTelefono(); });
  q('btnClearPhone').addEventListener('click', limpiarNumero);

  // Paso 2 — captura
  q('btnCapture').addEventListener('click', captureCurrentTab);

  // Resultado
  q('btnDiscardResult').addEventListener('click', discardResult);
  q('btnCopyExcel').addEventListener('click', copyForExcel);
  q('btnCopyText').addEventListener('click',  copyAsText);
  q('btnSaveRecord').addEventListener('click', saveRecord);

  // Manual
  q('btnParseManual').addEventListener('click', parseManual);

  // Historial
  q('btnClearAll').addEventListener('click', clearAll);
  q('btnExportCSV').addEventListener('click', () => exportCSV(false));
  q('btnExportCSVStats').addEventListener('click', () => exportCSV(false));
  q('btnImportCSV').addEventListener('click', () => q('fileImport').click());
  q('fileImport').addEventListener('change', importCSV);
  q('searchInput').addEventListener('input', e => {
    searchQuery = e.target.value.toLowerCase();
    renderHistory();
  });
  document.querySelectorAll('.fbtn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.fbtn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeFilter = btn.dataset.filter;
      renderHistory();
    });
  });
}

function q(id) { return document.getElementById(id); }

// ─────────────────────────────────────────────
//  DETECCIÓN AUTOMÁTICA DESDE EL DISCADOR
//  Inyecta content_dialer.js en la pestaña activa
//  (que debe ser Vocalcom/Hermes360) y extrae el
//  número de teléfono del DOM + fuente HTML.
// ─────────────────────────────────────────────
async function detectFromDialer() {
  const btn = q('btnDetectPhone');
  btn.disabled = true;
  btn.querySelector('span:first-child').textContent = '⏳ Detectando...';

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error('No hay pestaña activa');
    if (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://'))
      throw new Error('No funciona en páginas internas del navegador');

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files:  ['content_dialer.js']
    });

    const res = results && results[0] && results[0].result;

    if (!res || !res.phone) {
      // Mostrar info de debug para ayudar a diagnosticar
      const debugInfo = res && res.debug
        ? `
Debug: sel=${res.debug.fromSelectors}, txt=${res.debug.fromTextNodes}, html=${res.debug.fromHTML}, url=${res.debug.fromURL}`
        : '';
      throw new Error('No se encontró número en esta página' + debugInfo);
    }

    // Número encontrado — fijarlo Y copiar al portapapeles
    const num = res.phone;
    chrome.storage.local.set({ fixedPhone: num }, async () => {
      mostrarNumeroFijado(num);
      verificarDuplicado(num);
      // Copiar al portapapeles para pegar directo en el CRM
      try {
        await navigator.clipboard.writeText(num);
        showToast('✔ ' + num + ' — copiado al portapapeles ✓', 'ok');
      } catch(e) {
        showToast('✔ Número fijado: ' + num + ' (copia manual)', 'ok');
      }
    });

  } catch (err) {
    showToast('✖ ' + err.message, 'err');
  } finally {
    btn.disabled = false;
    btn.querySelector('span:first-child').textContent = '📞 Detectar desde discador';
  }
}

// ─────────────────────────────────────────────
//  PASO 1 — PEGAR TELÉFONO
//  Pega desde portapapeles O toma lo escrito.
//  Reemplaza siempre el número anterior sin pedir confirmación.
//  Verifica duplicados en el historial al instante.
// ─────────────────────────────────────────────
async function pegarTelefono() {
  let num = q('phoneInput').value.trim();

  // Si el campo está vacío, intentar leer del portapapeles
  if (!num) {
    try {
      num = (await navigator.clipboard.readText()).trim();
    } catch(e) { /* permiso denegado */ }
  }

  if (!num) { showToast('✖ Escribe o copia un número primero', 'err'); return; }

  // Normalizar: eliminar espacios/guiones extra
  num = num.replace(/[\s\-().]/g, '').replace(/^0056/, '+56');
  if (!num.startsWith('+')) {
    if (num.startsWith('56') && num.length >= 11) num = '+' + num;
    else if (num.length === 9) num = '+569' + num.slice(1); // 9XXXXXXXX
  }

  chrome.storage.local.set({ fixedPhone: num }, () => {
    mostrarNumeroFijado(num);
    q('phoneInput').value = '';
    verificarDuplicado(num);
  });
}

function limpiarNumero() {
  chrome.storage.local.remove('fixedPhone', () => {
    q('phoneSaved').classList.add('hidden');
    q('dupeAlert').classList.add('hidden');
    q('phoneInput').value = '';
    if (currentParsed) { currentParsed.phoneOriginal = ''; q('fPhone').textContent = '(sin número)'; }
  });
}

function mostrarNumeroFijado(num) {
  q('phoneSavedDisplay').textContent = num;
  q('phoneSaved').classList.remove('hidden');
}

function loadFixedPhone() {
  chrome.storage.local.get(['fixedPhone'], data => {
    if (data.fixedPhone) {
      mostrarNumeroFijado(data.fixedPhone);
      verificarDuplicado(data.fixedPhone);
    }
  });
}

function getFixedPhone(cb) {
  chrome.storage.local.get(['fixedPhone'], data => cb(data.fixedPhone || ''));
}

// Verifica si el número ya está en el historial
function verificarDuplicado(num) {
  const alert = q('dupeAlert');
  if (!num) { alert.classList.add('hidden'); return; }
  const clean = num.replace(/\D/g,'');
  const dupe = allRecords.some(r => {
    const rclean = (r.phoneOriginal||'').replace(/\D/g,'');
    return rclean && rclean === clean;
  });
  if (dupe) {
    alert.classList.remove('hidden');
  } else {
    alert.classList.add('hidden');
  }
}

// ─────────────────────────────────────────────
//  PASO 2 — CAPTURA DE PESTAÑA ACTIVA
// ─────────────────────────────────────────────
async function captureCurrentTab() {
  const btn = q('btnCapture');
  btn.disabled = true;
  btn.querySelector('span:last-child').textContent = 'Extrayendo...';
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error('No hay pestaña activa');
    if (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://'))
      throw new Error('No se puede capturar páginas internas del navegador');

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files:  ['content.js']
    });
    const payload = results && results[0] && results[0].result;
    if (!payload || !payload.text) throw new Error('No se pudo extraer texto de la página');

    const parsed = parseAtlas(payload.text);
    parsed.sourceUrl   = payload.url;
    parsed.sourceTitle = payload.title;
    parsed.capturedAt  = Date.now();

    getFixedPhone(phone => {
      parsed.phoneOriginal = phone;
      showParsedResult(parsed);
    });
  } catch (err) {
    showToast('✖ ' + err.message, 'err');
  } finally {
    btn.disabled = false;
    btn.querySelector('span:last-child').textContent = 'Extraer desde CRM';
  }
}

// ─────────────────────────────────────────────
//  PARSER ATLAS
// ─────────────────────────────────────────────
function parseAtlas(text) {
  const d = { phoneOriginal:'', razonSocial:'', rut:'', rubro:'', actividad:'', segmento:'', telefonoCRM:'', correo:'' };

  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  const map = {};
  const KNOWN = [
    'razón social','razon social','nombre empresa','empresa',
    'rut empresa','rut',
    'dirección empresa','direccion empresa','dirección','direccion',
    'teléfono','telefono','fono','celular','móvil','movil',
    'correo','correo electrónico','correo electronico','email','e-mail',
    'rubro','industria','giro',
    'actividad','actividad económica','actividad economica',
    'segmento','tamaño empresa','tamano empresa',
    'observación inicial','observacion inicial',
    'observación actual','observacion actual',
    'tipificación actual','tipificacion actual',
    'estado lead','intentos'
  ];
  for (let i = 0; i < lines.length - 1; i++) {
    const key = lines[i].toLowerCase().replace(/:$/, '').trim();
    if (KNOWN.includes(key) && !map[key]) map[key] = lines[i + 1];
  }

  function fm(...keys) { for (const k of keys) if (map[k]) return map[k].trim(); return ''; }
  function fr(...pats) { for (const p of pats) { const m = text.match(p); if (m && m[1]) return m[1].trim(); } return ''; }

  d.razonSocial = fm('razón social','razon social','nombre empresa','empresa') ||
                  fr(/Razón social\s*\n([^\n]+)/i, /razón social\s*[:\-]\s*(.+)/i);
  d.rut = fm('rut empresa','rut') ||
          fr(/RUT empresa\s*\n([^\n]+)/i, /\b(\d{1,2}\.?\d{3}\.?\d{3}-[\dkK])\b/);
  if (d.rut) d.rut = d.rut.trim();

  const telRaw = fm('teléfono','telefono','fono','celular','móvil','movil') ||
                 fr(/\b(\+56\s?9\s?\d{4}\s?\d{4})\b/, /\b(\+56\s?[2-8]\s?\d{7,8})\b/, /\b(9\d{8})\b/);
  d.telefonoCRM = (telRaw && !/sin\s*tel[eé]fono/i.test(telRaw)) ? telRaw.replace(/\s/g,'') : '';

  d.correo = fm('correo','correo electrónico','correo electronico','email','e-mail') ||
             fr(/\b([\w.+\-]+@[\w.\-]+\.[a-z]{2,})\b/i);
  d.rubro    = fm('rubro','industria','giro') || fr(/rubro\s*[:\-]\s*(.+)/i, /giro\s*[:\-]\s*(.+)/i);
  d.actividad= fm('actividad','actividad económica','actividad economica') || fr(/actividad(?:\s+econ[oó]mica)?\s*[:\-]?\s*\n?([^\n]+)/i);
  d.segmento = fm('segmento','tamaño empresa','tamano empresa') ||
               fr(/segmento\s*[:\-]\s*(.+)/i) || inferSegmento(text);
  return d;
}

function inferSegmento(text) {
  const m = text.match(/Horizont\s+P(\d+)/i);
  if (m) { const p=parseInt(m[1]); if(p===1)return'GRANDE';if(p===2)return'MEDIANA';if(p===3)return'PEQUEÑA'; }
  const s = text.match(/\b(MICRO|PEQUEÑA?|MEDIANA?|GRANDE|CORPORATIVO|PYME)\b/i);
  return s ? s[1].toUpperCase() : '';
}

// ─────────────────────────────────────────────
//  MOSTRAR RESULTADO
// ─────────────────────────────────────────────
function showParsedResult(parsed) {
  currentParsed = parsed;
  q('fPhone').textContent       = parsed.phoneOriginal || '(sin número fijado)';
  q('fRazonSocial').textContent = parsed.razonSocial   || '—';
  q('fRut').textContent         = parsed.rut           || '—';
  q('fRubro').textContent       = parsed.rubro         || '—';
  q('fActividad').textContent   = parsed.actividad     || '—';
  q('fSegmento').textContent    = parsed.segmento      || '—';
  q('fTelCRM').textContent      = parsed.telefonoCRM   || '—';
  q('fCorreo').textContent      = parsed.correo        || '—';
  q('parseResult').classList.remove('hidden');
  showView('main');
  // Auto-guardar en historial
  autoSaveRecord(parsed);
  // Auto-copiar como Excel al portapapeles
  autoCopyExcel(parsed);
}

// Auto-guardar silenciosamente al extraer datos
function autoSaveRecord(parsed) {
  const now    = new Date();
  const isComplete = !!(parsed.razonSocial && parsed.rut);
  const record = {
    id:            Date.now().toString(36) + Math.random().toString(36).slice(2),
    timestamp:     Date.now(),
    fecha:         now.toLocaleDateString('es-CL'),
    hora:          now.toLocaleTimeString('es-CL', {hour:'2-digit',minute:'2-digit'}),
    phoneOriginal: parsed.phoneOriginal  || '',
    razonSocial:   parsed.razonSocial    || '',
    rut:           parsed.rut            || '',
    rubro:         parsed.rubro          || '',
    actividad:     parsed.actividad      || '',
    segmento:      parsed.segmento       || '',
    telefonoCRM:   parsed.telefonoCRM    || '',
    correo:        parsed.correo         || '',
    sourceUrl:     parsed.sourceUrl      || '',
    isComplete:    isComplete
  };
  chrome.runtime.sendMessage({ type: 'SAVE_RECORD', record }, res => {
    if (res && res.ok) {
      allRecords.unshift(record);
      // Liberar número fijado tras guardar
      chrome.storage.local.remove('fixedPhone');
      q('phoneSaved').classList.add('hidden');
      q('dupeAlert').classList.add('hidden');
    }
  });
}

async function autoCopyExcel(parsed) {
  const hoy = new Date().toLocaleDateString('es-CL');
  const tsv = [
    hoy,
    parsed.razonSocial    || '',
    parsed.rut            || '',
    parsed.phoneOriginal  || parsed.telefonoCRM || '',
    parsed.correo         || '',
    '',
    ''
  ].join('\t');
  try {
    await navigator.clipboard.writeText(tsv);
    showToast('✔ Datos copiados — pega en Excel con Ctrl+V', 'ok');
  } catch(e) {
    // silencioso si falla
  }
}

function discardResult() {
  currentParsed = null;
  q('parseResult').classList.add('hidden');
  q('manualText').value = '';
}

// ─────────────────────────────────────────────
//  EXPORTACIÓN
// ─────────────────────────────────────────────
function copyForExcel() {
  if (!currentParsed) return;
  const p = currentParsed;
  const hoy = new Date().toLocaleDateString('es-CL');
  const tsv = [hoy, p.razonSocial, p.rut, p.phoneOriginal||p.telefonoCRM, p.correo, '', ''].join('\t');
  navigator.clipboard.writeText(tsv)
    .then(() => showToast('✔ Copiado — pega en Excel con Ctrl+V','ok'))
    .catch(() => showToast('✖ Error al copiar','err'));
}

function copyAsText() {
  if (!currentParsed) return;
  const p = currentParsed, now = new Date();
  const txt = `Número discador: ${p.phoneOriginal||'—'}\nEmpresa:         ${p.razonSocial||'—'}\nRUT:             ${p.rut||'—'}\nRubro:           ${p.rubro||'—'}\nActividad:       ${p.actividad||'—'}\nSegmento:        ${p.segmento||'—'}\nTel. CRM:        ${p.telefonoCRM||'—'}\nCorreo:          ${p.correo||'—'}\nFecha:           ${now.toLocaleDateString('es-CL')}\nHora:            ${now.toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit'})}`;
  navigator.clipboard.writeText(txt)
    .then(() => showToast('✔ Copiado','ok'))
    .catch(() => showToast('✖ Error','err'));
}

// ─────────────────────────────────────────────
//  GUARDAR REGISTRO
//  Siempre guarda — con datos completos o solo el número.
//  isComplete = tiene razón social y RUT.
// ─────────────────────────────────────────────
function saveRecord() {
  if (!currentParsed) return;
  _doSave(currentParsed, true);
}

function _doSave(parsed, releasePhone) {
  const now    = new Date();
  const isComplete = !!(parsed.razonSocial && parsed.rut);
  const record = {
    id:            Date.now().toString(36) + Math.random().toString(36).slice(2),
    timestamp:     Date.now(),
    fecha:         now.toLocaleDateString('es-CL'),
    hora:          now.toLocaleTimeString('es-CL', {hour:'2-digit',minute:'2-digit'}),
    phoneOriginal: parsed.phoneOriginal  || '',
    razonSocial:   parsed.razonSocial    || '',
    rut:           parsed.rut            || '',
    rubro:         parsed.rubro          || '',
    actividad:     parsed.actividad      || '',
    segmento:      parsed.segmento       || '',
    telefonoCRM:   parsed.telefonoCRM    || '',
    correo:        parsed.correo         || '',
    sourceUrl:     parsed.sourceUrl      || '',
    isComplete:    isComplete
  };

  chrome.runtime.sendMessage({ type: 'SAVE_RECORD', record }, res => {
    if (res && res.ok) {
      allRecords.unshift(record);
      showToast(`✔ Guardado (total: ${res.total})`, 'ok');
      if (releasePhone) {
        setTimeout(() => {
          chrome.storage.local.remove('fixedPhone');
          q('phoneSaved').classList.add('hidden');
          q('dupeAlert').classList.add('hidden');
          discardResult();
        }, 600);
      }
    }
  });
}

// ─────────────────────────────────────────────
//  GUARDAR SOLO NÚMERO (sin datos CRM)
//  Se llama desde el botón "Pegar teléfono" cuando
//  no hay extracción pendiente. Registra la llamada
//  como "incompleta" en el historial.
// ─────────────────────────────────────────────
function guardarSoloNumero(num) {
  if (!num) return;
  _doSave({ phoneOriginal: num, razonSocial:'', rut:'', rubro:'', actividad:'', segmento:'', telefonoCRM:'', correo:'', sourceUrl:'' }, false);
}

// ─────────────────────────────────────────────
//  PARSEO MANUAL
// ─────────────────────────────────────────────
function parseManual() {
  const text = q('manualText').value.trim();
  if (!text) { showToast('✖ Pega texto antes de extraer','err'); return; }
  const parsed = parseAtlas(text);
  parsed.capturedAt = Date.now();
  getFixedPhone(phone => { parsed.phoneOriginal = phone; showParsedResult(parsed); });
}

// ─────────────────────────────────────────────
//  HISTORIAL
// ─────────────────────────────────────────────
function loadRecords(cb) {
  chrome.storage.local.get(['records'], data => {
    allRecords = data.records || [];
    // Mostrar count en botón historial
    const btn = q('btnViewHistory');
    if (btn && allRecords.length > 0) {
      btn.textContent = '📋 ' + allRecords.length;
      btn.title = allRecords.length + ' registros en historial';
    }
    if (cb) cb();
  });
}

function getFilteredRecords() {
  const now = Date.now(), day = 86400000;
  let f = allRecords;
  if (activeFilter === 'today') {
    const sod = new Date(); sod.setHours(0,0,0,0);
    f = f.filter(r => r.timestamp >= sod.getTime());
  } else if (activeFilter === '7d')  { f = f.filter(r => r.timestamp >= now - 7*day); }
  else if (activeFilter === '30d') { f = f.filter(r => r.timestamp >= now - 30*day); }
  if (searchQuery) {
    f = f.filter(r =>
      (r.phoneOriginal||'').toLowerCase().includes(searchQuery) ||
      (r.razonSocial  ||'').toLowerCase().includes(searchQuery) ||
      (r.rut          ||'').toLowerCase().includes(searchQuery) ||
      (r.actividad    ||'').toLowerCase().includes(searchQuery) ||
      (r.correo       ||'').toLowerCase().includes(searchQuery)
    );
  }
  return f;
}

function renderHistory() {
  // Siempre leer directo desde storage para garantizar datos frescos
  chrome.storage.local.get(['records'], data => {
    allRecords = data.records || [];
    const filtered  = getFilteredRecords();
    const container = q('historyList');
    if (!container) return;
    if (!filtered.length) {
      container.innerHTML = '<div class="empty-state">📭 Sin registros</div>';
      return;
    }
    container.innerHTML = filtered.map(r => {
      const incomplete = !r.isComplete;
      const empresa = r.razonSocial || (incomplete ? '(solo número — sin extracción)' : '(sin nombre)');
      return `
      <div class="history-card${incomplete?' incomplete':''}">
        <div class="hc-top">
          <div class="hc-empresa">${esc(empresa)}</div>
          <div class="hc-meta">
            <span class="hc-phone">${esc(r.phoneOriginal||'—')}</span>
            <span class="hc-time">${esc(r.fecha)} ${esc(r.hora)}</span>
          </div>
        </div>
        ${!incomplete ? `
        <div class="hc-body">
          <div class="hc-field">RUT: <b>${esc(r.rut||'—')}</b></div>
          <div class="hc-field">Rubro: <b>${esc(r.rubro||'—')}</b></div>
          <div class="hc-field">Actividad: <b>${esc(truncate(r.actividad,22))}</b></div>
          <div class="hc-field">Tel.CRM: <b>${esc(r.telefonoCRM||'—')}</b></div>
        </div>` : ''}
        <div class="hc-actions">
          ${!incomplete ? `<button class="btn-action btn-excel" onclick="copyRecordExcel('${r.id}')">📊 Excel</button>` : ''}
          <button class="btn-action btn-text" onclick="copyRecordText('${r.id}')">📝 Texto</button>
          <button class="btn-sm btn-danger"   onclick="deleteRecord('${r.id}')">✖</button>
        </div>
      </div>`;
    }).join('');
  });
}

function copyRecordExcel(id) {
  const r = allRecords.find(x => x.id === id);
  if (!r) return;
  const tsv = [r.fecha, r.razonSocial, r.rut, r.phoneOriginal||r.telefonoCRM, r.correo, '', ''].join('\t');
  navigator.clipboard.writeText(tsv).then(() => showToast('✔ Copiado para Excel','ok')).catch(()=>{});
}

function copyRecordText(id) {
  const r = allRecords.find(x => x.id === id);
  if (!r) return;
  const txt = `Número discador: ${r.phoneOriginal||'—'}\nEmpresa:         ${r.razonSocial||'—'}\nRUT:             ${r.rut||'—'}\nRubro:           ${r.rubro||'—'}\nActividad:       ${r.actividad||'—'}\nSegmento:        ${r.segmento||'—'}\nTel. CRM:        ${r.telefonoCRM||'—'}\nCorreo:          ${r.correo||'—'}\nFecha:           ${r.fecha} ${r.hora}`;
  navigator.clipboard.writeText(txt).then(() => showToast('✔ Copiado','ok')).catch(()=>{});
}

function deleteRecord(id) {
  chrome.runtime.sendMessage({ type: 'DELETE_RECORD', id }, () => {
    allRecords = allRecords.filter(r => r.id !== id);
    renderHistory();
  });
}

function clearAll() {
  if (!confirm('¿Borrar todo el historial? Esta acción no se puede deshacer.')) return;
  chrome.runtime.sendMessage({ type: 'CLEAR_ALL' }, () => { allRecords = []; renderHistory(); });
}

// ─────────────────────────────────────────────
//  EXPORTAR CSV
//  Descarga un archivo CSV con todos los registros.
//  auto=true añade timestamp al nombre.
// ─────────────────────────────────────────────
function exportCSV(auto) {
  chrome.storage.local.get(['records'], data => {
    const records = data.records || [];
    if (!records.length && !auto) { showToast('✖ No hay registros para exportar','err'); return; }

    const header = 'Fecha,Hora,Número Discador,Empresa,RUT,Rubro,Actividad,Segmento,Tel.CRM,Correo,Estado\n';
    const rows = records.map(r => [
      r.fecha         || '',
      r.hora          || '',
      r.phoneOriginal || '',
      csvCell(r.razonSocial),
      r.rut           || '',
      csvCell(r.rubro),
      csvCell(r.actividad),
      csvCell(r.segmento),
      r.telefonoCRM   || '',
      r.correo        || '',
      r.isComplete ? 'COMPLETO' : 'INCOMPLETO'
    ].join(',')).join('\n');

    const blob = new Blob(['\uFEFF' + header + rows], { type: 'text/csv;charset=utf-8;' });
    const url  = URL.createObjectURL(blob);
    const now  = new Date();
    const ts   = now.toLocaleDateString('es-CL').replace(/\//g,'-') + '_' +
                 now.toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit'}).replace(':','h');
    const name = `CRM_Extractor_${ts}.csv`;

    const a = document.createElement('a');
    a.href     = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
    if (!auto) showToast(`✔ Exportado: ${name}`, 'ok');
  });
}

// Escape para CSV: entre comillas si tiene comas o comillas
function csvCell(val) {
  if (!val) return '';
  const s = String(val);
  if (s.includes(',') || s.includes('"') || s.includes('\n')) return '"' + s.replace(/"/g,'""') + '"';
  return s;
}

// ─────────────────────────────────────────────
//  IMPORTAR CSV
// ─────────────────────────────────────────────
function importCSV(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    const text  = ev.target.result.replace(/^\uFEFF/, ''); // quitar BOM
    const lines = text.trim().split('\n');
    if (lines.length < 2) { showToast('✖ Archivo vacío o inválido','err'); return; }

    // Saltamos la cabecera (línea 0)
    const imported = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = parseCSVLine(lines[i]);
      if (cols.length < 10) continue;
      imported.push({
        id:            Date.now().toString(36) + Math.random().toString(36).slice(2) + i,
        timestamp:     Date.now() - (lines.length - i) * 1000, // orden aprox.
        fecha:         cols[0] || '',
        hora:          cols[1] || '',
        phoneOriginal: cols[2] || '',
        razonSocial:   cols[3] || '',
        rut:           cols[4] || '',
        rubro:         cols[5] || '',
        actividad:     cols[6] || '',
        segmento:      cols[7] || '',
        telefonoCRM:   cols[8] || '',
        correo:        cols[9] || '',
        isComplete:    (cols[10]||'').trim() === 'COMPLETO'
      });
    }
    if (!imported.length) { showToast('✖ No se encontraron registros válidos','err'); return; }

    chrome.storage.local.get(['records'], data => {
      // Fusionar: los nuevos van al final, sin duplicar por id
      const existing = data.records || [];
      const existingIds = new Set(existing.map(r => r.rut + r.phoneOriginal + r.fecha));
      const toAdd = imported.filter(r => !existingIds.has(r.rut + r.phoneOriginal + r.fecha));
      const merged = [...existing, ...toAdd];
      chrome.storage.local.set({ records: merged }, () => {
        allRecords = merged;
        showToast(`✔ Importados ${toAdd.length} registros (${imported.length - toAdd.length} duplicados omitidos)`, 'ok');
        renderHistory();
      });
    });
  };
  reader.readAsText(file, 'UTF-8');
  e.target.value = ''; // reset para poder importar el mismo archivo de nuevo
}

// Parse mínimo de una línea CSV respetando comillas
function parseCSVLine(line) {
  const result = [];
  let cur = '', inQ = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') {
      if (inQ && line[i+1] === '"') { cur += '"'; i++; }
      else inQ = !inQ;
    } else if (c === ',' && !inQ) {
      result.push(cur); cur = '';
    } else cur += c;
  }
  result.push(cur);
  return result;
}

// ─────────────────────────────────────────────
//  EXPORTACIÓN AUTOMÁTICA PROGRAMADA
//  Targets: 12:00, 15:00, 17:45
//  Usa setTimeout calculando ms hasta el próximo target.
//  Solo activo mientras el popup esté abierto.
//  El service worker background.js también tiene un alarm
//  para disparar desde ahí cuando el popup está cerrado.
// ─────────────────────────────────────────────
const AUTO_EXPORT_TIMES = [
  { h: 12, m:  0 },
  { h: 15, m:  0 },
  { h: 17, m: 45 }
];

function scheduleAutoExports() {
  AUTO_EXPORT_TIMES.forEach(target => {
    const ms = msUntil(target.h, target.m);
    // Solo programar si falta menos de 8 horas (para no acumular demasiados timeouts)
    if (ms > 0 && ms < 8 * 3600 * 1000) {
      setTimeout(() => {
        exportCSV(true);
        showToast(`✔ Respaldo automático generado (${target.h}:${String(target.m).padStart(2,'0')})`, 'ok');
      }, ms);
    }
  });
}

function msUntil(h, m) {
  const now  = new Date();
  const target = new Date();
  target.setHours(h, m, 0, 0);
  if (target <= now) return -1; // ya pasó hoy
  return target - now;
}

// ─────────────────────────────────────────────
//  ESTADÍSTICAS
// ─────────────────────────────────────────────
function renderStats() {
  chrome.storage.local.get(['records'], data => {
    const records = data.records || [];
    allRecords = records;
    const sod = new Date(); sod.setHours(0,0,0,0);
    const today    = records.filter(r => r.timestamp >= sod.getTime());
    const empresas = new Set(records.map(r => (r.razonSocial||'').toUpperCase()).filter(Boolean));
    const ruts     = new Set(records.map(r => r.rut).filter(Boolean));
    q('statTotal').textContent    = records.length;
    q('statToday').textContent    = today.length;
    q('statEmpresas').textContent = empresas.size;
    q('statRuts').textContent     = ruts.size;
  });
}

// ─────────────────────────────────────────────
//  VISTAS
// ─────────────────────────────────────────────
function showView(name) {
  currentView = name;
  q('viewMain').classList.toggle('hidden',    name !== 'main');
  q('viewHistory').classList.toggle('hidden', name !== 'history');
  q('viewStats').classList.toggle('hidden',   name !== 'stats');
  q('btnViewHistory').classList.toggle('active', name === 'history');
  q('btnViewStats').classList.toggle('active',   name === 'stats');
  if (name === 'history') {
    // Recargar registros frescos desde storage antes de renderizar
    chrome.storage.local.get(['records'], data => {
      allRecords = data.records || [];
      renderHistory();
    });
  }
  if (name === 'stats') renderStats();
}

// ─────────────────────────────────────────────
//  UTILIDADES
// ─────────────────────────────────────────────
function showToast(msg, type) {
  const el = q('toastMain');
  if (!el) return;
  el.textContent = msg;
  el.className   = `toast ${type}`;
  el.classList.remove('hidden');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.add('hidden'), 3500);
}

function esc(str) {
  return String(str||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function truncate(str, max) {
  if (!str) return '—';
  return str.length > max ? str.slice(0,max) + '…' : str;
}

// Exponer al scope global para onclick en HTML generado
window.copyRecordExcel = copyRecordExcel;
window.copyRecordText  = copyRecordText;
window.deleteRecord    = deleteRecord;
