// ══════════════════════════════════════════════════════════════════
//  CONTENT_DIALER.JS — CRM Extractor Pro
//  Se inyecta en la pestaña del discador Vocalcom/Hermes360.
//
//  Estrategia multi-capa para encontrar el número de teléfono:
//
//  CAPA 1 — Selectores CSS específicos de Hermes360/Vocalcom
//  CAPA 2 — Búsqueda por atributos conocidos (data-phone, data-number, etc.)
//  CAPA 3 — Todos los text nodes del DOM buscando patrón numérico chileno
//  CAPA 4 — HTML fuente completo con regex (captura números en atributos JS)
//
//  El número en la pantalla se ve como: 56452735173
//  Formato esperado: 56XXXXXXXXX (11 dígitos) o +56XXXXXXXXX
// ══════════════════════════════════════════════════════════════════

(function () {

  // ── PATRONES DE NÚMERO CHILENO ────────────────────────────────
  // Acepta: 56912345678, +56912345678, 56212345678, 56452735173
  const PHONE_RE   = /(?:\+?56)?[2-9]\d{8,9}/g;
  const PHONE_FULL = /\b((?:\+?56)?[2-9]\d{8,9})\b/;

  // ── CAPA 1: Selectores específicos de Vocalcom Hermes360 ──────
  // Observando la foto, el número aparece en un elemento con ícono
  // de teléfono (📞) y texto "56452735173". Hermes360 usa clases
  // como .phone-number, .call-number, .dialer-number, o spans
  // dentro de componentes Vue/React con data-*
  const DIALER_SELECTORS = [
    // Vocalcom Hermes360 específico
    '[class*="phone-number"]',
    '[class*="phoneNumber"]',
    '[class*="call-number"]',
    '[class*="callNumber"]',
    '[class*="dialer"]',
    '[class*="caller"]',
    '[class*="contact-number"]',
    '[class*="contactNumber"]',
    // Atributos de datos
    '[data-phone]',
    '[data-number]',
    '[data-tel]',
    '[data-contact-phone]',
    // Elementos comunes donde aparecen números
    'span[title]',
    'div[title]',
    'span[data-original-title]',
    // Input/display del discador
    'input[name*="phone"]',
    'input[name*="number"]',
    'input[id*="phone"]',
    'input[id*="number"]',
    '.v-phone-number',
    '.phone-display',
    '.number-display'
  ];

  function trySelectors() {
    for (const sel of DIALER_SELECTORS) {
      try {
        const els = document.querySelectorAll(sel);
        for (const el of els) {
          const candidates = [
            el.value,
            el.textContent,
            el.getAttribute('title'),
            el.getAttribute('data-phone'),
            el.getAttribute('data-number'),
            el.getAttribute('data-tel'),
            el.getAttribute('data-original-title')
          ];
          for (const c of candidates) {
            if (!c) continue;
            const clean = c.replace(/[\s\-().+]/g,'');
            if (PHONE_FULL.test(clean) && clean.length >= 9 && clean.length <= 12) {
              return normalizePhone(clean);
            }
          }
        }
      } catch(e) { /* selector inválido */ }
    }
    return null;
  }

  // ── CAPA 2: Todos los text nodes del DOM ──────────────────────
  // Recorre todos los nodos de texto y busca el patrón numérico.
  // Prioriza nodos cortos (menos contexto = más probable que sea solo el número).
  function tryTextNodes() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const candidates = [];
    let node;
    while ((node = walker.nextNode())) {
      const t = node.textContent.trim().replace(/[\s\-().+]/g,'');
      if (t.length >= 9 && t.length <= 12 && PHONE_FULL.test(t)) {
        // Darle prioridad a nodos más cortos (más específicos)
        candidates.push({ phone: normalizePhone(t), len: t.length });
      }
    }
    if (candidates.length) {
      // El más corto que cumpla el patrón es probablemente el número limpio
      candidates.sort((a,b) => a.len - b.len);
      return candidates[0].phone;
    }
    return null;
  }

  // ── CAPA 3: HTML fuente completo con regex ────────────────────
  // Vocalcom carga datos en atributos data-*, props de Vue/React,
  // o strings en el JS inline. El HTML fuente los expone todos.
  function tryHTMLSource() {
    const html = document.documentElement.outerHTML;
    // Buscar patrones más específicos primero
    const patterns = [
      // Vocalcom: "phone":"56452735173" o phone:56452735173
      /"phone"\s*:\s*"(\+?56[2-9]\d{8,9})"/i,
      /"phoneNumber"\s*:\s*"(\+?56[2-9]\d{8,9})"/i,
      /"number"\s*:\s*"(\+?56[2-9]\d{8,9})"/i,
      /"tel"\s*:\s*"(\+?56[2-9]\d{8,9})"/i,
      /data-phone="(\+?56[2-9]\d{8,9})"/i,
      /data-number="(\+?56[2-9]\d{8,9})"/i,
      // El número aparece en la URL a veces
      /Oid_Net[^&]*?(\d{9,12})/i,
      // Patrón genérico: número de 11 dígitos que empieza en 56
      /\b(56[2-9]\d{8,9})\b/
    ];
    for (const pat of patterns) {
      const m = html.match(pat);
      if (m && m[1]) {
        const clean = m[1].replace(/\D/g,'');
        if (clean.length >= 9 && clean.length <= 12) return normalizePhone(clean);
      }
    }
    return null;
  }

  // ── CAPA 4: URL de la página ──────────────────────────────────
  // Vocalcom a veces pone el número en la URL (Oid_Net, Station_Agent, etc.)
  function tryURL() {
    const url = window.location.href;
    const m = url.match(/[&?](?:phone|number|tel|ani|dnis|calledNumber)=(\+?56[2-9]\d{8,9})/i);
    if (m) return normalizePhone(m[1]);
    // Buscar cualquier segmento de 11 dígitos en la URL que empiece en 56
    const um = url.match(/\b(56[2-9]\d{8,9})\b/);
    if (um) return normalizePhone(um[1]);
    return null;
  }

  // ── NORMALIZAR TELÉFONO ───────────────────────────────────────
  function normalizePhone(raw) {
    const clean = String(raw).replace(/\D/g,'');
    if (clean.startsWith('56') && clean.length >= 11) return '+' + clean;
    if (clean.length === 9) return '+56' + clean;
    if (clean.length === 8) return '+562' + clean; // fijo Santiago
    return '+56' + clean;
  }

  // ── EJECUTAR CAPAS EN ORDEN ───────────────────────────────────
  const phone =
    trySelectors()  ||
    tryTextNodes()  ||
    tryHTMLSource() ||
    tryURL()        ||
    null;

  // ── RETORNAR RESULTADO ────────────────────────────────────────
  return {
    type:        'DIALER_PHONE_DETECTED',
    phone:       phone,
    url:         window.location.href,
    title:       document.title,
    capturedAt:  Date.now(),
    // Para debug: devolver también todos los candidatos encontrados
    debug: {
      fromSelectors: trySelectors(),
      fromTextNodes: tryTextNodes(),
      fromHTML:      tryHTMLSource(),
      fromURL:       tryURL()
    }
  };
})();
