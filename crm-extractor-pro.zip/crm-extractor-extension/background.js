// ══════════════════════════════════════════════════════════════════
//  BACKGROUND SERVICE WORKER — CRM Extractor Pro v3
//  Novedades:
//    · chrome.alarms para exportación automática a 12:00, 15:00, 17:45
//      (funciona aunque el popup esté cerrado)
//    · Guarda el CSV en chrome.downloads
// ══════════════════════════════════════════════════════════════════

// ── ALARMAS AUTOMÁTICAS ───────────────────────────────────────────
// Se registran al instalar la extensión y cada vez que se reinicia el SW.
const AUTO_EXPORT_ALARMS = [
  { name: 'export_1200', h: 12, m:  0 },
  { name: 'export_1500', h: 15, m:  0 },
  { name: 'export_1745', h: 17, m: 45 }
];

function scheduleAlarms() {
  AUTO_EXPORT_ALARMS.forEach(({ name, h, m }) => {
    const now    = new Date();
    const target = new Date();
    target.setHours(h, m, 0, 0);
    if (target <= now) target.setDate(target.getDate() + 1); // si ya pasó, mañana

    // Convertir a timestamp para la alarma
    chrome.alarms.create(name, {
      when:            target.getTime(),
      periodInMinutes: 24 * 60  // repetir cada 24 horas
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  scheduleAlarms();
});

// Re-programar al despertar el SW (puede perderse tras una pausa)
chrome.alarms.getAll(alarms => {
  if (alarms.length === 0) scheduleAlarms();
});

// ── DISPARAR EXPORTACIÓN AUTOMÁTICA ──────────────────────────────
chrome.alarms.onAlarm.addListener(alarm => {
  const isExport = AUTO_EXPORT_ALARMS.some(a => a.name === alarm.name);
  if (!isExport) return;

  chrome.storage.local.get(['records'], data => {
    const records = data.records || [];
    if (!records.length) return;

    const header = 'Fecha,Hora,Número Discador,Empresa,RUT,Rubro,Actividad,Segmento,Tel.CRM,Correo,Estado\n';
    const rows   = records.map(r => [
      r.fecha         || '',
      r.hora          || '',
      r.phoneOriginal || '',
      csvCell(r.razonSocial),
      r.rut           || '',
      csvCell(r.rubro),
      csvCell(r.actividad),
      csvCell(r.segmento),
      r.telefonoCRM   || '',
      r.correo        || '',
      r.isComplete ? 'COMPLETO' : 'INCOMPLETO'
    ].join(',')).join('\n');

    const csv = '\uFEFF' + header + rows;  // BOM para Excel en español
    const now  = new Date();
    const ts   = now.toLocaleDateString('es-CL').replace(/\//g,'-') + '_' +
                 now.toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit'}).replace(':','h');
    const filename = `CRM_Extractor_${ts}.csv`;

    // Guardar como data: URL y descargar via chrome.downloads
    const b64 = btoa(unescape(encodeURIComponent(csv)));
    const url  = `data:text/csv;charset=utf-8;base64,${b64}`;

    chrome.downloads.download({
      url,
      filename,
      saveAs:   false,
      conflictAction: 'uniquify'
    });
  });
});

function csvCell(val) {
  if (!val) return '';
  const s = String(val);
  if (s.includes(',') || s.includes('"') || s.includes('\n')) return '"' + s.replace(/"/g,'""') + '"';
  return s;
}

// ── MENSAJES DESDE POPUP ──────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === 'SAVE_RECORD') {
    chrome.storage.local.get(['records'], data => {
      const records = data.records || [];
      records.unshift(msg.record);
      chrome.storage.local.set({ records }, () => {
        sendResponse({ ok: true, total: records.length });
      });
    });
    return true;
  }

  if (msg.type === 'DELETE_RECORD') {
    chrome.storage.local.get(['records'], data => {
      const records = (data.records || []).filter(r => r.id !== msg.id);
      chrome.storage.local.set({ records }, () => sendResponse({ ok: true }));
    });
    return true;
  }

  if (msg.type === 'CLEAR_ALL') {
    chrome.storage.local.remove('records', () => sendResponse({ ok: true }));
    return true;
  }
});
