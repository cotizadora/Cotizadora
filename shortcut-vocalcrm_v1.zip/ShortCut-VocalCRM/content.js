// ==UserScript==
// @name         ShortCut-VocalCRM
// @namespace    pausa-vocal.vocalcom
// @version      4.1.0
// @description  Pre-selecciona un estado de agente y lo aplica automaticamente al cortar la llamada (replay del clic real). Autoconfigurable + modo debug.
// @author       Pausa Vocal
// @match        *://*.vocalcomcx.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

/*
 * ============================================================================
 *  ShortCut-VocalCRM — atajos de estado (VOCALCOM) y tipificación (CRM Atlas)
 * ----------------------------------------------------------------------------
 *  IDEA CENTRAL (confiabilidad > elegancia):
 *   - No dependemos de funciones internas de VOCALCOM (SetAgentState, etc.).
 *   - "Aprendemos" tu clic REAL sobre un estado del menu y lo GUARDAMOS.
 *   - Cuando detectamos fin de llamada, RE-EJECUTAMOS ese clic real,
 *     disparando los mismos handlers (jQuery/Bootstrap) que usas tu.
 *
 *  DETECCION DE FIN DE LLAMADA (por capas, la que dispare primero):
 *   1. Cronometro de llamada que se detiene / desaparece  (generico, dia 1)
 *   2. Trama WebSocket (AgentLink) que coincide con un patron configurado
 *      -> el modo debug registra las tramas para que aprendas el patron
 *   3. JsSIP: evento 'ended'/'failed' si la UA es accesible desde window
 *
 *  MULTI-FRAME: el sitio usa framesets. El script corre en TODOS los frames;
 *  el panel se dibuja solo en el frame superior y el estado se comparte por
 *  localStorage (mismo origen). El frame que contiene el elemento aprendido
 *  es el que ejecuta el replay.
 * ============================================================================
 */

(function () {
  'use strict';

  // Evitar doble inicializacion en el mismo documento
  if (window.__VCA_LOADED__) return;
  window.__VCA_LOADED__ = true;

  const IS_TOP = (function () { try { return window.self === window.top; } catch (e) { return false; } })();

  // El CRM (Atlas) NO usa cola: cada tipificación se aplica EN EL MOMENTO y no
  // queda nada pendiente. Si quedara algo armado y luego cae OTRO cliente (o se
  // recarga la página), se tipificaría al cliente equivocado. La cola solo tiene
  // sentido en VOCALCOM, donde el cambio de estado espera a que corte la llamada.
  const IS_CRM = /geimser\.cl/i.test(location.hostname || '');

  // ---------------------------------------------------------------------------
  // Almacenamiento (compartido entre frames del mismo origen via localStorage)
  // ---------------------------------------------------------------------------
  const K = {
    states:   'vca_states',    // [{name, desc}]
    settings: 'vca_settings',  // {debug, wsPattern, wrapupSelector, ...}
    armed:    'vca_armed',     // desc | null
    callend:  'vca_callend',   // timestamp (broadcast entre frames)
    needrep:  'vca_needrep',   // timestamp (pedir replay a otros frames)
    lastfire: 'vca_lastfire',  // timestamp (cooldown anti-doble-disparo)
    log:      'vca_log'        // [] lineas de debug (para verlas en el panel)
  };

  const Store = {
    get(k, def) {
      try { const v = localStorage.getItem(k); return v == null ? def : JSON.parse(v); }
      catch (e) { return def; }
    },
    set(k, v) {
      try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
    },
    del(k) { try { localStorage.removeItem(k); } catch (e) {} }
  };

  const DEFAULT_SETTINGS = {
    debug: false,
    wsPattern: '',          // subcadena/regex para detectar fin de llamada en WS
    wrapupSelector: '',     // selector CSS cuya aparicion = fin de llamada (opcional)
    hangupSelector: '',     // selector cuya DESAPARICION = fin de llamada (opcional)
    useTimer: true,         // detector generico por cronometro
    cooldownMs: 4000,       // ventana anti-doble-disparo
    minArmedMs: 1500,       // no disparar si se armo hace < X ms (evita colas de llamada previa)
    autoWatch: true,        // aplicar EN CUANTO el control de estado se habilite
    requireDisableFirst: true, // exigir haber visto el control deshabilitado antes de disparar
                               // (asi no se dispara en mitad de la llamada, solo tras habilitarse)
    stepTimeoutMs: 8000,    // espera max. por cada paso (que aparezca / se habilite)
    totalTimeoutMs: 30000,  // tiempo total del replay (reintenta si el menu no estaba listo)
    retryGapMs: 1000,       // espera entre reintentos del ciclo completo
    stepGapMs: 400,         // pausa entre pasos para que se abra el menu
    keepAlive: true         // mantener la pestaña activa en segundo plano (audio inaudible)
  };

  function settings() { return Object.assign({}, DEFAULT_SETTINGS, Store.get(K.settings, {})); }
  function setSetting(patch) { Store.set(K.settings, Object.assign(settings(), patch)); }

  // ---------------------------------------------------------------------------
  // Log en memoria + espejo a localStorage para el panel + consola en debug
  // ---------------------------------------------------------------------------
  function log() {
    const s = settings();
    const msg = '[VCA' + (IS_TOP ? '/top' : '/frame') + '] ' + Array.from(arguments).join(' ');
    if (s.debug) { try { console.log(msg); } catch (e) {} }
    const arr = Store.get(K.log, []);
    arr.push(new Date().toLocaleTimeString() + '  ' + Array.from(arguments).join(' '));
    while (arr.length > 200) arr.shift();
    Store.set(K.log, arr);
  }

  // ===========================================================================
  //  LOCATOR: capturar un elemento -> descriptor; y resolver descriptor -> elemento
  // ===========================================================================
  const Locator = {
    norm(t) { return (t || '').replace(/\s+/g, ' ').trim(); },

    cssPath(el) {
      const parts = [];
      let cur = el;
      while (cur && cur.nodeType === 1 && parts.length < 6) {
        let part = cur.tagName.toLowerCase();
        if (cur.id) { parts.unshift(part + '#' + CSS.escape(cur.id)); break; }
        const cls = Array.from(cur.classList)
          .filter(c => !/(active|show|open|hover|selected|focus|highlight)/i.test(c))
          .slice(0, 3);
        if (cls.length) part += '.' + cls.map(c => CSS.escape(c)).join('.');
        const parent = cur.parentElement;
        if (parent) {
          const same = Array.from(parent.children).filter(c => c.tagName === cur.tagName);
          if (same.length > 1) part += ':nth-of-type(' + (same.indexOf(cur) + 1) + ')';
        }
        parts.unshift(part);
        cur = cur.parentElement;
      }
      return parts.join(' > ');
    },

    capture(el) {
      const data = {};
      for (const a of el.attributes || []) {
        if (/^(data-|onclick|href|value|title|aria-label)/i.test(a.name)) data[a.name] = a.value;
      }
      return {
        text: this.norm(el.textContent).slice(0, 60),
        tag: el.tagName.toLowerCase(),
        id: el.id || '',
        classes: Array.from(el.classList),
        path: this.cssPath(el),
        attrs: data
      };
    },

    // Devuelve el elemento en un documento dado, o null. Varias estrategias.
    resolve(doc, d) {
      if (!d) return null;
      // 1) por id
      if (d.id) { const e = doc.getElementById(d.id); if (e) return e; }
      // 2) por path CSS + verificacion de texto
      try {
        const e = doc.querySelector(d.path);
        if (e && (!d.text || this.norm(e.textContent).slice(0, 60) === d.text)) return e;
      } catch (e) {}
      // 3) por tag + primera clase + texto exacto
      const firstCls = d.classes.find(c => !/(active|show|open|selected)/i.test(c));
      try {
        const sel = d.tag + (firstCls ? '.' + CSS.escape(firstCls) : '');
        const cand = Array.from(doc.querySelectorAll(sel));
        const hit = cand.find(e => this.norm(e.textContent).slice(0, 60) === d.text);
        if (hit) return hit;
      } catch (e) {}
      // 4) cualquier control con ese texto exacto y pocos hijos
      if (d.text) {
        const all = Array.from(doc.querySelectorAll('a,button,li,span,div,td'));
        const hit = all.find(e =>
          this.norm(e.textContent).slice(0, 60) === d.text && e.children.length <= 2);
        if (hit) return hit;
      }
      // 5) ultimo recurso: el path aunque el texto haya cambiado. Necesario para
      //    controles cuyo texto refleja el estado actual (ej. el toggle "En espera"
      //    que luego dice otra cosa) o menus que varian su etiqueta.
      try { const e = doc.querySelector(d.path); if (e) return e; } catch (e) {}
      return null;
    },

    // Re-ejecuta un clic realista. NO llama a el.click() para evitar doble disparo:
    // un evento 'click' despachado ya invoca handlers jQuery/onclick y navegacion <a>.
    fireClick(el) {
      try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
      try { el.focus && el.focus(); } catch (e) {}
      const view = el.ownerDocument.defaultView || window;
      const opts = { bubbles: true, cancelable: true, view: view, button: 0 };
      ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(type => {
        try { el.dispatchEvent(new MouseEvent(type, opts)); } catch (e) {}
      });
    }
  };

  // ===========================================================================
  //  ARMADO (estado pre-seleccionado) — compartido entre frames
  // ===========================================================================
  function getArmed() { return Store.get(K.armed, null); }
  function setArmed(desc) {
    if (desc) Store.set(K.armed, desc); else Store.del(K.armed);
    if (window.__vcaPanel) window.__vcaPanel.refresh();
    // Notificar a otros frames para refrescar UI si tuvieran alguna
    Store.set('vca_armping', Date.now());
  }

  // ===========================================================================
  //  MOTOR DE REPLAY MULTI-PASO (Pausa -> menu -> estado), con esperas
  // ===========================================================================
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ¿El elemento esta visible y NO deshabilitado? (el boton "Pausa" se habilita
  // solo despues de la llamada; hay que esperar a que este clicable).
  function isClickable(el) {
    if (!el) return false;
    if (el.disabled) return false;
    const cls = (el.getAttribute && el.getAttribute('class')) || '';
    if (/(^|\s)(disabled|is-disabled|inactive)(\s|$)/i.test(cls)) return false;
    if (el.getAttribute && el.getAttribute('aria-disabled') === 'true') return false;
    try { if (el.getClientRects().length === 0) return false; } catch (e) {}
    return true;
  }

  // Espera hasta que el paso se pueda resolver Y este clicable, o venza el timeout.
  async function waitFor(desc, timeout) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      const el = Locator.resolve(document, desc);
      if (el && isClickable(el)) return el;
      await sleep(150);
    }
    return Locator.resolve(document, desc); // ultimo intento aunque no parezca clicable
  }

  // --- Controles de formulario (<select>, texto, casillas) -------------------
  // Asignar .value directamente no basta si la web usa React/Vue: hay que usar
  // el setter NATIVO del prototipo para que el framework detecte el cambio.
  function setNativeValue(el, value) {
    try {
      const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
      if (d && d.set) { d.set.call(el, value); return; }
    } catch (e) {}
    try { el.value = value; } catch (e) {}
  }
  function fireInputChange(el) {
    try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {}
    try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
  }
  function optionMatch(el, step) {
    if (!el || !el.options) return null;
    for (const o of el.options) {
      if (step.value !== undefined && step.value !== '' && o.value === step.value) return o.value;
    }
    for (const o of el.options) {                    // respaldo: casar por texto
      if (step.optText && Locator.norm(o.textContent) === step.optText) return o.value;
    }
    return null;
  }
  // Espera a que el <select> exista Y ya tenga la opcion: los menus encadenados
  // (Estado -> Resultado -> Motivo) se rellenan tras elegir el anterior.
  async function waitForOption(step, timeout) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      const el = Locator.resolve(document, step);
      if (el) { const v = optionMatch(el, step); if (v !== null) return { el: el, value: v }; }
      await sleep(150);
    }
    return null;
  }

  // Un intento de la secuencia completa. false si algun paso no estaba listo.
  async function runStepsOnce(steps, s) {
    for (let i = 0; i < steps.length; i++) {
      const st = steps[i];
      const kind = st.kind || 'click';
      const tag = '  paso ' + (i + 1) + '/' + steps.length;

      if (kind === 'select') {
        const hit = await waitForOption(st, s.stepTimeoutMs);
        if (!hit) { log(tag + ' menu sin la opcion "' + (st.optText || st.value) + '"'); return false; }
        setNativeValue(hit.el, hit.value);
        fireInputChange(hit.el);
        log(tag + ' -> menu "' + (st.optText || hit.value) + '"');

      } else if (kind === 'input') {
        const el = await waitFor(st, s.stepTimeoutMs);
        if (!el) { log(tag + ' campo de texto no encontrado'); return false; }
        setNativeValue(el, st.value);
        fireInputChange(el);
        log(tag + ' -> texto "' + String(st.value).slice(0, 30) + '"');

      } else if (kind === 'check') {
        const el = await waitFor(st, s.stepTimeoutMs);
        if (!el) { log(tag + ' casilla no encontrada'); return false; }
        if (!!el.checked !== !!st.checked) Locator.fireClick(el);
        log(tag + ' -> casilla ' + st.checked);

      } else {
        const el = await waitFor(st, s.stepTimeoutMs);
        if (!el || !isClickable(el)) {
          log(tag + ' no listo (' + st.tag + ' "' + st.text + '")');
          return false;
        }
        Locator.fireClick(el);
        log(tag + ' -> ' + st.tag + ' "' + st.text + '"');
      }
      await sleep(s.stepGapMs);
    }
    return true;
  }

  // Ejecuta la secuencia reintentando el ciclo completo hasta lograrlo o vencer
  // el tiempo total (el menu de pausa no siempre esta disponible al instante).
  async function runSteps(steps) {
    const s = settings();
    const deadline = Date.now() + s.totalTimeoutMs;
    let attempt = 0;
    while (Date.now() < deadline) {
      attempt++;
      if (attempt > 1) log('Replay reintento ' + attempt + '...');
      if (await runStepsOnce(steps, s)) { log('Replay COMPLETADO (intento ' + attempt + ').'); return true; }
      // cerrar cualquier menu abierto antes de reintentar
      try {
        (document.activeElement || document.body).dispatchEvent(
          new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, which: 27, bubbles: true }));
      } catch (e) {}
      await sleep(s.retryGapMs);
    }
    log('Replay AGOTADO tras ' + attempt + ' intento(s): no se pudo aplicar el estado.');
    return false;
  }

  // Normaliza a un array de pasos (compat con formato antiguo de 1 clic).
  function stepsOf(x) {
    if (!x) return [];
    if (x.steps && x.steps.length) return x.steps;
    if (x.desc) return [x.desc];
    if (x.path || x.text) return [x]; // era un descriptor suelto
    return [];
  }

  // ===========================================================================
  //  MANEJO DE FIN DE LLAMADA -> replay
  //  Actua el frame que CONTIENE el primer control de la secuencia. Si no esta
  //  en este frame, delega a otros frames via `needrep`.
  // ===========================================================================
  let replaying = false;

  function handleCallEnd(sourceTag) {
    const s = settings();
    // CRM: solo se aplica por el ▶ del usuario (sourceTag 'popup'). Nunca por un
    // detector automático, para no tipificar sobre un cliente que no corresponde.
    if (IS_CRM && sourceTag !== 'popup') return;
    const armed = getArmed();
    if (!armed) return; // nada pre-seleccionado -> no hacemos nada

    const now = Date.now();
    const last = Store.get(K.lastfire, 0);
    if (now - last < s.cooldownMs) return;              // cooldown global
    if (armed.__armedAt && now - armed.__armedAt < s.minArmedMs) return; // recien armado
    if (replaying) return;

    const steps = stepsOf(armed);
    if (!steps.length) return;
    // Si el primer control no vive en este frame, que lo intenten los demas.
    if (!Locator.resolve(document, steps[0])) { Store.set(K.needrep, now + '|' + Math.random()); return; }

    Store.set(K.lastfire, now);
    replaying = true;
    log('Fin de llamada (' + sourceTag + ') -> aplicando "' +
        (armed.label || armed.name || armed.text) + '" (' + steps.length + ' paso/s)');
    runSteps(steps).then((ok) => {
      replaying = false;
      if (ok) { setArmed(null); }
      else { Store.set(K.needrep, Date.now() + '|' + Math.random()); } // que prueben otros frames
    });
  }

  // Otro frame (no lider) intenta el replay si los controles viven aqui.
  function tryReplayFromBus() {
    if (replaying) return;
    const armed = getArmed();
    if (!armed) return;
    const steps = stepsOf(armed);
    if (!steps.length) return;
    if (!Locator.resolve(document, steps[0])) return; // el primer control no esta aqui
    Store.set(K.lastfire, Date.now());
    replaying = true;
    log('Replay (bus) en este frame: "' + (armed.label || armed.name || armed.text) + '"');
    runSteps(steps).then((ok) => { replaying = false; if (ok) setArmed(null); });
  }

  // ===========================================================================
  //  AUTO-VIGILANCIA: dispara EN CUANTO el control de estado se habilita.
  //  No depende de detectar el fin de llamada: armas "Correo" durante la
  //  llamada (el control esta deshabilitado) y en cuanto se habilita -tras la
  //  llamada y la pantalla intermedia- se ejecuta la secuencia sola.
  //  Corre en cada frame; solo actua el frame que contiene el 1er control.
  // ===========================================================================
  const armWatch = { sawDisabled: false };

  // Estado final de un atajo (la última selección). Sirve para emparejar dos
  // atajos que llevan al MISMO estado desde puntos de partida distintos.
  function finalStateKey(sc) {
    const st = stepsOf(sc);
    const l = st[st.length - 1] || {};
    return String(l.optText || l.value || l.text || '').trim().toUpperCase();
  }
  // data-status del PRIMER paso ('available' = disponible/En espera; 'red' = En línea).
  function firstStepStatus(sc) {
    const st = stepsOf(sc);
    const f = st[0] || {};
    return String((f.attrs && f.attrs['data-status']) || '').toLowerCase();
  }

  // RED DE SEGURIDAD. Un atajo "en llamada" (su 1er paso apunta al estado En línea)
  // que quedó ARMADO cuando el agente YA está DISPONIBLE no puede ejecutarse: su
  // control ya no existe y queda "pegado". En ese caso buscamos el "gemelo
  // disponible" (otro atajo con el MISMO estado final, cuyo 1er paso es el estado
  // disponible) y lo ejecutamos. Ej.: PROGRAMAR ENVIAR CORREO (pegado) -> CORREO.
  // Así el ejecutivo no queda Disponible creyendo que dejó programado el envío.
  function stuckFallbackCheck(armed) {
    if (replaying) return false;
    const fs = firstStepStatus(armed);
    if (!fs || fs === 'available') return false;      // no es un atajo "en llamada"
    // ¿El agente ya está DISPONIBLE? (existe el botón de estado disponible)
    if (!document.querySelector('button.dropdown-toggle[data-status="available"]')) return false;
    const target = finalStateKey(armed);
    if (!target) return false;
    const twin = Store.get(K.states, []).find(sc =>
      firstStepStatus(sc) === 'available' && finalStateKey(sc) === target);
    if (!twin) return false;
    const tSteps = stepsOf(twin);
    if (!tSteps.length || !Locator.resolve(document, tSteps[0])) return false;
    const now = Date.now();
    if (now - Store.get(K.lastfire, 0) < settings().cooldownMs) return false;
    Store.set(K.lastfire, now);
    replaying = true;
    log('Atajo en-llamada pegado y agente DISPONIBLE -> ejecuto gemelo disponible: "' + (twin.label || '') + '"');
    runSteps(tSteps).then((ok) => { replaying = false; if (ok) setArmed(null); });
    return true;
  }

  function autoWatchTick() {
    const s = settings();
    if (!s.autoWatch || replaying) return;
    // CRM: sin cola ni vigilancia. La tipificación se aplica solo en el momento
    // en que el usuario pulsa ▶ (vía applynow), nunca "en cuanto se pueda".
    if (IS_CRM) return;
    const armed = getArmed();
    if (!armed) { armWatch.sawDisabled = false; return; }
    // Red de seguridad: atajo "en llamada" pegado + agente disponible -> gemelo.
    if (stuckFallbackCheck(armed)) return;
    const steps = stepsOf(armed);
    if (!steps.length) return;

    const first = Locator.resolve(document, steps[0]);
    if (!first) return; // los controles no viven en este frame

    const now = Date.now();
    if (now - Store.get(K.lastfire, 0) < s.cooldownMs) return;
    if (armed.__armedAt && now - armed.__armedAt < s.minArmedMs) return;

    if (!isClickable(first)) { armWatch.sawDisabled = true; return; } // aun deshabilitado
    // `immediate` = lo pidió el usuario con ▶: ejecutar en cuanto se pueda, sin
    // exigir haber visto antes el control deshabilitado.
    if (s.requireDisableFirst && !armed.immediate && !armWatch.sawDisabled) return;

    Store.set(K.lastfire, now);
    replaying = true;
    log('Auto: control habilitado -> aplicando "' + (armed.label || armed.name || armed.text) + '"');
    runSteps(steps).then((ok) => {
      replaying = false;
      if (ok) { armWatch.sawDisabled = false; setArmed(null); }
    });
  }

  // Broadcast de fin de llamada a todos los frames (por si el detector vive en otro)
  function broadcastCallEnd(sourceTag) {
    handleCallEnd(sourceTag);                 // local
    Store.set(K.callend, Date.now() + '|' + sourceTag); // otros frames
  }

  // Reaccionar a eventos de storage de otros frames/pestanas
  window.addEventListener('storage', (e) => {
    if (e.key === K.callend && e.newValue) {
      const tag = String(e.newValue).split('|')[1] || 'otro-frame';
      handleCallEnd(tag);
    } else if (e.key === K.needrep) {
      tryReplayFromBus();
    } else if (e.key === 'vca_armping' && window.__vcaPanel) {
      window.__vcaPanel.refresh();
    }
  });

  // Comandos desde el popup de la extension (via bridge en mundo aislado).
  // Los CustomEvent sobre `document` cruzan entre el mundo MAIN y el aislado.
  document.addEventListener('vca:cmd', (ev) => {
    const d = (ev && ev.detail) || {};
    if (d.type === 'applynow') { Store.set(K.lastfire, 0); handleCallEnd('popup'); }
    else if (d.type === 'callend') { handleCallEnd(d.tag || 'popup'); }
    else if (d.type === 'refresh' && window.__vcaPanel) { window.__vcaPanel.rebuild(); window.__vcaPanel.refresh(); }
  });

  // ===========================================================================
  //  DETECTORES DE FIN DE LLAMADA
  // ===========================================================================

  // --- 1) WebSocket sniffer (AgentLink). Registra tramas en debug; casa patron.
  (function patchWebSocket() {
    const NativeWS = window.WebSocket;
    if (!NativeWS || NativeWS.__vcaPatched) return;
    function VcaWS(url, protocols) {
      const ws = protocols === undefined ? new NativeWS(url) : new NativeWS(url, protocols);
      try {
        ws.addEventListener('message', (ev) => {
          const s = settings();
          let data = ev.data;
          if (typeof data !== 'string') return; // ignoramos binario
          if (s.debug) {
            // guardar ultimas tramas para inspeccion en el panel
            const frames = Store.get('vca_wsframes', []);
            frames.push(new Date().toLocaleTimeString() + '  ' + data.slice(0, 300));
            while (frames.length > 60) frames.shift();
            Store.set('vca_wsframes', frames);
          }
          if (s.wsPattern) {
            let match = false;
            try { match = new RegExp(s.wsPattern, 'i').test(data); }
            catch (e) { match = data.toLowerCase().indexOf(s.wsPattern.toLowerCase()) >= 0; }
            if (match) broadcastCallEnd('websocket');
          }
        });
      } catch (e) {}
      return ws;
    }
    VcaWS.prototype = NativeWS.prototype;
    VcaWS.CONNECTING = NativeWS.CONNECTING; VcaWS.OPEN = NativeWS.OPEN;
    VcaWS.CLOSING = NativeWS.CLOSING; VcaWS.CLOSED = NativeWS.CLOSED;
    VcaWS.__vcaPatched = true;
    try { window.WebSocket = VcaWS; } catch (e) {}
  })();

  // --- 2) Cronometro de llamada (generico). Un elemento cuyo texto es un reloj
  //         (mm:ss) y cambia cada segundo; cuando se detiene/desaparece = fin.
  const TimerDetector = (function () {
    let tracked = null;      // {el, last, lastChange}
    let interval = null;
    const CLOCK = /^\s*\d{1,2}:\d{2}(:\d{2})?\s*$/;

    function findClocks() {
      const out = [];
      const nodes = document.querySelectorAll('span,div,td,b,strong,label,p');
      for (const n of nodes) {
        if (n.children.length === 0 && CLOCK.test(n.textContent)) out.push(n);
      }
      return out;
    }

    function tick() {
      const s = settings();
      if (!s.useTimer) return;
      const now = Date.now();

      if (tracked && document.contains(tracked.el)) {
        const txt = tracked.el.textContent.trim();
        if (txt !== tracked.last) {
          tracked.last = txt; tracked.lastChange = now;
        } else if (now - tracked.lastChange > 2500) {
          // el reloj dejo de avanzar por >2.5s -> fin de llamada
          const wasRunning = tracked.wasRunning;
          if (wasRunning) {
            log('Cronometro detenido en', txt, '-> fin de llamada');
            broadcastCallEnd('cronometro');
          }
          tracked = null;
        }
        // marcar que llego a correr (cambio al menos una vez)
        if (tracked && tracked.last !== tracked.initial) tracked.wasRunning = true;
      } else if (tracked && !document.contains(tracked.el)) {
        if (tracked.wasRunning) {
          log('Cronometro desaparecio -> fin de llamada');
          broadcastCallEnd('cronometro-removido');
        }
        tracked = null;
      }

      if (!tracked) {
        const clocks = findClocks();
        // preferimos un reloj distinto de 00:00
        const cand = clocks.find(c => !/^0?0:00(:00)?$/.test(c.textContent.trim())) || clocks[0];
        if (cand) {
          tracked = { el: cand, last: cand.textContent.trim(), initial: cand.textContent.trim(),
                      lastChange: now, wasRunning: false };
        }
      }
    }

    return {
      start() { if (!interval) interval = setInterval(tick, 1000); }
    };
  })();

  // --- 3) Observadores DOM configurables (wrap-up aparece / hangup desaparece)
  const DomDetector = (function () {
    let hangupSeen = false;
    function check() {
      const s = settings();
      if (s.wrapupSelector) {
        try { if (document.querySelector(s.wrapupSelector)) broadcastCallEnd('wrapup-selector'); }
        catch (e) {}
      }
      if (s.hangupSelector) {
        try {
          const present = !!document.querySelector(s.hangupSelector);
          if (present) hangupSeen = true;
          else if (hangupSeen) { hangupSeen = false; broadcastCallEnd('hangup-desaparecio'); }
        } catch (e) {}
      }
    }
    return {
      start() {
        try {
          const mo = new MutationObserver(() => check());
          mo.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
        } catch (e) {}
        setInterval(check, 1000);
      }
    };
  })();

  // --- 4) JsSIP (best-effort): buscar una UA con .sessions y enganchar 'ended'
  const JsSipDetector = (function () {
    const hooked = new WeakSet();
    function scan() {
      try {
        for (const key of Object.keys(window)) {
          const v = window[key];
          if (v && typeof v === 'object' && v._sessions) {
            const sessions = v._sessions;
            for (const id in sessions) {
              const sess = sessions[id];
              if (sess && !hooked.has(sess) && typeof sess.on === 'function') {
                hooked.add(sess);
                sess.on('ended', () => broadcastCallEnd('jssip-ended'));
                sess.on('failed', () => broadcastCallEnd('jssip-failed'));
                log('JsSIP: sesion enganchada');
              }
            }
          }
        }
      } catch (e) {}
    }
    return { start() { setInterval(scan, 2000); } };
  })();

  // ===========================================================================
  //  MODO "APRENDER" MULTI-PASO: graba la SECUENCIA de clics del usuario
  //  (ej. "Pausa" -> "Envio de correo"). Los clics SI se dejan pasar para que
  //  el menu real se abra y puedas continuar hasta el estado final.
  // ===========================================================================
  function startLearning(name) {
    Store.set('vca_learning', { name, ts: Date.now(), steps: [] });
    log('APRENDER "' + name + '": haz los clics reales (ej. Pausa -> estado). Pulsa “Terminar” al acabar.');
    if (window.__vcaPanel) window.__vcaPanel.refresh();
  }
  function finishLearning() {
    const learn = Store.get('vca_learning', null);
    Store.del('vca_learning');
    if (learn && learn.steps && learn.steps.length) {
      const states = Store.get(K.states, []);
      const idx = states.findIndex(x => x.name === learn.name);
      const entry = { name: learn.name, steps: learn.steps };
      if (idx >= 0) states[idx] = entry; else states.push(entry);
      Store.set(K.states, states);
      log('APRENDIDO "' + learn.name + '" con ' + learn.steps.length + ' paso(s).');
    } else {
      log('Aprendizaje cancelado (0 pasos).');
    }
    if (window.__vcaPanel) { window.__vcaPanel.rebuild(); window.__vcaPanel.refresh(); }
  }
  function cancelLearning() {
    Store.del('vca_learning');
    log('Aprendizaje cancelado.');
    if (window.__vcaPanel) window.__vcaPanel.refresh();
  }

  // Captura cada clic MIENTRAS se graba, sin bloquearlo (el menu debe abrirse).
  // El estado de grabacion (recording + steps) vive en localStorage de la pagina,
  // escrito por ESTE content script. No depende de que el popup/ventana siga
  // abierto: la ventana de control solo lee/muestra este estado.
  //   vca_learning = { recording:boolean, steps:[descriptor...], ts }
  function pushStep(step, human) {
    const learn = Store.get('vca_learning', null);
    if (!learn || !learn.recording) return;
    learn.steps = learn.steps || [];
    learn.steps.push(step);
    Store.set('vca_learning', learn);
    log('  grabado paso ' + learn.steps.length + ': ' + human);
  }

  // Clics normales (botones, enlaces, celdas...). Los controles de formulario NO
  // se graban por clic: un <select> nativo despliega su lista a nivel del sistema
  // operativo y un clic sintetico sobre una <option> no selecciona nada. Esos se
  // graban con el evento 'change' (abajo).
  document.addEventListener('click', function (ev) {
    const learn = Store.get('vca_learning', null);
    if (!learn || !learn.recording) return;
    const t = ev.target;
    if (t && /^(select|option|input|textarea)$/i.test(t.tagName || '')) return;
    const act = (t.closest && t.closest('a,button,li,[role="button"],[onclick]')) || t;
    const desc = Locator.capture(act);
    desc.kind = 'click';
    pushStep(desc, desc.tag + ' "' + desc.text + '"');
  }, true);

  // Menus desplegables nativos (<select>), campos de texto y casillas.
  document.addEventListener('change', function (ev) {
    const learn = Store.get('vca_learning', null);
    if (!learn || !learn.recording) return;
    const el = ev.target;
    if (!el || !el.tagName) return;
    const tag = el.tagName.toLowerCase();

    if (tag === 'select') {
      const opt = el.options[el.selectedIndex];
      const desc = Locator.capture(el);
      desc.kind = 'select';
      desc.value = el.value;
      desc.optText = opt ? Locator.norm(opt.textContent) : '';
      desc.text = '';   // el textContent de un <select> son TODAS las opciones: inservible
      pushStep(desc, 'menu -> "' + desc.optText + '"');
    } else if (tag === 'input' || tag === 'textarea') {
      const desc = Locator.capture(el);
      if (/^(checkbox|radio)$/i.test(el.type || '')) {
        desc.kind = 'check'; desc.checked = !!el.checked;
        pushStep(desc, el.type + ' = ' + desc.checked);
      } else {
        desc.kind = 'input'; desc.value = el.value; desc.text = '';
        pushStep(desc, 'texto = "' + String(el.value).slice(0, 30) + '"');
      }
    }
  }, true);

  // ===========================================================================
  //  [DESACTIVADO EN v2] PANEL FLOTANTE INYECTADO EN LA PAGINA
  //  Toda la UI vive ahora en el popup de la extension. Estas funciones
  //  (buildPanel / electPanelFrame / removePanel) YA NO SE LLAMAN; se conservan
  //  como referencia. `window.__vcaPanel` nunca se define, por lo que los
  //  `if (window.__vcaPanel)` repartidos por el archivo son no-ops inofensivos.
  // ===========================================================================
  function buildPanel() {
    if (document.getElementById('vca-panel')) return;

    const wrap = document.createElement('div');
    wrap.id = 'vca-panel';
    wrap.innerHTML = `
      <style>
        #vca-panel{position:fixed;top:12px;right:12px;z-index:2147483647;width:250px;
          font:12px/1.4 system-ui,Segoe UI,Arial,sans-serif;color:#111;background:#fff;
          border:1px solid #cfd6e4;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,.22);
          overflow:hidden;user-select:none}
        #vca-panel *{box-sizing:border-box}
        #vca-head{background:#0d3b66;color:#fff;padding:8px 10px;display:flex;
          align-items:center;justify-content:space-between;cursor:move}
        #vca-head b{font-size:12px;letter-spacing:.2px}
        #vca-body{padding:10px;max-height:70vh;overflow:auto}
        .vca-btn{display:block;width:100%;text-align:left;margin:4px 0;padding:7px 9px;
          border:1px solid #cfd6e4;border-radius:7px;background:#f6f8fc;cursor:pointer;
          font-size:12px;position:relative}
        .vca-btn:hover{background:#eef2fa}
        .vca-btn.armed{background:#12a150;border-color:#0e8a44;color:#fff;font-weight:600}
        .vca-btn .x{position:absolute;right:6px;top:6px;opacity:.5}
        .vca-btn .x:hover{opacity:1}
        .vca-row{display:flex;gap:6px;margin-top:8px}
        .vca-row button{flex:1;padding:6px;border:1px solid #cfd6e4;border-radius:7px;
          background:#fff;cursor:pointer;font-size:11px}
        .vca-row button:hover{background:#f0f3f9}
        #vca-hint{margin-top:8px;padding:7px;background:#fff7e0;border:1px solid #f0d38a;
          border-radius:7px;font-size:11px;display:none}
        #vca-status{margin-top:8px;font-size:11px;color:#555}
        #vca-dbg{margin-top:8px;display:none}
        #vca-dbg textarea{width:100%;height:120px;font:10px/1.3 monospace;
          border:1px solid #cfd6e4;border-radius:6px;padding:6px;resize:vertical}
        #vca-dbg input{width:100%;padding:5px;margin:3px 0;border:1px solid #cfd6e4;border-radius:6px}
        #vca-dbg label{font-size:10px;color:#555;display:block;margin-top:6px}
        .vca-mini{font-size:10px;color:#777;margin-top:4px}
        #vca-panel.min{width:auto}
        #vca-panel.min #vca-body{display:none}
      </style>
      <div id="vca-head"><b>⚡ ShortCut-VocalCRM</b><span id="vca-min" style="cursor:pointer">▾</span></div>
      <div id="vca-body">
        <div id="vca-states"></div>
        <input id="vca-name" placeholder="Nombre del estado (ej: Correo)"
          style="width:100%;padding:6px;border:1px solid #cfd6e4;border-radius:7px;font-size:12px;margin-top:8px">
        <div class="vca-row">
          <button id="vca-learn">▶ Iniciar grabación</button>
          <button id="vca-disarm">✖ Desarmar</button>
        </div>
        <div id="vca-hint"></div>
        <div id="vca-rec" style="display:none;margin-top:8px;padding:7px;background:#e8f5ff;border:1px solid #9ecbe8;border-radius:7px">
          <div id="vca-rec-info" style="font-size:11px;margin-bottom:6px"></div>
          <div class="vca-row" style="margin-top:0">
            <button id="vca-rec-done">■ Detener grabación</button>
            <button id="vca-rec-cancel">✖ Cancelar</button>
          </div>
        </div>
        <div id="vca-status"></div>
        <div class="vca-row">
          <button id="vca-dbgtoggle">🐞 Debug</button>
        </div>
        <div id="vca-dbg">
          <label>Patron WebSocket (regex) que indica fin de llamada</label>
          <input id="vca-ws" placeholder="ej: hangup|callEnd|endcall">
          <label>Selector CSS que APARECE al terminar (opcional)</label>
          <input id="vca-wrap" placeholder="ej: #wrapupPanel">
          <label>Selector del boton de colgar (su desaparicion = fin)</label>
          <input id="vca-hang" placeholder="ej: #btnHangup">
          <div class="vca-mini">
            <label style="display:inline"><input type="checkbox" id="vca-timer" style="width:auto"> Detector por cronometro</label>
          </div>
          <div class="vca-mini">
            <label style="display:inline"><input type="checkbox" id="vca-autowatch" style="width:auto"> Auto-aplicar al habilitarse el control</label>
          </div>
          <div class="vca-mini">
            <label style="display:inline"><input type="checkbox" id="vca-reqdis" style="width:auto"> Exigir ver el control deshabilitado primero</label>
          </div>
          <div class="vca-mini">
            <label style="display:inline"><input type="checkbox" id="vca-keepalive" style="width:auto"> Mantener activo en 2° plano (audio inaudible)</label>
          </div>
          <div class="vca-row">
            <button id="vca-testend">▶ Simular fin de llamada</button>
            <button id="vca-clearlog">Limpiar</button>
          </div>
          <label>Registro / tramas WebSocket</label>
          <textarea id="vca-logbox" readonly></textarea>
        </div>
      </div>`;
    document.documentElement.appendChild(wrap);
    wrap.classList.add('min'); // minimizado por defecto: menos cosas flotando

    const $ = (id) => wrap.querySelector(id);

    // --- Arrastrar
    (function drag() {
      const head = $('#vca-head'); let sx, sy, ox, oy, on = false;
      head.addEventListener('mousedown', (e) => {
        if (e.target.id === 'vca-min') return;
        on = true; sx = e.clientX; sy = e.clientY;
        const r = wrap.getBoundingClientRect(); ox = r.left; oy = r.top;
        e.preventDefault();
      });
      window.addEventListener('mousemove', (e) => {
        if (!on) return;
        wrap.style.left = (ox + e.clientX - sx) + 'px';
        wrap.style.top = (oy + e.clientY - sy) + 'px';
        wrap.style.right = 'auto';
      });
      window.addEventListener('mouseup', () => on = false);
    })();

    $('#vca-min').addEventListener('click', () => wrap.classList.toggle('min'));

    $('#vca-learn').addEventListener('click', () => {
      const inp = $('#vca-name');
      const name = (inp.value || '').trim();
      if (!name) { inp.focus(); return; }
      startLearning(name);
      inp.value = '';
    });
    $('#vca-disarm').addEventListener('click', () => { setArmed(null); });
    $('#vca-rec-done').addEventListener('click', () => finishLearning());
    $('#vca-rec-cancel').addEventListener('click', () => cancelLearning());

    $('#vca-dbgtoggle').addEventListener('click', () => {
      const dbg = $('#vca-dbg');
      const show = dbg.style.display !== 'block';
      dbg.style.display = show ? 'block' : 'none';
      setSetting({ debug: show });
      if (show) syncDbgInputs();
    });

    $('#vca-ws').addEventListener('change', (e) => setSetting({ wsPattern: e.target.value.trim() }));
    $('#vca-wrap').addEventListener('change', (e) => setSetting({ wrapupSelector: e.target.value.trim() }));
    $('#vca-hang').addEventListener('change', (e) => setSetting({ hangupSelector: e.target.value.trim() }));
    $('#vca-timer').addEventListener('change', (e) => setSetting({ useTimer: e.target.checked }));
    $('#vca-autowatch').addEventListener('change', (e) => setSetting({ autoWatch: e.target.checked }));
    $('#vca-reqdis').addEventListener('change', (e) => setSetting({ requireDisableFirst: e.target.checked }));
    $('#vca-keepalive').addEventListener('change', (e) => {
      setSetting({ keepAlive: e.target.checked });
      if (e.target.checked) startKeepAlive();
    });
    $('#vca-testend').addEventListener('click', () => broadcastCallEnd('SIMULADO'));
    $('#vca-clearlog').addEventListener('click', () => { Store.set(K.log, []); Store.set('vca_wsframes', []); });

    function syncDbgInputs() {
      const s = settings();
      $('#vca-ws').value = s.wsPattern;
      $('#vca-wrap').value = s.wrapupSelector;
      $('#vca-hang').value = s.hangupSelector;
      $('#vca-timer').checked = s.useTimer;
      $('#vca-autowatch').checked = s.autoWatch;
      $('#vca-reqdis').checked = s.requireDisableFirst;
      $('#vca-keepalive').checked = s.keepAlive;
    }

    const panel = {
      rebuild() {
        const host = $('#vca-states');
        host.innerHTML = '';
        const states = Store.get(K.states, []);
        if (!states.length) {
          host.innerHTML = '<div class="vca-mini">Aun no hay estados. Pulsa “Aprender estado”, escribe un nombre y haz la secuencia real: “Pausa” y luego el estado.</div>';
        }
        const armed = getArmed();
        states.forEach((st) => {
          const steps = stepsOf(st);
          const last = steps.length ? steps[steps.length - 1] : {};
          const b = document.createElement('button');
          b.className = 'vca-btn' + (armed && armed.name === st.name ? ' armed' : '');
          b.innerHTML = (armed && armed.name === st.name ? '🟢 ' : '⚪ ') +
            st.name + '<span class="x" title="Borrar">🗑</span>' +
            '<div class="vca-mini">' + steps.length + ' paso(s) · “' + (last.text || '') + '”</div>';
          b.addEventListener('click', (e) => {
            if (e.target.classList.contains('x')) {
              const all = Store.get(K.states, []).filter(x => x.name !== st.name);
              Store.set(K.states, all); panel.rebuild(); return;
            }
            const cur = getArmed();
            if (cur && cur.name === st.name) { setArmed(null); }   // toggle off
            else { setArmed({ name: st.name, steps: stepsOf(st), __armedAt: Date.now() }); }
            panel.refresh();
          });
          host.appendChild(b);
        });
      },
      refresh() {
        const armed = getArmed();
        Array.from($('#vca-states').querySelectorAll('.vca-btn')).forEach((b, i) => {
          const states = Store.get(K.states, []);
          const st = states[i]; if (!st) return;
          const on = armed && armed.name === st.name;
          b.classList.toggle('armed', on);
        });
        // Barra de grabacion (modo aprender)
        const learn = Store.get('vca_learning', null);
        const rec = $('#vca-rec');
        if (learn) {
          wrap.classList.remove('min'); // expandir para ver la grabacion
          rec.style.display = 'block';
          const n = (learn.steps || []).length;
          $('#vca-rec-info').innerHTML =
            '● Grabando <b>“' + learn.name + '”</b> — ' + n + ' clic(s).<br>' +
            'Haz los clics reales (Pausa → estado); al terminar pulsa <b>■ Detener grabación</b>.';
          $('#vca-status').textContent = 'Grabando secuencia...';
        } else {
          rec.style.display = 'none';
          $('#vca-status').textContent = armed
            ? 'ARMADO: “' + (armed.name || armed.text) + '” se aplicara al colgar.'
            : 'En espera. Selecciona un estado para armar.';
        }
      },
      setHint(t) {
        const h = $('#vca-hint');
        h.textContent = t; h.style.display = t ? 'block' : 'none';
      }
    };

    window.__vcaPanel = panel;
    panel.rebuild();
    panel.refresh();

    // refresco periodico del log/estado
    window.__vcaPanelInterval = setInterval(() => {
      if ($('#vca-dbg').style.display === 'block') {
        const logArr = Store.get(K.log, []);
        const ws = Store.get('vca_wsframes', []);
        $('#vca-logbox').value =
          '== REGISTRO ==\n' + logArr.slice(-40).join('\n') +
          (ws.length ? '\n\n== TRAMAS WS (ultimas) ==\n' + ws.slice(-20).join('\n') : '');
      }
      panel.refresh();
    }, 1200);
  }

  // ===========================================================================
  //  ELECCION DE FRAME PARA EL PANEL
  //  El panel se dibuja en el frame VISIBLE mas grande (donde mira el agente),
  //  aunque la UI del agente este dentro de un iframe. Excluye framesets y
  //  frames sin cuerpo. Se re-evalua cada ~1.5s y sobrevive a re-render de la SPA.
  // ===========================================================================
  const MY_ID = Math.random().toString(36).slice(2);
  const AREAS = 'vca_areas';

  function myArea() {
    // Un <frameset> no renderiza contenido fijo: lo excluimos devolviendo 0.
    if (!document.body || document.body.tagName === 'FRAMESET') return 0;
    return (window.innerWidth || 0) * (window.innerHeight || 0);
  }

  function removePanel() {
    const p = document.getElementById('vca-panel');
    if (p) p.remove();
    if (window.__vcaPanelInterval) { clearInterval(window.__vcaPanelInterval); window.__vcaPanelInterval = null; }
    window.__vcaPanel = null;
  }

  function electPanelFrame() {
    const now = Date.now();
    const areas = Store.get(AREAS, {});
    areas[MY_ID] = { area: myArea(), ts: now };
    for (const k in areas) { if (now - (areas[k].ts || 0) > 4000) delete areas[k]; }
    Store.set(AREAS, areas);

    let best = null;
    for (const k in areas) {
      if (!areas[k] || areas[k].area <= 0) continue;
      if (!best || areas[k].area > areas[best].area ||
         (areas[k].area === areas[best].area && k > best)) best = k;
    }
    if (best === MY_ID) buildPanel();      // soy el frame elegido -> dibujo (idempotente)
    else if (best) removePanel();          // gana otro frame -> quito el mio si lo tuviera
  }

  // ===========================================================================
  //  KEEP-ALIVE: mantiene la pestaña "activa" en segundo plano reproduciendo un
  //  tono INAUDIBLE (10 Hz, volumen mínimo). Los navegadores no congelan/ralentizan
  //  las pestañas que estan emitiendo audio, asi el auto-aplicado sigue funcionando
  //  aunque estes en otra pestaña. Solo en el frame lider (uno basta por pestaña).
  // ===========================================================================
  function startKeepAlive() {
    if (window.__vcaKeepAlive) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      const ctx = new AC();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      gain.gain.value = 0.03;     // el navegador detecta "audio activo"...
      osc.frequency.value = 10;   // ...pero a 10 Hz ningun auricular/altavoz lo reproduce (inaudible)
      osc.type = 'sine';
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start();
      window.__vcaKeepAlive = ctx;
      // Reanudar si el navegador suspende el contexto (politica de autoplay).
      // Requiere un gesto del usuario: cualquier clic/tecla en la pagina lo activa.
      const resume = () => { try { if (ctx.state !== 'running') ctx.resume(); } catch (e) {} };
      resume();
      setInterval(resume, 3000);
      ['click', 'pointerdown', 'mousedown', 'keydown', 'touchstart', 'visibilitychange']
        .forEach(ev => document.addEventListener(ev, resume, true));
      // Publicar el estado ('running'/'suspended') para que la ventana lo muestre.
      const publish = () => { try { Store.set('vca_ka', { state: ctx.state, ts: Date.now() }); } catch (e) {} };
      publish();
      setInterval(publish, 2000);
      log('Keep-alive de audio iniciado (estado: ' + ctx.state + ').');
    } catch (e) { log('Keep-alive no disponible: ' + e); }
  }

  // ===========================================================================
  //  ARRANQUE
  // ===========================================================================
  function boot() {
    // CRM: sin cola. Borra al cargar cualquier tipificación que quedara pendiente,
    // para que NUNCA se aplique sola sobre el cliente que se abra en esta página.
    if (IS_CRM && IS_TOP) { try { Store.del(K.armed); } catch (e) {} }
    TimerDetector.start();
    DomDetector.start();
    JsSipDetector.start();
    setInterval(autoWatchTick, 700);
    // Expuesto para que el service worker lo dispare con chrome.scripting aunque
    // el temporizador de la pestaña este congelado en segundo plano.
    window.__vcaTick = autoWatchTick;
    if (IS_TOP && settings().keepAlive) startKeepAlive(); // uno por pestaña
    // NOTA: la UI ahora vive 100% en el popup de la extension. No se inyecta
    // ningun panel en la pagina (buildPanel/eleccion quedan sin usar).
    log('Cargado en', location.href.slice(0, 80),
        IS_TOP ? '(frame superior)' : '(frame hijo)', 'area=', myArea());
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
