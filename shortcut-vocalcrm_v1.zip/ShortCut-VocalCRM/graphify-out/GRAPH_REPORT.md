# Graph Report - C:\Users\Eduardo\Documents\ShortCut-VocalCRM  (2026-07-23)

## Corpus Check
- Corpus is ~14,790 words - fits in a single context window. You may not need a graph.

## Summary
- 164 nodes · 330 edges · 14 communities
- Extraction: 88% EXTRACTED · 3% INFERRED · 0% AMBIGUOUS · INFERRED: 9 edges (avg confidence: 0.5)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Manifiesto y permisos
- Arquitectura y flujos (alto nivel)
- Almacenamiento y panel flotante (bridge)
- Localizador y panel en pagina (content)
- Estado del panel y audio (control)
- Render y envio de comandos (control)
- Motor: armar, disparar y fallback
- Orden, colores y estado UI
- Service worker: ventana, auto-F5, pulso
- Detectores de fin de llamada
- Grabacion en pagina y arranque
- Reproduccion de pasos (replay)
- Arrastrar y reordenar (UI)
- Descubrimiento de pestanas

## God Nodes (most connected - your core abstractions)
1. `log()` - 16 edges
2. `refreshInner()` - 16 edges
3. `renderList()` - 14 edges
4. `settings()` - 11 edges
5. `autoWatchTick()` - 10 edges
6. `runStepsOnce()` - 9 edges
7. `runSteps()` - 9 edges
8. `stuckFallbackCheck()` - 9 edges
9. `buildPanel()` - 9 edges
10. `Motor de ejecución (content.js)` - 9 edges

## Surprising Connections (you probably didn't know these)
- `Puente + almacenamiento + panel flotante (bridge.js)` --siembra (seedDefaults)--> `Config de fábrica (default-config.json)`  [0.9]
  bridge.js → default-config.json
- `Panel de control (control.html + control.js)` --nombra y guarda--> `Grabación de atajos`  [0.9]
  control.js → content.js
- `PENDIENTE: config de fábrica para repartir` --vía Exportar/Importar--> `Panel de control (control.html + control.js)`  [0.75]
  default-config.json → control.js
- `Puente + almacenamiento + panel flotante (bridge.js)` --comparte estado (localStorage) y vca:cmd--> `Motor de ejecución (content.js)`  [0.9]
  bridge.js → content.js
- `Bus por localStorage del origen` --conecta--> `Motor de ejecución (content.js)`  [0.85]
  bridge.js → content.js

## Import Cycles
- None detected.

## Communities (14 total, 0 thin omitted)

### Community 0 - "Manifiesto y permisos"
Cohesion: 0.07
Nodes (29): action, default_icon, default_title, background, service_worker, content_scripts, 128, 16 (+21 more)

### Community 1 - "Arquitectura y flujos (alto nivel)"
Cohesion: 0.18
Nodes (18): Service worker (background.js), Puente + almacenamiento + panel flotante (bridge.js), Dedup de atajos por firma, Bus por localStorage del origen, Clave de sitio estable (siteKey), Motor de ejecución (content.js), Panel de control (control.html + control.js), Config de fábrica (default-config.json) (+10 more)

### Community 2 - "Almacenamiento y panel flotante (bridge)"
Cohesion: 0.19
Nodes (8): applyPos(), build(), css(), dragify(), mkHeadBtn(), setMode(), showPop(), toggle()

### Community 3 - "Localizador y panel en pagina (content)"
Cohesion: 0.24
Nodes (7): capture(), cssPath(), electPanelFrame(), myArea(), norm(), removePanel(), resolve()

### Community 4 - "Estado del panel y audio (control)"
Cohesion: 0.24
Nodes (9): diag, engineLog, ensureAudio(), hoverBlip(), lastStates, missingSiteHtml(), setStatus(), showStaleNotice() (+1 more)

### Community 5 - "Render y envio de comandos (control)"
Cohesion: 0.29
Nodes (11): activateShortcut(), broadcast(), confirmBox(), escapeHtml(), optimistic(), refresh(), renderList(), sendTo() (+3 more)

### Community 6 - "Motor: armar, disparar y fallback"
Cohesion: 0.44
Nodes (10): autoWatchTick(), finalStateKey(), firstStepStatus(), getArmed(), handleCallEnd(), runSteps(), setArmed(), stepsOf() (+2 more)

### Community 7 - "Orden, colores y estado UI"
Cohesion: 0.27
Nodes (10): bgBadge(), bgWarning(), colorRank(), connectionWarningHtml(), groupRank(), refreshInner(), showRecBox(), siteName() (+2 more)

### Community 8 - "Service worker: ventana, auto-F5, pulso"
Cohesion: 0.28
Nodes (3): findControlWindow(), getSavedPos(), openControl()

### Community 9 - "Detectores de fin de llamada"
Cohesion: 0.33
Nodes (9): broadcastCallEnd(), check(), findClocks(), scan(), setSetting(), settings(), start(), tick() (+1 more)

### Community 10 - "Grabacion en pagina y arranque"
Cohesion: 0.39
Nodes (8): boot(), buildPanel(), cancelLearning(), finishLearning(), log(), pushStep(), startKeepAlive(), startLearning()

### Community 11 - "Reproduccion de pasos (replay)"
Cohesion: 0.36
Nodes (8): fireInputChange(), isClickable(), optionMatch(), runStepsOnce(), setNativeValue(), sleep(), waitFor(), waitForOption()

### Community 12 - "Arrastrar y reordenar (UI)"
Cohesion: 0.29
Nodes (8): labelOf(), onDragEnd(), onDragMove(), onRowPointerDown(), paintArmInfo(), renderNow(), reorderGroupInLastStates(), sigOf()

### Community 13 - "Descubrimiento de pestanas"
Cohesion: 0.50
Nodes (4): collect(), pingTab(), queryTabs(), scanTabs()

## Knowledge Gaps
- **28 isolated node(s):** `diag`, `engineLog`, `lastStates`, `manifest_version`, `name` (+23 more)
  These have ≤1 connection - possible missing edges or undocumented components.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Panel de control (control.html + control.js)` connect `Arquitectura y flujos (alto nivel)` to `Manifiesto y permisos`?**
  _High betweenness centrality (0.015) - this node is a cross-community bridge._
- **What connects `diag`, `engineLog`, `lastStates` to the rest of the system?**
  _28 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Manifiesto y permisos` be split into smaller, more focused modules?**
  _Cohesion score 0.06666666666666667 - nodes in this community are weakly interconnected._